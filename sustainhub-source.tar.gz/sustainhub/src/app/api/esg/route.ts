import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const responses = await db.esgResponse.findMany({
      where: { userId },
      orderBy: { indicatorCode: 'asc' },
    });

    return NextResponse.json({ responses });
  } catch (error) {
    console.error('Get ESG responses error:', error);
    return NextResponse.json({ error: 'Failed to fetch ESG data' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, companyId, reportingPeriod, responses } = body;

    if (!userId || !companyId || !responses || !Array.isArray(responses)) {
      return NextResponse.json({ error: 'User ID, company ID, and responses array are required' }, { status: 400 });
    }

    // Upsert each response
    const results = [];
    for (const r of responses) {
      const upserted = await db.esgResponse.upsert({
        where: {
          companyId_indicatorCode: {
            companyId,
            indicatorCode: r.indicatorCode,
          },
        },
        update: {
          responseValue: r.responseValue ?? null,
          notes: r.notes ?? null,
          section: r.section,
          indicatorLabel: r.indicatorLabel,
        },
        create: {
          userId,
          companyId,
          indicatorCode: r.indicatorCode,
          indicatorLabel: r.indicatorLabel,
          section: r.section,
          responseValue: r.responseValue ?? null,
          notes: r.notes ?? null,
          reportingPeriod,
        },
      });
      results.push(upserted);
    }

    return NextResponse.json({ saved: results.length, responses: results });
  } catch (error) {
    console.error('Save ESG responses error:', error);
    return NextResponse.json({ error: 'Failed to save ESG responses' }, { status: 500 });
  }
}
