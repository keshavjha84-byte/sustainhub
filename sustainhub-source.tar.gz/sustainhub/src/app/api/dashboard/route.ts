import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ESG_INDICATORS } from '@/data/esg-indicators';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    // Get company data
    const company = await db.company.findUnique({
      where: { userId },
      select: {
        companyName: true,
        industrySector: true,
        onboardingCompleted: true,
      },
    });

    // Get GHG entries
    const ghgEntries = await db.ghgEntry.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    // Get ESG responses
    const esgResponses = await db.esgResponse.findMany({
      where: { userId },
    });

    // Calculate ESG Readiness Score
    const totalIndicators = ESG_INDICATORS.length;
    const respondedIndicators = esgResponses.filter(r => r.responseValue !== null && r.responseValue !== '').length;
    const esgReadinessScore = totalIndicators > 0 ? Math.round((respondedIndicators / totalIndicators) * 100) : 0;

    // Section breakdowns
    const govTotal = ESG_INDICATORS.filter(i => i.section === 'Governance').length;
    const envTotal = ESG_INDICATORS.filter(i => i.section === 'Environmental').length;
    const socTotal = ESG_INDICATORS.filter(i => i.section === 'Social').length;

    const govCompleted = esgResponses.filter(r =>
      r.section === 'Governance' && r.responseValue !== null && r.responseValue !== ''
    ).length;
    const envCompleted = esgResponses.filter(r =>
      r.section === 'Environmental' && r.responseValue !== null && r.responseValue !== ''
    ).length;
    const socCompleted = esgResponses.filter(r =>
      r.section === 'Social' && r.responseValue !== null && r.responseValue !== ''
    ).length;

    const sectionProgress = {
      governance: govTotal > 0 ? Math.round((govCompleted / govTotal) * 100) : 0,
      environmental: envTotal > 0 ? Math.round((envCompleted / envTotal) * 100) : 0,
      social: socTotal > 0 ? Math.round((socCompleted / socTotal) * 100) : 0,
    };

    // GHG summary
    const latestGhg = ghgEntries[0] || null;
    const totalEmissions = latestGhg?.totalEmissions || null;
    const latestReportingPeriod = latestGhg?.reportingPeriod || null;

    // Recent activity
    const recentActivity: { id: string; action: string; timestamp: string; type: 'ghg' | 'esg' | 'system' }[] = [];

    if (latestGhg) {
      recentActivity.push({
        id: latestGhg.id,
        action: `GHG emissions calculated: ${latestGhg.totalEmissions.toFixed(4)} tCO₂e`,
        timestamp: latestGhg.createdAt.toISOString(),
        type: 'ghg',
      });
    }

    if (esgResponses.length > 0) {
      const latestEsg = esgResponses.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())[0];
      recentActivity.push({
        id: latestEsg.id,
        action: `ESG questionnaire updated (${respondedIndicators}/${totalIndicators} completed)`,
        timestamp: latestEsg.updatedAt.toISOString(),
        type: 'esg',
      });
    }

    if (company?.onboardingCompleted) {
      recentActivity.push({
        id: 'onboarding',
        action: 'Company profile completed',
        timestamp: new Date().toISOString(),
        type: 'system',
      });
    }

    recentActivity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Next action
    let nextAction: { label: string; view: string } | null = null;
    if (!company?.onboardingCompleted) {
      nextAction = { label: 'Complete company onboarding', view: 'onboarding' };
    } else if (esgReadinessScore === 0) {
      nextAction = { label: 'Start your ESG questionnaire', view: 'esg-questionnaire' };
    } else if (esgReadinessScore < 100) {
      nextAction = { label: 'Continue your ESG questionnaire', view: 'esg-questionnaire' };
    } else if (!totalEmissions || totalEmissions === 0) {
      nextAction = { label: 'Calculate your GHG emissions', view: 'ghg-calculator' };
    } else {
      nextAction = { label: 'Generate your ESG report', view: 'reports' };
    }

    return NextResponse.json({
      esgReadinessScore,
      totalEmissions,
      latestReportingPeriod,
      completedIndicators: respondedIndicators,
      totalIndicators,
      sectionProgress,
      recentActivity: recentActivity.slice(0, 5),
      nextAction,
      company: company ? {
        companyName: company.companyName,
        industrySector: company.industrySector,
      } : null,
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    return NextResponse.json({ error: 'Failed to load dashboard data' }, { status: 500 });
  }
}
