import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { classifyCompany } from '@/data/constants';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const company = await db.company.findUnique({
      where: { userId },
    });

    return NextResponse.json({ company });
  } catch (error) {
    console.error('Get company error:', error);
    return NextResponse.json({ error: 'Failed to fetch company data' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, companyName, registrationNumber, industrySector, annualRevenue, numberOfEmployees, state } = body;

    if (!userId || !companyName || !industrySector || !annualRevenue || !numberOfEmployees || !state) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }

    const companySize = classifyCompany(annualRevenue, numberOfEmployees);

    const company = await db.company.upsert({
      where: { userId },
      update: {
        companyName,
        registrationNumber,
        industrySector,
        annualRevenue,
        numberOfEmployees,
        state,
        companySize,
        onboardingCompleted: true,
      },
      create: {
        userId,
        companyName,
        registrationNumber,
        industrySector,
        annualRevenue,
        numberOfEmployees,
        state,
        companySize,
        onboardingCompleted: true,
      },
    });

    return NextResponse.json({ company });
  } catch (error) {
    console.error('Save company error:', error);
    return NextResponse.json({ error: 'Failed to save company data' }, { status: 500 });
  }
}
