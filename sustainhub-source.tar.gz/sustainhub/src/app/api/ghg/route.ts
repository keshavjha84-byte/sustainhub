import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const entries = await db.ghgEntry.findMany({
      where: { userId },
      include: {
        emissionItems: true,
        scope1Items: true,
        scope2Items: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ entries });
  } catch (error) {
    console.error('Get GHG entries error:', error);
    return NextResponse.json({ error: 'Failed to fetch GHG data' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      companyId,
      reportingPeriod,
      scope2Method,
      emissionItems,
      scope1Total,
      scope2Total,
      scope3Total,
      totalEmissions,
    } = body;

    if (!userId || !companyId || !reportingPeriod) {
      return NextResponse.json(
        { error: 'User ID, company ID, and reporting period are required' },
        { status: 400 },
      );
    }

    const entry = await db.ghgEntry.create({
      data: {
        userId,
        companyId,
        reportingPeriod,
        scope1Total: scope1Total || 0,
        scope2Total: scope2Total || 0,
        scope3Total: scope3Total || 0,
        totalEmissions: totalEmissions || 0,
        status: 'submitted',
        scope2Method: scope2Method || 'location',
        emissionItems: {
          create: (emissionItems || []).map(
            (item: {
              scope: number;
              category: string;
              subCategory?: string;
              sourceName?: string;
              activityData: number;
              activityUnit: string;
              emissionFactor: number;
              efUnit: string;
              emissions: number;
              metadata?: string;
            }) => ({
              scope: item.scope,
              category: item.category,
              subCategory: item.subCategory || null,
              sourceName: item.sourceName || null,
              activityData: item.activityData,
              activityUnit: item.activityUnit,
              emissionFactor: item.emissionFactor,
              efUnit: item.efUnit,
              emissions: item.emissions,
              metadata: item.metadata || null,
            }),
          ),
        },
      },
      include: {
        emissionItems: true,
        scope1Items: true,
        scope2Items: true,
      },
    });

    return NextResponse.json({ entry }, { status: 201 });
  } catch (error) {
    console.error('Save GHG entry error:', error);
    return NextResponse.json({ error: 'Failed to save GHG data' }, { status: 500 });
  }
}
