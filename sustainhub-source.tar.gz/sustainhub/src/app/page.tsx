'use client';

import { useEffect, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useAuthStore } from '@/store/auth';
import { usePortalStore } from '@/store/portal';
import { useToast } from '@/hooks/use-toast';
import LandingPage from '@/components/landing/landing-page';
import AuthWrapper from '@/components/auth/auth-wrapper';
import { PortalLayout } from '@/components/portal/portal-layout';
import OnboardingView from '@/components/portal/onboarding-view';
import DashboardView from '@/components/portal/dashboard-view';
import GhgCalculatorView from '@/components/portal/ghg-calculator-view';
import EsgQuestionnaireView from '@/components/portal/esg-questionnaire-view';
import ReportsView from '@/components/portal/reports-view';
import ResourcesView from '@/components/portal/resources-view';
import SubscriptionView from '@/components/portal/subscription-view';
import type { PortalView } from '@/types';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});

const pageVariants = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.25, ease: 'easeOut' } },
  exit: { opacity: 0, y: -8, transition: { duration: 0.15, ease: 'easeIn' } },
};

function PortalRouter() {
  const user = useAuthStore((s) => s.user);
  const company = useAuthStore((s) => s.company);
  const setCompany = useAuthStore((s) => s.setCompany);
  const view = usePortalStore((s) => s.currentView);
  const setView = usePortalStore((s) => s.setView);
  const { toast } = useToast();

  const companyId = company?.id || user?.id || '';
  const companyData = company
    ? { companyName: company.companyName, companySize: company.companySize }
    : null;

  // Fetch company data if authenticated but no company loaded yet
  useEffect(() => {
    if (user?.id && !company) {
      fetch(`/api/company?userId=${user.id}`)
        .then(r => r.json())
        .then(data => {
          if (data.company) {
            setCompany({
              id: data.company.id,
              companyName: data.company.companyName,
              companySize: data.company.companySize,
              industrySector: data.company.industrySector,
              onboardingCompleted: data.company.onboardingCompleted,
            });
            // If onboarding was completed and we're on onboarding page, redirect
            if (data.company.onboardingCompleted && view === 'onboarding') {
              setView('dashboard');
            }
          }
        })
        .catch(() => {});
    }
  }, [user?.id, company, setCompany, view, setView]);

  const handleGetStarted = () => setView('auth');
  const handleBackToLanding = () => setView('landing');

  const handleOnboardingComplete = useCallback(async () => {
    // Refresh company data after onboarding
    const userId = user?.id;
    if (userId) {
      try {
        const res = await fetch(`/api/company?userId=${userId}`);
        const data = await res.json();
        if (data.company) {
          setCompany({
            id: data.company.id,
            companyName: data.company.companyName,
            companySize: data.company.companySize,
            industrySector: data.company.industrySector,
            onboardingCompleted: data.company.onboardingCompleted,
          });
        }
      } catch {
        // Company was saved, just proceed
      }
    }
    toast({ title: 'Company profile saved!', description: 'You can now explore the portal.' });
    queryClient.invalidateQueries({ queryKey: ['dashboard'] });
    setView('dashboard');
  }, [user, setCompany, setView, toast]);

  const handleNavigate = useCallback((targetView: PortalView) => {
    setView(targetView);
  }, [setView]);

  // Redirect authenticated users away from landing
  useEffect(() => {
    if (user && view === 'landing') {
      setView(company?.onboardingCompleted ? 'dashboard' : 'onboarding');
    }
  }, [user, view, company, setView]);

  return (
    <AnimatePresence mode="wait">
      {view === 'landing' && !user && (
        <motion.div key="landing" variants={pageVariants} initial="initial" animate="animate" exit="exit">
          <LandingPage onGetStarted={handleGetStarted} />
        </motion.div>
      )}

      {view === 'auth' && (
        <motion.div key="auth" variants={pageVariants} initial="initial" animate="animate" exit="exit">
          <AuthWrapper onBack={handleBackToLanding} />
        </motion.div>
      )}

      {view === 'onboarding' && user && (
        <motion.div key="onboarding" variants={pageVariants} initial="initial" animate="animate" exit="exit">
          <div className="min-h-screen flex items-center justify-center p-4 bg-muted/30">
            <div className="w-full max-w-2xl">
              <OnboardingView
                userId={user.id}
                onComplete={handleOnboardingComplete}
              />
            </div>
          </div>
        </motion.div>
      )}

      {user && view !== 'landing' && view !== 'auth' && view !== 'onboarding' && (
        <motion.div key="portal" variants={pageVariants} initial="initial" animate="animate" exit="exit">
          <PortalLayout companyData={companyData}>
            {view === 'dashboard' && (
              <DashboardView userId={user.id} onNavigate={handleNavigate} />
            )}
            {view === 'ghg-calculator' && (
              <GhgCalculatorView userId={user.id} companyId={companyId} />
            )}
            {view === 'esg-questionnaire' && (
              <EsgQuestionnaireView userId={user.id} companyId={companyId} />
            )}
            {view === 'reports' && (
              <ReportsView userId={user.id} />
            )}
            {view === 'resources' && (
              <ResourcesView />
            )}
            {view === 'subscription' && (
              <SubscriptionView userId={user.id} />
            )}
            {view === 'settings' && (
              <DashboardView userId={user.id} onNavigate={handleNavigate} />
            )}
          </PortalLayout>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function HomePage() {
  return (
    <QueryClientProvider client={queryClient}>
      <PortalRouter />
    </QueryClientProvider>
  );
}