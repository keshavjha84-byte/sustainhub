import { create } from 'zustand';
import { PortalView } from '@/types';

interface PortalState {
  currentView: PortalView;
  sidebarOpen: boolean;
  setView: (view: PortalView) => void;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
}

export const usePortalStore = create<PortalState>((set) => ({
  currentView: 'landing',
  sidebarOpen: true,
  setView: (view) => set({ currentView: view }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
}));