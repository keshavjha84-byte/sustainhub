import { create } from 'zustand';

interface CompanyInfo {
  id: string;
  companyName: string;
  companySize: string;
  industrySector: string;
  onboardingCompleted: boolean;
}

interface AuthState {
  isAuthenticated: boolean;
  user: {
    id: string;
    email: string;
    name: string;
    role: string;
  } | null;
  company: CompanyInfo | null;
  isLoading: boolean;
  setAuth: (user: { id: string; email: string; name: string; role: string; company?: CompanyInfo | null } | null) => void;
  setCompany: (company: CompanyInfo | null) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  user: null,
  company: null,
  isLoading: true,
  setAuth: (userData) => set({
    isAuthenticated: !!userData,
    user: userData ? { id: userData.id, email: userData.email, name: userData.name, role: userData.role } : null,
    company: userData?.company || null,
    isLoading: false,
  }),
  setCompany: (company) => set({ company }),
  setLoading: (loading) => set({ isLoading: loading }),
  logout: () => set({ isAuthenticated: false, user: null, company: null, isLoading: false }),
}));