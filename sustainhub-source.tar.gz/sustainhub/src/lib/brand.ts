// Central brand configuration - change the name here and it updates everywhere
// To switch names, just update `name` and `shortName` below.

export const BRAND = {
  name: 'SustainHub',
  shortName: 'SH',
  tagline: 'Sustainability Reporting for Malaysian Businesses',
  description:
    'Meet Bursa Malaysia SEDG compliance requirements. Calculate GHG emissions, complete the 35-indicator questionnaire, and generate publication-ready reports.',
  url: 'sustainhub.com',
  copyright: 'SustainHub Malaysia',
  badge: 'Built for Malaysian SMEs',
} as const;