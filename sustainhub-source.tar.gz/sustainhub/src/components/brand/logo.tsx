'use client';

import { cn } from '@/lib/utils';

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const sizeConfig = {
  sm: {
    wrapper: 'gap-1.5',
    iconBox: 'size-7 rounded-md',
    iconSvg: 16,
    text: 'text-sm',
  },
  md: {
    wrapper: 'gap-2',
    iconBox: 'size-8 rounded-lg',
    iconSvg: 20,
    text: 'text-lg',
  },
  lg: {
    wrapper: 'gap-2.5',
    iconBox: 'size-10 rounded-xl',
    iconSvg: 24,
    text: 'text-2xl',
  },
} as const;

export function SustainHubLogo({ className, showText = true, size = 'md' }: LogoProps) {
  const cfg = sizeConfig[size];

  return (
    <div className={cn('flex items-center', cfg.wrapper, className)}>
      {/* Hub icon: rounded square with interconnected dots */}
      <div
        className={cn(
          'flex items-center justify-center bg-primary shrink-0',
          cfg.iconBox,
        )}
      >
        <svg
          width={cfg.iconSvg}
          height={cfg.iconSvg}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          {/* Connecting lines */}
          <path
            d="M7.5 7.5 L16.5 7.5"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
          />
          <path
            d="M12 10.5 L12 19.5"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
          />
          <path
            d="M7.5 12.5 L16.5 17.5"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
          />
          {/* Center dot */}
          <circle cx="12" cy="7.5" r="2" fill="currentColor" />
          {/* Top-left dot */}
          <circle cx="7.5" cy="7.5" r="1.6" fill="currentColor" />
          {/* Top-right dot */}
          <circle cx="16.5" cy="7.5" r="1.6" fill="currentColor" />
          {/* Bottom-left dot */}
          <circle cx="7.5" cy="12.5" r="1.6" fill="currentColor" />
          {/* Bottom-right dot */}
          <circle cx="16.5" cy="17.5" r="1.6" fill="currentColor" />
          {/* Bottom-center dot */}
          <circle cx="12" cy="19.5" r="1.6" fill="currentColor" />
        </svg>
      </div>

      {showText && (
        <span className={cn('font-bold tracking-tight text-foreground', cfg.text)}>
          Sustain<span className="text-primary">Hub</span>
        </span>
      )}
    </div>
  );
}
