'use client';

import { useState, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { SustainHubLogo } from '@/components/brand/logo';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/store/auth';
import { usePortalStore } from '@/store/portal';
import { useToast } from '@/hooks/use-toast';
import LoginForm from './login-form';
import RegisterForm from './register-form';

type AuthView = 'login' | 'register';

interface AuthWrapperProps {
  onBack: () => void;
}

export default function AuthWrapper({ onBack }: AuthWrapperProps) {
  const [authView, setAuthView] = useState<AuthView>('login');
  const { setAuth, logout } = useAuthStore();
  const { setView } = usePortalStore();
  const { toast } = useToast();

  const handleLogin = useCallback(async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Login failed.');
    }

    // Fetch full session data
    const sessionRes = await fetch('/api/auth/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: data.user.id }),
    });

    const sessionData = await sessionRes.json();

    if (!sessionRes.ok) {
      throw new Error(sessionData.error || 'Failed to load session.');
    }

    setAuth({ ...sessionData.user, company: sessionData.user.company });
    toast({ title: 'Welcome back!', description: `Signed in as ${sessionData.user.name}` });

    // Navigate based on onboarding status
    if (sessionData.user.company?.onboardingCompleted) {
      setView('dashboard');
    } else {
      setView('onboarding');
    }
  }, [setAuth, setView, toast]);

  const handleRegister = useCallback(async (name: string, email: string, password: string) => {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Registration failed.');
    }

    // Auto-login after registration
    const loginRes = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const loginData = await loginRes.json();

    if (!loginRes.ok) {
      // Registration succeeded but auto-login failed. Still store basic user.
      setAuth({ ...data.user, company: null });
      toast({ title: 'Account created!', description: 'Please sign in to continue.' });
      setView('onboarding');
      return;
    }

    const sessionRes = await fetch('/api/auth/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: loginData.user.id }),
    });

    const sessionData = await sessionRes.json();

    if (sessionRes.ok) {
      setAuth({ ...sessionData.user, company: sessionData.user.company });
    } else {
      setAuth({ ...loginData.user, company: null });
    }

    toast({ title: 'Account created!', description: "Welcome to SustainHub. Let's set up your company." });
    setView('onboarding');
  }, [setAuth, setView, toast]);

  const handleLogout = useCallback(() => {
    logout();
    setView('landing');
  }, [logout, setView]);

  // Expose logout to parent via window or just keep internal
  // For now, logout is handled internally via auth store

  return (
    <div className="flex min-h-screen">
      {/* ─── Left Brand Panel (desktop only) ─── */}
      <div className="hidden lg:flex lg:w-[480px] xl:w-[520px] shrink-0 flex-col justify-between bg-primary p-10 text-primary-foreground relative overflow-hidden">
        {/* Decorative shapes */}
        <div className="pointer-events-none absolute -top-20 -right-20 h-72 w-72 rounded-full bg-primary-foreground/5" aria-hidden />
        <div className="pointer-events-none absolute bottom-10 -left-16 h-56 w-56 rounded-full bg-primary-foreground/5" aria-hidden />

        <div className="relative z-10">
          <button
            type="button"
            onClick={onBack}
            className="mb-8 inline-flex items-center gap-1.5 text-sm text-primary-foreground/70 transition-colors hover:text-primary-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to home
          </button>

          <div className="flex items-center gap-3 mb-6">
            <SustainHubLogo size="md" className="text-primary-foreground [&_*]:!text-primary-foreground" />
          </div>

          <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
            Simplified ESG Compliance for Malaysian SMEs
          </h2>
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-primary-foreground/75">
            Navigate Bursa Malaysia&apos;s sustainability requirements with confidence.
            Our platform guides you through every step of ESG reporting.
          </p>
        </div>

        {/* Simple illustration area */}
        <div className="relative z-10 mx-auto w-full max-w-sm">
          <div className="rounded-2xl border border-primary-foreground/10 bg-primary-foreground/5 p-6">
            <div className="flex items-center gap-3 mb-4">
              <SustainHubLogo size="sm" className="opacity-80 [&_*]:!text-primary-foreground" />
              <div>
                <div className="h-2.5 w-28 rounded bg-primary-foreground/15" />
                <div className="mt-1.5 h-2 w-20 rounded bg-primary-foreground/10" />
              </div>
            </div>
            <div className="space-y-2.5">
              <div className="flex items-center gap-2.5">
                <div className="h-7 w-7 rounded-md bg-primary-foreground/10 shrink-0" />
                <div className="flex-1 h-2.5 rounded bg-primary-foreground/10" />
              </div>
              <div className="flex items-center gap-2.5">
                <div className="h-7 w-7 rounded-md bg-primary-foreground/10 shrink-0" />
                <div className="flex-1 h-2.5 rounded bg-primary-foreground/8" />
              </div>
              <div className="flex items-center gap-2.5">
                <div className="h-7 w-7 rounded-md bg-primary-foreground/10 shrink-0" />
                <div className="flex-1 h-2.5 rounded bg-primary-foreground/10" />
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <div className="h-2 w-24 rounded bg-primary-foreground/10" />
              <div className="h-7 w-20 rounded-md bg-primary-foreground/15" />
            </div>
          </div>
        </div>

        <p className="relative z-10 text-xs text-primary-foreground/50">
          &copy; 2025 SustainHub Malaysia
        </p>
      </div>

      {/* ─── Right Form Panel ─── */}
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-10 sm:px-12 bg-background">
        {/* Mobile back button */}
        <button
          type="button"
          onClick={onBack}
          className="mb-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground lg:hidden"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </button>

        {/* Mobile brand */}
        <div className="mb-6 lg:hidden">
          <SustainHubLogo size="md" />
        </div>

        <div className="w-full max-w-sm">
          <AnimatePresence mode="wait">
            {authView === 'login' ? (
              <motion.div
                key="login"
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 12 }}
                transition={{ duration: 0.2 }}
              >
                <LoginForm
                  onLogin={handleLogin}
                  onSwitchToRegister={() => setAuthView('register')}
                />
              </motion.div>
            ) : (
              <motion.div
                key="register"
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -12 }}
                transition={{ duration: 0.2 }}
              >
                <RegisterForm
                  onRegister={handleRegister}
                  onSwitchToLogin={() => setAuthView('login')}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}