'use client';

import { useState, useEffect, useCallback, useSyncExternalStore } from 'react';
import { motion } from 'framer-motion';
import {
  Calculator,
  ClipboardList,
  FileText,
  BookOpen,
  BarChart3,
  ShieldCheck,
  UserPlus,
  PenLine,
  FileDown,
  Zap,
  Target,
  DollarSign,
  HeadphonesIcon,
  ArrowRight,
  Check,
  Menu,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion';
import { Separator } from '@/components/ui/separator';
import { SustainHubLogo } from '@/components/brand/logo';
import { SUBSCRIPTION_PLANS } from '@/data/constants';

interface LandingPageProps {
  onGetStarted: () => void;
}

/* ------------------------------------------------------------------ */
/*  Animation variants                                                 */
/* ------------------------------------------------------------------ */
const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.45, ease: [0.22, 0.61, 0.36, 1] },
  }),
};

const sectionFade = {
  hidden: { opacity: 0, y: 32 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 0.61, 0.36, 1] },
  },
};

/* ------------------------------------------------------------------ */
/*  Data                                                               */
/* ------------------------------------------------------------------ */

const NAV_LINKS = [
  { label: 'Features', href: '#features' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'Pricing', href: '#pricing' },
];

const STATS = [
  { value: '100+', label: 'Companies' },
  { value: '500+', label: 'Reports' },
  { value: '350+', label: 'Users' },
  { value: '99%', label: 'Compliance Rate' },
];

const FEATURES = [
  {
    icon: Calculator,
    title: 'GHG Calculator',
    description:
      'Calculate Scope 1, 2, and 3 emissions using Malaysia-specific emission factors. TNB grid factors for Peninsular, Sabah, and Sarawak are built in.',
    accent: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400',
  },
  {
    icon: ClipboardList,
    title: 'SEDG Questionnaire',
    description:
      'Work through all 35 SEDG indicators across Governance, Environmental, and Social pillars with clear, guided questions.',
    accent: 'bg-teal-50 text-teal-600 dark:bg-teal-950 dark:text-teal-400',
  },
  {
    icon: FileText,
    title: 'Report Generation',
    description:
      'Generate professional ESG reports aligned with Bursa Malaysia requirements, ready to share with stakeholders and regulators.',
    accent: 'bg-green-50 text-green-600 dark:bg-green-950 dark:text-green-400',
  },
  {
    icon: BookOpen,
    title: 'Education Centre',
    description:
      'Learn about ESG reporting, GHG protocols, and Malaysian regulations through structured learning modules and guides.',
    accent: 'bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400',
  },
  {
    icon: BarChart3,
    title: 'Dashboard Analytics',
    description:
      'Track your ESG readiness score, monitor emissions trends, and see your progress across all three pillars at a glance.',
    accent: 'bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-400',
  },
  {
    icon: ShieldCheck,
    title: 'Secure & Private',
    description:
      'Your data stays in Malaysia. Enterprise-grade security with full PDPA compliance and role-based access controls.',
    accent: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
  },
];

const STEPS = [
  {
    number: 1,
    icon: UserPlus,
    title: 'Create your account',
    description:
      'Sign up in under a minute with your email. No credit card required for the free plan.',
  },
  {
    number: 2,
    icon: PenLine,
    title: 'Enter your data',
    description:
      'Add your company details, calculate emissions using built-in Malaysia factors, and fill in the SEDG questionnaire.',
  },
  {
    number: 3,
    icon: FileDown,
    title: 'Download your report',
    description:
      'Generate a polished ESG report you can share with stakeholders, banks, and regulators.',
  },
];

const DIFFERENTIATORS = [
  {
    icon: Zap,
    title: 'Malaysian emission factors built in',
    description:
      'Grid factors from TNB, SESB, and Sarawak Energy are pre-loaded. No need to look up external data.',
  },
  {
    icon: Target,
    title: 'SEDG-aligned by default',
    description:
      "Our questionnaire maps directly to Bursa Malaysia's 35 SEDG indicators across all three pillars.",
  },
  {
    icon: DollarSign,
    title: 'Built for SMEs',
    description:
      'Simple pricing, no enterprise complexity. Get started with the features you need and upgrade as you grow.',
  },
  {
    icon: HeadphonesIcon,
    title: 'Local support',
    description:
      'Our team understands Malaysian regulations, TNB billing, and the challenges SMEs face with ESG reporting.',
  },
];

const FAQS = [
  {
    question: 'What is SEDG and does it apply to my business?',
    answer:
      "SEDG stands for Bursa Malaysia's Sustainable Development Reporting Guide. It applies to Main Market listed issuers, but many SMEs are being asked by supply chain partners and banks to provide ESG data.",
  },
  {
    question: 'What are Scope 1, 2, and 3 emissions?',
    answer:
      'Scope 1 covers direct emissions from sources you own (e.g., company vehicles, on-site fuel). Scope 2 covers indirect emissions from purchased electricity. Scope 3 covers all other indirect emissions in your value chain (e.g., business travel, waste, purchased goods).',
  },
  {
    question: 'Which emission factors does SustainHub use?',
    answer:
      'We use Malaysia-specific grid emission factors published by the Energy Commission and MGTC: Peninsular (0.6332 kg CO2e/kWh), Sabah (0.4138), and Sarawak (0.2450). For fuel combustion, we use factors from the GHG Protocol and IPCC guidelines.',
  },
  {
    question: 'How long does it take to complete a report?',
    answer:
      'Most SMEs complete their first report in 2-4 hours. Subsequent reports are faster as your data carries over between periods.',
  },
  {
    question: 'Is my data secure?',
    answer:
      "Yes. Your data is encrypted at rest and in transit. We comply with Malaysia's PDPA and do not share your data with third parties.",
  },
  {
    question: 'Can I cancel my subscription anytime?',
    answer:
      'Yes, you can cancel anytime from your account settings. Your data remains accessible on the free plan.',
  },
  {
    question: 'Do I need to be a Bursa-listed company to use SustainHub?',
    answer:
      'No. While SustainHub is built around SEDG requirements, any Malaysian business can use it to measure and report their ESG performance.',
  },
];

const FOOTER_LINKS = {
  Product: ['Features', 'Pricing', 'GHG Calculator', 'ESG Questionnaire'],
  Resources: ['ESG Guide', 'GHG Reporting Guide', 'SEDG Framework', 'Glossary'],
  Company: ['About', 'Contact', 'Privacy Policy', 'Terms of Service'],
};

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = useCallback(
    (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
      e.preventDefault();
      setMobileNavOpen(false);
      const el = document.querySelector(href);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    },
    []
  );

  if (!mounted) return null;

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* ────────────────────────────────────────────────────────── */}
      {/*  1. NAVIGATION                                              */}
      {/* ────────────────────────────────────────────────────────── */}
      <nav
        className={`sticky top-0 z-40 border-b transition-colors duration-200 ${
          scrolled
            ? 'border-border bg-background/90 backdrop-blur-lg'
            : 'border-transparent bg-background'
        }`}
      >
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <SustainHubLogo size="md" />

          {/* Desktop nav */}
          <div className="hidden items-center gap-8 md:flex">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="hidden md:block">
            <Button size="sm" onClick={onGetStarted}>
              Get Started
              <ArrowRight className="ml-1 h-3.5 w-3.5" />
            </Button>
          </div>

          {/* Mobile hamburger */}
          <button
            className="inline-flex items-center justify-center rounded-md p-2 text-muted-foreground hover:text-foreground md:hidden"
            onClick={() => setMobileNavOpen(!mobileNavOpen)}
            aria-label="Toggle navigation menu"
          >
            {mobileNavOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile nav dropdown */}
        {mobileNavOpen && (
          <div className="border-t bg-background px-4 pb-4 pt-2 md:hidden">
            <div className="flex flex-col gap-3">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                >
                  {link.label}
                </a>
              ))}
              <Separator className="my-1" />
              <Button size="sm" onClick={() => { setMobileNavOpen(false); onGetStarted(); }} className="w-full">
                Get Started
                <ArrowRight className="ml-1 h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* ────────────────────────────────────────────────────────── */}
      {/*  MAIN CONTENT                                              */}
      {/* ────────────────────────────────────────────────────────── */}
      <main className="flex-1">
        {/* ────────────────────────────────────────────────────── */}
        {/*  2. HERO                                               */}
        {/* ────────────────────────────────────────────────────── */}
        <section className="relative overflow-hidden px-4 pt-16 pb-20 sm:pt-24 sm:pb-28">
          {/* Background decoration */}
          <div className="pointer-events-none absolute -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-primary/5 blur-[100px]" aria-hidden />
          <div className="pointer-events-none absolute -bottom-32 -right-32 h-[400px] w-[400px] rounded-full bg-emerald-500/5 blur-[100px]" aria-hidden />

          <div className="relative mx-auto max-w-3xl text-center">
            <motion.div
              initial="hidden"
              animate="visible"
              className="flex flex-col items-center gap-5"
            >
              <motion.div variants={fadeUp} custom={0}>
                <Badge
                  variant="outline"
                  className="border-primary/20 bg-primary/5 px-3.5 py-1.5 text-xs font-medium text-primary"
                >
                  Built for Malaysian SMEs
                </Badge>
              </motion.div>

              <motion.h1
                variants={fadeUp}
                custom={1}
                className="text-3xl font-extrabold leading-[1.15] tracking-tight text-foreground sm:text-5xl"
              >
                Sustainability Reporting for Malaysian Businesses
              </motion.h1>

              <motion.p
                variants={fadeUp}
                custom={2}
                className="mx-auto max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg"
              >
                Meet Bursa Malaysia&apos;s SEDG requirements. Calculate GHG emissions, complete
                the 35-indicator questionnaire, and generate publication-ready reports in one
                platform.
              </motion.p>

              <motion.div
                variants={fadeUp}
                custom={3}
                className="mt-2 flex flex-col gap-3 sm:flex-row sm:justify-center"
              >
                <Button size="lg" onClick={onGetStarted} className="px-7 text-base">
                  Start Free Today
                  <ArrowRight className="ml-1.5 h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="px-7 text-base"
                  onClick={(e) => handleNavClick(e as unknown as React.MouseEvent<HTMLAnchorElement>, '#how-it-works')}
                >
                  See How It Works
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  3. TRUSTED BY / SOCIAL PROOF                          */}
        {/* ────────────────────────────────────────────────────── */}
        <section className="border-y bg-muted/30 px-4 py-12 sm:py-16">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-4xl"
          >
            <p className="mb-8 text-center text-sm font-medium text-muted-foreground">
              Trusted by businesses across Malaysia
            </p>
            <div className="grid grid-cols-2 gap-6 sm:grid-cols-4 sm:gap-8">
              {STATS.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl font-extrabold tracking-tight text-foreground sm:text-4xl">
                    {stat.value}
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  4. FEATURES GRID                                      */}
        {/* ────────────────────────────────────────────────────── */}
        <section id="features" className="scroll-mt-16 px-4 py-16 sm:py-24">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-5xl"
          >
            <div className="mx-auto mb-12 max-w-2xl text-center sm:mb-16">
              <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Everything you need for ESG compliance
              </h2>
              <p className="mt-3 text-base text-muted-foreground">
                One platform to calculate, report, and learn about your sustainability performance.
              </p>
            </div>

            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((feature, i) => (
                <motion.div
                  key={feature.title}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: '-40px' }}
                  variants={fadeUp}
                  custom={i}
                >
                  <Card className="group h-full border-border/60 transition-all duration-200 hover:border-primary/20 hover:shadow-md">
                    <CardContent className="flex flex-col gap-4 p-6 pt-6">
                      <div
                        className={`flex h-11 w-11 items-center justify-center rounded-xl ${feature.accent}`}
                      >
                        <feature.icon className="h-5 w-5" />
                      </div>
                      <h3 className="text-base font-semibold text-foreground">{feature.title}</h3>
                      <p className="text-sm leading-relaxed text-muted-foreground">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  5. HOW IT WORKS                                       */}
        {/* ────────────────────────────────────────────────────── */}
        <section
          id="how-it-works"
          className="scroll-mt-16 border-y bg-muted/30 px-4 py-16 sm:py-24"
        >
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-4xl"
          >
            <div className="mx-auto mb-14 max-w-2xl text-center">
              <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Get compliant in three steps
              </h2>
              <p className="mt-3 text-base text-muted-foreground">
                No complicated setup. Just sign up, fill in your data, and download your report.
              </p>
            </div>

            <div className="relative grid gap-10 sm:grid-cols-3 sm:gap-8">
              {/* Connecting line (desktop) */}
              <div
                className="pointer-events-none absolute left-[calc(16.67%+24px)] right-[calc(16.67%+24px)] top-12 hidden h-px bg-border sm:block"
                aria-hidden
              />

              {STEPS.map((step, i) => (
                <motion.div
                  key={step.number}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: '-40px' }}
                  variants={fadeUp}
                  custom={i}
                  className="relative text-center"
                >
                  <div className="relative z-10 mx-auto mb-5 flex h-12 w-12 items-center justify-center rounded-full border-2 border-primary bg-background">
                    <step.icon className="h-5 w-5 text-primary" />
                  </div>
                  <span className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-primary/70">
                    Step {step.number}
                  </span>
                  <h3 className="mb-2 text-base font-semibold text-foreground">{step.title}</h3>
                  <p className="mx-auto max-w-xs text-sm leading-relaxed text-muted-foreground">
                    {step.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  6. WHAT MAKES US DIFFERENT                            */}
        {/* ────────────────────────────────────────────────────── */}
        <section className="px-4 py-16 sm:py-24">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-5xl"
          >
            <div className="mx-auto mb-12 max-w-2xl text-center sm:mb-16">
              <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Why Malaysian SMEs choose SustainHub
              </h2>
              <p className="mt-3 text-base text-muted-foreground">
                We built this specifically for the Malaysian market, not adapted from a global tool.
              </p>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              {DIFFERENTIATORS.map((item, i) => (
                <motion.div
                  key={item.title}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: '-40px' }}
                  variants={fadeUp}
                  custom={i}
                >
                  <div className="rounded-xl border border-border/60 bg-card p-6 transition-colors duration-200 hover:border-primary/15">
                    <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <item.icon className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="mb-2 text-base font-semibold text-foreground">{item.title}</h3>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  7. PRICING                                            */}
        {/* ────────────────────────────────────────────────────── */}
        <section id="pricing" className="scroll-mt-16 border-y bg-muted/30 px-4 py-16 sm:py-24">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-5xl"
          >
            <div className="mx-auto mb-12 max-w-2xl text-center sm:mb-16">
              <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Simple, transparent pricing
              </h2>
              <p className="mt-3 text-base text-muted-foreground">
                Start free, then upgrade when you need more. No hidden fees, no annual lock-ins.
              </p>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {SUBSCRIPTION_PLANS.map((plan, i) => {
                const isHighlighted = plan.highlighted;
                return (
                  <motion.div
                    key={plan.id}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: '-40px' }}
                    variants={fadeUp}
                    custom={i}
                    className="relative"
                  >
                    {isHighlighted && (
                      <div className="absolute -top-3 left-1/2 z-10 -translate-x-1/2">
                        <Badge className="bg-primary text-primary-foreground px-3 py-0.5 text-xs">
                          Most Popular
                        </Badge>
                      </div>
                    )}
                    <Card
                      className={`h-full transition-shadow duration-200 hover:shadow-lg ${
                        isHighlighted ? 'border-primary shadow-md' : ''
                      }`}
                    >
                      <CardContent className="flex flex-col gap-5 p-6 pt-6">
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
                          <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-4xl font-extrabold tracking-tight text-foreground">
                            {plan.price === 0 ? 'Free' : `RM${plan.price}`}
                          </span>
                          {plan.price > 0 && (
                            <span className="text-sm text-muted-foreground">/month</span>
                          )}
                        </div>
                        <Separator />
                        <ul className="flex flex-col gap-3">
                          {plan.features.map((feature) => (
                            <li key={feature} className="flex items-start gap-2.5 text-sm">
                              <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                              <span className="text-muted-foreground">{feature}</span>
                            </li>
                          ))}
                        </ul>
                        <Button
                          className="mt-auto w-full"
                          variant={isHighlighted ? 'default' : 'outline'}
                          onClick={onGetStarted}
                        >
                          {plan.cta}
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  8. FAQ                                                */}
        {/* ────────────────────────────────────────────────────── */}
        <section className="px-4 py-16 sm:py-24">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-3xl"
          >
            <div className="mb-10 text-center sm:mb-14">
              <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Frequently asked questions
              </h2>
              <p className="mt-3 text-base text-muted-foreground">
                Quick answers to common questions about SustainHub and ESG reporting in Malaysia.
              </p>
            </div>

            <Accordion type="single" collapsible className="w-full">
              {FAQS.map((faq, i) => (
                <AccordionItem key={i} value={`faq-${i}`}>
                  <AccordionTrigger className="text-left text-sm font-medium sm:text-base">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </section>

        {/* ────────────────────────────────────────────────────── */}
        {/*  9. FINAL CTA                                         */}
        {/* ────────────────────────────────────────────────────── */}
        <section className="px-4 pb-16 sm:pb-24">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={sectionFade}
            className="mx-auto max-w-3xl rounded-2xl bg-primary px-6 py-14 text-center text-primary-foreground sm:px-12 sm:py-16"
          >
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Ready to get started with ESG reporting?
            </h2>
            <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed opacity-90 sm:text-base">
              Join Malaysian SMEs already using SustainHub to stay ahead of sustainability
              requirements.
            </p>
            <div className="mt-8">
              <Button
                size="lg"
                variant="secondary"
                onClick={onGetStarted}
                className="px-8 text-base"
              >
                Create Free Account
                <ArrowRight className="ml-1.5 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        </section>
      </main>

      {/* ────────────────────────────────────────────────────────── */}
      {/*  10. FOOTER                                                 */}
      {/* ────────────────────────────────────────────────────────── */}
      <footer className="mt-auto border-t bg-muted/30 px-4 pt-12 pb-8 sm:pt-16">
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
            {/* Brand column */}
            <div className="lg:col-span-2">
              <SustainHubLogo size="md" className="mb-3" />
              <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
                ESG compliance platform built for Malaysian businesses. Calculate emissions,
                complete SEDG questionnaires, and generate professional reports.
              </p>
            </div>

            {/* Link columns */}
            {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
              <div key={heading}>
                <h4 className="mb-3 text-sm font-semibold text-foreground">{heading}</h4>
                <ul className="flex flex-col gap-2.5">
                  {links.map((link) => (
                    <li key={link}>
                      <a
                        href="#"
                        className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <Separator className="my-8" />

          <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
            <p className="text-xs text-muted-foreground">
              &copy; 2025 SustainHub Malaysia. All rights reserved.
            </p>
            <p className="text-xs text-muted-foreground">Made in Malaysia</p>
          </div>
        </div>
      </footer>
    </div>
  );
}