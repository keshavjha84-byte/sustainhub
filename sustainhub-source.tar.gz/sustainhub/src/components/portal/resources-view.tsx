'use client';

import { useState } from 'react';
import {
  BookOpen,
  GraduationCap,
  ChevronRight,
  CheckCircle2,
  Clock,
  ExternalLink,
  Zap,
  Globe,
  Scale,
  Shield,
  Lightbulb,
  Building2,
  Leaf,
  FileText,
  BarChart3,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { BRAND } from '@/lib/brand';

// ─── Types ────────────────────────────────────────────────────────────────

interface Lesson {
  id: string;
  title: string;
  content: string;
}

interface Module {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  lessons: Lesson[];
}

// ─── Learning Modules Data ────────────────────────────────────────────────

const MODULES: Module[] = [
  {
    id: 'intro-esg',
    title: 'Introduction to ESG',
    description:
      'Understand what ESG means, why it matters for Malaysian businesses, and how it connects to Bursa Malaysia\'s requirements.',
    icon: Globe,
    lessons: [
      {
        id: 'intro-esg-1',
        title: 'What is ESG?',
        content:
          'ESG stands for Environmental, Social, and Governance. It is a framework for evaluating how a company manages sustainability risks and opportunities beyond financial performance. The three pillars cover carbon footprint and resource use (Environmental), employee welfare and community impact (Social), and board oversight and ethics (Governance).',
      },
      {
        id: 'intro-esg-2',
        title: 'Why ESG Matters for Malaysian SMEs',
        content:
          'Bursa Malaysia\'s Enhanced Sustainability Reporting Guide (SEDG) requires Main Market listed issuers to publish annual sustainability statements. Even if your SME is not publicly listed, larger corporations are extending ESG expectations down their supply chain. Banks and green financing programmes also favour companies with strong sustainability practices.',
      },
      {
        id: 'intro-esg-3',
        title: 'The Three Pillars Explained',
        content:
          'Environmental covers your carbon footprint, energy consumption, water use, and waste management. Social addresses employee welfare, community engagement, training, and data privacy. Governance examines board composition, ethics policies, anti-corruption measures, and risk management.',
      },
      {
        id: 'intro-esg-4',
        title: 'ESG and Your Supply Chain',
        content:
          'Many Malaysian SMEs supply to larger listed companies that now require ESG data from their vendors. Being ESG-ready positions your business as a preferred supplier and can be a competitive advantage in tenders and contracts.',
      },
    ],
  },
  {
    id: 'ghg-emissions',
    title: 'Understanding GHG Emissions',
    description:
      'Learn about greenhouse gases, the three scopes of emissions, and how they apply to your business operations.',
    icon: Leaf,
    lessons: [
      {
        id: 'ghg-1',
        title: 'What Are Greenhouse Gases?',
        content:
          'Greenhouse gases (GHGs) trap heat in the atmosphere and drive climate change. The main gases are carbon dioxide (CO2), methane (CH4), and nitrous oxide (N2O). Emissions are measured in tonnes of CO2 equivalent (tCO2e), which converts all gases to a common unit based on their global warming potential.',
      },
      {
        id: 'ghg-2',
        title: 'Scope 1: Direct Emissions',
        content:
          'Scope 1 covers emissions from sources your company owns or controls directly. This includes combustion of diesel or petrol in company vehicles, on-site generators, natural gas for heating, and refrigerant leaks from air conditioning systems.',
      },
      {
        id: 'ghg-3',
        title: 'Scope 2: Indirect Energy Emissions',
        content:
          'Scope 2 covers emissions from the generation of purchased electricity, steam, heating, and cooling that your company consumes. For most Malaysian SMEs, this is electricity from TNB (Peninsular), SESB (Sabah), or Sarawak Energy.',
      },
      {
        id: 'ghg-4',
        title: 'Scope 3: Value Chain Emissions',
        content:
          'Scope 3 covers all other indirect emissions in your value chain. This includes business travel, employee commuting, waste disposal, purchased goods and services, transportation, and investments. Scope 3 is often the largest source of emissions but can be the most difficult to measure.',
      },
    ],
  },
  {
    id: 'ghg-accounting',
    title: 'GHG Accounting Methods',
    description:
      'Learn how to calculate your carbon footprint using established methodologies and Malaysia-specific emission factors.',
    icon: BarChart3,
    lessons: [
      {
        id: 'acc-1',
        title: 'The GHG Protocol',
        content:
          'The GHG Protocol is the most widely used international standard for greenhouse gas accounting. It provides frameworks for corporate emissions reporting at the organisational and project levels. SustainHub\'s calculator follows GHG Protocol methodology.',
      },
      {
        id: 'acc-2',
        title: 'Malaysian Grid Emission Factors',
        content:
          'Malaysia uses different emission factors for each electricity grid region. Peninsular Malaysia (TNB): 0.6332 kg CO2e/kWh. Sabah (SESB): 0.4138 kg CO2e/kWh. Sarawak (Sarawak Energy): 0.2450 kg CO2e/kWh. Sarawak has the lowest factor due to its hydroelectric power generation.',
      },
      {
        id: 'acc-3',
        title: 'Fuel Combustion Factors',
        content:
          'Common fuel emission factors used in Malaysia: Diesel (2.68 kg CO2e/litre), Petrol (2.31 kg CO2e/litre), Natural Gas (2.02 kg CO2e/kg), LPG (2.98 kg CO2e/kg). These factors are sourced from the GHG Protocol and IPCC guidelines.',
      },
      {
        id: 'acc-4',
        title: 'Reading Your TNB Bill',
        content:
          'To calculate Scope 2 emissions, find the total kWh consumed on your TNB bill. Look for the "Electricity Consumption" or "KWh Used" line. Note the billing period dates. Multiply the kWh by the appropriate grid factor (0.6332 for Peninsular Malaysia). SustainHub\'s calculator handles this automatically.',
      },
    ],
  },
  {
    id: 'sedg-framework',
    title: 'SEDG Reporting Framework',
    description:
      'Understand Bursa Malaysia\'s Sustainable Development Reporting Guide and how to complete the 35 SEDG indicators.',
    icon: Scale,
    lessons: [
      {
        id: 'sedg-1',
        title: 'What is SEDG?',
        content:
          'The Sustainable Development Reporting Guide (SEDG) is published by Bursa Malaysia. It sets out recommended ESG disclosures for listed companies. The guide covers 35 indicators across three pillars: Governance (12 indicators), Environmental (11 indicators), and Social (12 indicators).',
      },
      {
        id: 'sedg-2',
        title: 'Governance Indicators',
        content:
          'The 12 Governance indicators cover board composition and diversity, sustainability governance structure, code of conduct and ethics, anti-corruption policies, risk management, stakeholder engagement, and sustainability reporting practices. Strong governance is the foundation of credible ESG reporting.',
      },
      {
        id: 'sedg-3',
        title: 'Environmental Indicators',
        content:
          'The 11 Environmental indicators cover climate change mitigation (GHG emissions, energy consumption), resource use (water, materials), pollution prevention, and biodiversity. Most SMEs start with GHG emissions and energy consumption as these are the most measurable.',
      },
      {
        id: 'sedg-4',
        title: 'Social Indicators',
        content:
          'The 12 Social indicators cover employment practices, occupational health and safety, training and development, supply chain management, customer health and safety, and community engagement. These reflect your company\'s impact on people both inside and outside the organisation.',
      },
    ],
  },
  {
    id: 'report-writing',
    title: 'ESG Report Writing',
    description:
      'Learn how to compile and present your ESG data into a professional report that meets stakeholder expectations.',
    icon: FileText,
    lessons: [
      {
        id: 'rw-1',
        title: 'Structuring Your Report',
        content:
          'A good ESG report follows a clear structure: introduction, organisational profile, materiality assessment, governance overview, environmental performance data, social performance data, and future targets. Include both quantitative data (emissions figures, percentages) and qualitative narrative (policies, initiatives).',
      },
      {
        id: 'rw-2',
        title: 'Data Quality and Verification',
        content:
          'Ensure your data is accurate by using consistent measurement methods, documenting your assumptions and calculation methodologies, and keeping records of source data (utility bills, fuel receipts). Where exact data is unavailable, use reasonable estimates and clearly state the basis.',
      },
      {
        id: 'rw-3',
        title: 'Setting Targets and Tracking Progress',
        content:
          'Set specific, measurable ESG targets such as reducing emissions by 10% year-on-year, achieving 100% SEDG indicator completion, or transitioning to renewable energy. Track progress quarterly and report both achievements and areas for improvement.',
      },
    ],
  },
  {
    id: 'malaysia-regulations',
    title: 'Malaysian Regulatory Landscape',
    description:
      'Stay informed about Malaysia\'s sustainability policies, incentives, and compliance requirements.',
    icon: Building2,
    lessons: [
      {
        id: 'mr-1',
        title: 'Bursa Malaysia Requirements',
        content:
          'Bursa Malaysia requires Main Market listed issuers to publish annual sustainability statements. The Enhanced Sustainability Reporting Guide (SEDG) applies from financial years ending 31 December 2025 onwards. ACE Market issuers are encouraged to adopt sustainability reporting on a comply-or-explain basis.',
      },
      {
        id: 'mr-2',
        title: 'Government Incentives for SMEs',
        content:
          'The Malaysian government offers several incentives for SMEs adopting sustainable practices: Green Technology Financing Scheme (GTFS) by Bank Negara Malaysia, Green Investment Tax Allowance (GITA), and grants through MGTC and SME Corp. Early adoption of ESG practices can help you qualify for these programmes.',
      },
      {
        id: 'mr-3',
        title: 'International Standards Relevance',
        content:
          'While SEDG is the primary framework in Malaysia, international standards like GRI (Global Reporting Initiative), TCFD (Task Force on Climate-related Financial Disclosures), and ISSB (International Sustainability Standards Board) are increasingly referenced. Understanding these can help if you deal with international partners or plan to list on foreign exchanges.',
      },
    ],
  },
];

// ─── Glossary Data ────────────────────────────────────────────────────────

const GLOSSARY_TERMS = [
  {
    term: 'Scope 1 Emissions',
    definition:
      'Direct GHG emissions from sources owned or controlled by the company (e.g., company vehicles, on-site fuel combustion).',
  },
  {
    term: 'Scope 2 Emissions',
    definition:
      'Indirect GHG emissions from the generation of purchased electricity, steam, heating, and cooling consumed by the company.',
  },
  {
    term: 'Scope 3 Emissions',
    definition:
      'All other indirect GHG emissions in a company\'s value chain, including business travel, employee commuting, and purchased goods.',
  },
  {
    term: 'GHG Protocol',
    definition:
      "The world's most widely used greenhouse gas accounting standards. Provides frameworks for measuring and managing emissions.",
  },
  {
    term: 'tCO2e',
    definition:
      'Tonnes of carbon dioxide equivalent. A standard unit for measuring carbon footprint, converting all GHGs to CO2 equivalent.',
  },
  {
    term: 'SEDG',
    definition:
      'Sustainable Development Reporting Guide published by Bursa Malaysia. Sets out the recommended ESG disclosures for listed companies.',
  },
  {
    term: 'GRI',
    definition:
      'Global Reporting Initiative. An international independent standards organisation for sustainability reporting.',
  },
  {
    term: 'TCFD',
    definition:
      'Task Force on Climate-related Financial Disclosures. Provides recommendations for climate-related financial risk disclosures.',
  },
  {
    term: 'ISSB',
    definition:
      'International Sustainability Standards Board. Develops global sustainability disclosure standards for capital markets.',
  },
  {
    term: 'Materiality',
    definition:
      'The principle that companies should report on the sustainability topics that matter most to their business and stakeholders.',
  },
  {
    term: 'PDPA',
    definition:
      'Personal Data Protection Act 2010. Malaysia\'s law governing the processing of personal data.',
  },
  {
    term: 'GTFS',
    definition:
      'Green Technology Financing Scheme. A Bank Negara Malaysia programme providing preferential financing for green technology projects.',
  },
];

// ─── Emission Factors Data ────────────────────────────────────────────────

const SCOPE1_FACTORS = [
  { fuel: 'Diesel', factor: '2.68', unit: 'kg CO2e / litre' },
  { fuel: 'Petrol (Gasoline)', factor: '2.31', unit: 'kg CO2e / litre' },
  { fuel: 'Natural Gas', factor: '2.02', unit: 'kg CO2e / kg' },
  { fuel: 'LPG', factor: '2.98', unit: 'kg CO2e / kg' },
];

const SCOPE2_FACTORS = [
  { grid: 'Peninsular Malaysia (TNB)', factor: '0.6332', unit: 'kg CO2e / kWh' },
  { grid: 'Sabah (SESB)', factor: '0.4138', unit: 'kg CO2e / kWh' },
  { grid: 'Sarawak (Sarawak Energy)', factor: '0.2450', unit: 'kg CO2e / kWh' },
];

// ─── External Resources Data ──────────────────────────────────────────────

const EXTERNAL_RESOURCES = [
  {
    title: 'Bursa Malaysia Sustainability Guide',
    url: 'https://www.bursamalaysia.com/trading/sustainability',
    description:
      'Official sustainability resources, policies, and reporting requirements from Bursa Malaysia.',
    icon: Scale,
  },
  {
    title: 'SEDG Portal',
    url: 'https://sedg.bursamalaysia.com',
    description:
      'The dedicated portal for Bursa Malaysia\'s Sustainable Development Reporting Guide and related resources.',
    icon: Globe,
  },
  {
    title: 'Malaysian Green Technology & Climate Change Corp (MGTC)',
    url: 'https://www.greentechmalaysia.my',
    description:
      'National green technology agency driving Malaysia\'s transition to a low-carbon economy.',
    icon: Zap,
  },
  {
    title: 'SME Corp Malaysia',
    url: 'https://www.smecorp.gov.my',
    description:
      'Central coordinating agency for SME development in Malaysia with grants, programmes, and advisory services.',
    icon: Shield,
  },
  {
    title: 'Malaysia Climate Change Centre',
    url: 'https://www.climatechange.my',
    description:
      'National focal point for climate change knowledge, research, and capacity building in Malaysia.',
    icon: Leaf,
  },
  {
    title: 'Department of Environment (DOE) Malaysia',
    url: 'https://www.doe.gov.my',
    description:
      'Federal department under the Ministry of Natural Resources and Environmental Sustainability responsible for environmental regulations.',
    icon: Building2,
  },
];

// ─── Main Component ───────────────────────────────────────────────────────

export default function ResourcesView() {
  const totalLessons = MODULES.reduce((sum, m) => sum + m.lessons.length, 0);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(
    new Set()
  );

  const toggleLesson = (lessonId: string) => {
    setCompletedLessons((prev) => {
      const next = new Set(prev);
      if (next.has(lessonId)) {
        next.delete(lessonId);
      } else {
        next.add(lessonId);
      }
      return next;
    });
  };

  const progressPercent =
    totalLessons > 0
      ? Math.round((completedLessons.size / totalLessons) * 100)
      : 0;

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight md:text-3xl flex items-center gap-2">
          <GraduationCap className="h-7 w-7 text-primary" />
          Education &amp; Learning Centre
        </h1>
        <p className="text-muted-foreground mt-1">
          Learn ESG reporting, GHG accounting, and Malaysian sustainability
          regulations at your own pace
        </p>
      </div>

      {/* Overall progress bar */}
      <Card className="border-dashed">
        <CardContent className="py-4 px-6">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="font-medium">Your Learning Progress</span>
            <span className="text-muted-foreground">
              {completedLessons.size} of {totalLessons} lessons completed
            </span>
          </div>
          <Progress value={progressPercent} className="h-2.5" />
          <p className="text-xs text-muted-foreground mt-1.5">
            {progressPercent === 100
              ? 'Well done! You have completed all lessons.'
              : `${100 - progressPercent}% remaining to complete the programme.`}
          </p>
        </CardContent>
      </Card>

      <Separator />

      {/* Tabbed content */}
      <Tabs defaultValue="modules" className="w-full">
        <TabsList className="w-full sm:w-auto grid grid-cols-3 mb-6">
          <TabsTrigger value="modules" className="gap-1.5 text-xs sm:text-sm">
            <BookOpen className="h-4 w-4 hidden sm:block" />
            Learning Modules
          </TabsTrigger>
          <TabsTrigger value="reference" className="gap-1.5 text-xs sm:text-sm">
            <Lightbulb className="h-4 w-4 hidden sm:block" />
            Quick Reference
          </TabsTrigger>
          <TabsTrigger value="external" className="gap-1.5 text-xs sm:text-sm">
            <ExternalLink className="h-4 w-4 hidden sm:block" />
            External Resources
          </TabsTrigger>
        </TabsList>

        {/* ── Tab 1: Learning Modules ──────────────────────────────────── */}
        <TabsContent value="modules" className="space-y-4">
          <div className="grid gap-4">
            {MODULES.map((mod) => {
              const ModIcon = mod.icon;
              const completedInModule = mod.lessons.filter((l) =>
                completedLessons.has(l.id)
              ).length;
              const moduleProgress =
                mod.lessons.length > 0
                  ? Math.round(
                      (completedInModule / mod.lessons.length) * 100
                    )
                  : 0;

              return (
                <Card key={mod.id} className="overflow-hidden">
                  <Accordion type="single" collapsible>
                    <AccordionItem value={mod.id} className="border-0">
                      {/* Module header row */}
                      <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-accent/50 transition-colors">
                        <div className="flex items-start gap-3 text-left flex-1">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                            <ModIcon className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <CardTitle className="text-base font-semibold">
                                {mod.title}
                              </CardTitle>
                              <Badge
                                variant={
                                  moduleProgress === 100
                                    ? 'default'
                                    : 'secondary'
                                }
                                className="text-xs"
                              >
                                {completedInModule}/{mod.lessons.length}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">
                              {mod.description}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              <Progress
                                value={moduleProgress}
                                className="h-1.5 w-24"
                              />
                              <span className="text-xs text-muted-foreground">
                                {moduleProgress}%
                              </span>
                            </div>
                          </div>
                        </div>
                      </AccordionTrigger>

                      {/* Expandable lessons */}
                      <AccordionContent className="px-6 pb-4">
                        <div className="space-y-3">
                          {mod.lessons.map((lesson, idx) => {
                            const isCompleted = completedLessons.has(
                              lesson.id
                            );
                            return (
                              <div
                                key={lesson.id}
                                className={`rounded-lg border p-4 transition-colors ${
                                  isCompleted
                                    ? 'bg-primary/5 border-primary/20'
                                    : 'bg-muted/50 border-transparent'
                                }`}
                              >
                                <div className="flex items-start gap-3">
                                  <Checkbox
                                    id={lesson.id}
                                    checked={isCompleted}
                                    onCheckedChange={() =>
                                      toggleLesson(lesson.id)
                                    }
                                    className="mt-0.5"
                                    aria-label={`Mark "${lesson.title}" as completed`}
                                  />
                                  <div className="flex-1 min-w-0">
                                    <label
                                      htmlFor={lesson.id}
                                      className="text-sm font-medium leading-tight cursor-pointer flex items-center gap-2"
                                    >
                                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-semibold text-muted-foreground">
                                        {idx + 1}
                                      </span>
                                      {lesson.title}
                                      {isCompleted && (
                                        <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                                      )}
                                    </label>
                                    <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                                      {lesson.content}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* ── Tab 2: Quick Reference ────────────────────────────────────── */}
        <TabsContent value="reference" className="space-y-6">
          {/* ESG Glossary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <BookOpen className="h-5 w-5 text-primary" />
                ESG Glossary
                <Badge variant="secondary" className="ml-auto text-xs">
                  {GLOSSARY_TERMS.length} terms
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-0 md:gap-4">
                <div className="md:rounded-lg md:border md:p-2">
                  <Accordion type="multiple" className="w-full">
                    {GLOSSARY_TERMS
                      .slice(0, Math.ceil(GLOSSARY_TERMS.length / 2))
                      .map((item) => (
                        <GlossaryItem
                          key={item.term}
                          term={item.term}
                          definition={item.definition}
                        />
                      ))}
                  </Accordion>
                </div>
                <div className="md:rounded-lg md:border md:p-2">
                  <Accordion type="multiple" className="w-full">
                    {GLOSSARY_TERMS
                      .slice(Math.ceil(GLOSSARY_TERMS.length / 2))
                      .map((item) => (
                        <GlossaryItem
                          key={item.term}
                          term={item.term}
                          definition={item.definition}
                        />
                      ))}
                  </Accordion>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* How to Read Your TNB Bill */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Zap className="h-5 w-5 text-primary" />
                How to Read Your TNB Bill for GHG Reporting
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground mb-4">
                To calculate your Scope 2 emissions, you need your total
                electricity consumption in kilowatt-hours (kWh) from your
                Tenaga Nasional Berhad (TNB) bill. Follow these steps:
              </p>
              <ul className="space-y-3">
                {[
                  {
                    title: 'Locate the "Current Charge" section',
                    desc: 'On your TNB bill, find the section that breaks down your charges. Look for the line labelled "Electricity Consumption" or "KWh Used."',
                  },
                  {
                    title: 'Find the total kWh consumed',
                    desc: 'The bill will show the current reading minus the previous reading, giving you the total kWh consumed for the billing period. This is the number you need.',
                  },
                  {
                    title: 'Note the billing period dates',
                    desc: 'Record the start and end dates of the billing period so you can match your emissions calculation to the correct reporting period (e.g., quarterly or annually).',
                  },
                  {
                    title: 'Apply the grid emission factor',
                    desc: 'Multiply your kWh by the appropriate Malaysian grid emission factor: Peninsular (0.6332 kg CO2e/kWh), Sabah (0.4138), or Sarawak (0.2450). SustainHub\'s calculator handles this automatically.',
                  },
                ].map((item, idx) => (
                  <li key={idx} className="flex gap-3 text-sm">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                      {idx + 1}
                    </span>
                    <div>
                      <p className="font-medium text-foreground">
                        {item.title}
                      </p>
                      <p className="text-muted-foreground">{item.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Emission Factors Quick Reference */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <BarChart3 className="h-5 w-5 text-primary" />
                Emission Factors Quick Reference
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Scope 1 */}
              <div>
                <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <Badge variant="outline" className="font-mono text-xs">
                    Scope 1
                  </Badge>
                  Fuel Combustion Factors
                </h3>
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead className="font-semibold">Fuel Type</TableHead>
                        <TableHead className="font-semibold text-right">
                          Emission Factor
                        </TableHead>
                        <TableHead className="font-semibold text-right hidden sm:table-cell">
                          Unit
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {SCOPE1_FACTORS.map((row) => (
                        <TableRow key={row.fuel}>
                          <TableCell className="font-medium">
                            {row.fuel}
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {row.factor}
                          </TableCell>
                          <TableCell className="text-right text-muted-foreground hidden sm:table-cell">
                            {row.unit}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Scope 2 */}
              <div>
                <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <Badge variant="outline" className="font-mono text-xs">
                    Scope 2
                  </Badge>
                  Grid Emission Factors
                </h3>
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead className="font-semibold">Grid Region</TableHead>
                        <TableHead className="font-semibold text-right">
                          Emission Factor
                        </TableHead>
                        <TableHead className="font-semibold text-right hidden sm:table-cell">
                          Unit
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {SCOPE2_FACTORS.map((row) => (
                        <TableRow key={row.grid}>
                          <TableCell className="font-medium">
                            {row.grid}
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {row.factor}
                          </TableCell>
                          <TableCell className="text-right text-muted-foreground hidden sm:table-cell">
                            {row.unit}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <p className="text-xs text-muted-foreground">
                Sources: GHG Protocol, IPCC Guidelines, Malaysia Energy
                Commission. Factors used by {BRAND.name}&apos;s calculator.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab 3: External Resources ─────────────────────────────────── */}
        <TabsContent value="external" className="space-y-6">
          <p className="text-sm text-muted-foreground">
            Official government and regulatory resources for Malaysian
            sustainability compliance. These links open in a new tab.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {EXTERNAL_RESOURCES.map((resource) => {
              const IconComp = resource.icon;
              return (
                <a
                  key={resource.url}
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group rounded-lg border p-4 transition-colors hover:bg-accent"
                >
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
                      <IconComp className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0 space-y-1.5">
                      <p className="text-sm font-medium leading-tight group-hover:text-primary transition-colors">
                        {resource.title}
                      </p>
                      <p className="text-xs text-muted-foreground line-clamp-3">
                        {resource.description}
                      </p>
                      <span className="inline-flex items-center gap-1 text-xs text-primary font-medium">
                        Visit website
                        <ExternalLink className="h-3 w-3" />
                      </span>
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ─── Helper: Glossary Item ────────────────────────────────────────────────

function GlossaryItem({
  term,
  definition,
}: {
  term: string;
  definition: string;
}) {
  return (
    <AccordionItem value={term}>
      <AccordionTrigger className="text-sm font-medium hover:no-underline">
        {term}
      </AccordionTrigger>
      <AccordionContent className="text-sm text-muted-foreground">
        {definition}
      </AccordionContent>
    </AccordionItem>
  );
}