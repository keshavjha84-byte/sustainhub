'use client';

import type { ReactNode } from 'react';
import { Sidebar } from './sidebar';
import { PortalHeader } from './portal-header';

interface PortalLayoutProps {
  children: ReactNode;
  companyData: { companyName: string; companySize: string } | null;
}

export function PortalLayout({ children, companyData }: PortalLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar companyData={companyData} />

      {/* Main content area, offset on desktop to accommodate fixed sidebar */}
      <div className="flex min-h-screen flex-col lg:pl-[260px] transition-[padding] duration-300 ease-in-out">
        {/* Top header bar */}
        <PortalHeader />

        {/* Page content */}
        <main className="flex-1">
          <div className="mx-auto w-full max-w-7xl p-4 md:p-6 lg:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
