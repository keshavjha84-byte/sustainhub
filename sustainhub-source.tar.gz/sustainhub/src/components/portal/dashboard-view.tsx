"use client";

import { useQuery } from "@tanstack/react-query";
import {
  TrendingUp,
  Leaf,
  Shield,
  Users,
  ArrowRight,
  FileBarChart,
  Activity,
  CheckCircle,
  AlertTriangle,
  Loader2,
  Calculator,
  ClipboardList,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Bar, BarChart, XAxis, YAxis, Cell } from "recharts";
import type { PortalView } from "@/types";

// ── Types ───────────────────────────────────────────────────────────
interface DashboardData {
  esgReadinessScore: number;
  totalEmissions: number | null;
  latestReportingPeriod: string | null;
  completedIndicators: number;
  totalIndicators: number;
  sectionProgress: {
    governance: number;
    environmental: number;
    social: number;
  };
  recentActivity: {
    id: string;
    action: string;
    timestamp: string;
    type: "ghg" | "esg" | "system";
  }[];
  nextAction: {
    label: string;
    view: PortalView;
  } | null;
  company: {
    companyName: string;
    industrySector: string;
  } | null;
}

interface DashboardViewProps {
  userId: string;
  onNavigate: (view: PortalView) => void;
}

// ── Helpers ─────────────────────────────────────────────────────────
function getScoreColor(score: number): string {
  if (score < 30) return "text-red-500";
  if (score <= 60) return "text-amber-500";
  return "text-emerald-500";
}

function getScoreStrokeColor(score: number): string {
  if (score < 30) return "#ef4444";
  if (score <= 60) return "#f59e0b";
  return "#10b981";
}

function getScoreBgColor(score: number): string {
  if (score < 30) return "bg-red-500/10 border-red-500/20";
  if (score <= 60) return "bg-amber-500/10 border-amber-500/20";
  return "bg-emerald-500/10 border-emerald-500/20";
}

function getScoreLabel(score: number): string {
  if (score < 30) return "Getting Started";
  if (score <= 60) return "In Progress";
  return "On Track";
}

function getScoreBadgeVariant(score: number): "destructive" | "secondary" | "default" {
  if (score < 30) return "destructive";
  if (score <= 60) return "secondary";
  return "default";
}

function formatNumber(num: number): string {
  if (num >= 1000) return (num / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  return num.toLocaleString();
}

function formatTimestamp(ts: string): string {
  const date = new Date(ts);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString("en-MY", { day: "numeric", month: "short" });
}

function getActivityIcon(type: string) {
  switch (type) {
    case "ghg":
      return <Leaf className="h-4 w-4 text-emerald-600" />;
    case "esg":
      return <Shield className="h-4 w-4 text-teal-600" />;
    default:
      return <Activity className="h-4 w-4 text-muted-foreground" />;
  }
}

const sectionChartConfig = {
  governance: { label: "Governance", color: "#14b8a6" },
  environmental: { label: "Environmental", color: "#22c55e" },
  social: { label: "Social", color: "#f59e0b" },
};

// ── Circular Progress Component ─────────────────────────────────────
function CircularProgress({ value, size = 100, strokeWidth = 8 }: { value: number; size?: number; strokeWidth?: number }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;
  const color = getScoreStrokeColor(value);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-muted/30"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-700 ease-out"
        />
      </svg>
      <span className={`absolute text-2xl font-bold ${getScoreColor(value)}`}>
        {Math.round(value)}%
      </span>
    </div>
  );
}

// ── Loading Skeleton ────────────────────────────────────────────────
function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      {/* Stat cards skeleton */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="gap-4">
            <CardHeader className="pb-0">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-10 w-20 mb-2" />
              <Skeleton className="h-3 w-16" />
            </CardContent>
          </Card>
        ))}
      </div>
      {/* Middle section skeleton */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <Skeleton className="h-5 w-40" />
          </CardHeader>
          <CardContent className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-3 w-full" />
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <Skeleton className="h-5 w-32" />
          </CardHeader>
          <CardContent className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3">
                <Skeleton className="h-8 w-8 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      {/* Quick actions skeleton */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i} className="gap-4">
            <CardContent className="flex items-center gap-3">
              <Skeleton className="h-10 w-10 rounded-lg" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-20" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ── Main Component ──────────────────────────────────────────────────
export default function DashboardView({ userId, onNavigate }: DashboardViewProps) {
  const { data, isLoading, isError } = useQuery<DashboardData>({
    queryKey: ["dashboard", userId],
    queryFn: async () => {
      const res = await fetch(`/api/dashboard?userId=${userId}`);
      if (!res.ok) throw new Error("Failed to fetch dashboard data");
      return res.json();
    },
    refetchOnWindowFocus: false,
  });

  if (isLoading) return <DashboardSkeleton />;

  if (isError || !data) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
        <h3 className="text-lg font-semibold mb-1">Unable to Load Dashboard</h3>
        <p className="text-sm text-muted-foreground max-w-md">
          We couldn&apos;t retrieve your dashboard data. Please try again later or complete your onboarding to get started.
        </p>
        <Button variant="outline" className="mt-4" onClick={() => onNavigate("onboarding")}>
          Complete Onboarding
        </Button>
      </div>
    );
  }

  const hasAnyData = data.totalEmissions !== null || data.completedIndicators > 0 || data.esgReadinessScore > 0;

  return (
    <div className="space-y-6">
      {/* Welcome header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          Welcome back{data.company ? `, ${data.company.companyName}` : ""}
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Here&apos;s an overview of your ESG compliance progress.
        </p>
      </div>

      {/* ── Top Row: 4 Stat Cards ─────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. ESG Readiness Score */}
        <Card className="gap-2">
          <CardHeader className="pb-0">
            <CardDescription className="flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5" />
              ESG Readiness
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center pb-2">
            <CircularProgress value={data.esgReadinessScore} size={96} strokeWidth={8} />
            <Badge
              variant={getScoreBadgeVariant(data.esgReadinessScore)}
              className="mt-2"
            >
              {getScoreLabel(data.esgReadinessScore)}
            </Badge>
          </CardContent>
        </Card>

        {/* 2. GHG Emissions */}
        <Card className="gap-2">
          <CardHeader className="pb-0">
            <CardDescription className="flex items-center gap-1.5">
              <Leaf className="h-3.5 w-3.5" />
              GHG Emissions
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            {data.totalEmissions !== null ? (
              <>
                <p className="text-3xl lg:text-4xl font-bold tracking-tight">
                  {formatNumber(data.totalEmissions)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">tCO₂e total</p>
                {data.latestReportingPeriod && (
                  <Badge variant="outline" className="mt-2 text-xs">
                    {data.latestReportingPeriod}
                  </Badge>
                )}
              </>
            ) : (
              <div className="flex flex-col items-center justify-center py-2 text-center">
                <p className="text-3xl font-bold text-muted-foreground/30">0.00</p>
                <p className="text-xs text-muted-foreground mt-1">tCO2e</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 3. SEDG Completion */}
        <Card className="gap-2">
          <CardHeader className="pb-0">
            <CardDescription className="flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5" />
              SEDG Completion
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <div className="flex items-baseline gap-1">
              <span className="text-3xl lg:text-4xl font-bold tracking-tight">
                {data.completedIndicators}
              </span>
              <span className="text-lg text-muted-foreground">
                /{data.totalIndicators}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">indicators completed</p>
            <div className="mt-3 h-2 w-full rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-teal-500 transition-all duration-500"
                style={{
                  width: `${data.totalIndicators > 0 ? (data.completedIndicators / data.totalIndicators) * 100 : 0}%`,
                }}
              />
            </div>
          </CardContent>
        </Card>

        {/* 4. Next Action */}
        <Card className="gap-2">
          <CardHeader className="pb-0">
            <CardDescription className="flex items-center gap-1.5">
              <Activity className="h-3.5 w-3.5" />
              Next Action
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col justify-between pb-2 h-full">
            {data.nextAction ? (
              <>
                <p className="text-sm font-medium leading-snug">
                  {data.nextAction.label}
                </p>
                <Button
                  size="sm"
                  className="mt-3 w-full"
                  onClick={() => onNavigate(data.nextAction!.view)}
                >
                  Get Started
                  <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                </Button>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center py-2 text-center">
                <CheckCircle className="h-6 w-6 text-emerald-500 mb-1" />
                <p className="text-sm text-muted-foreground">All caught up!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Middle Section ─────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: ESG Section Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">ESG Section Progress</CardTitle>
            <CardDescription>Completion across the three ESG pillars</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {hasAnyData ? (
              <>
                <ChartContainer config={sectionChartConfig} className="h-48 w-full">
                  <BarChart
                    layout="vertical"
                    data={[
                      { section: "Governance", value: data.sectionProgress.governance, fill: "#14b8a6" },
                      { section: "Environmental", value: data.sectionProgress.environmental, fill: "#22c55e" },
                      { section: "Social", value: data.sectionProgress.social, fill: "#f59e0b" },
                    ]}
                    margin={{ top: 4, right: 16, left: 4, bottom: 4 }}
                  >
                    <XAxis type="number" domain={[0, 100]} tickFormatter={(v) => `${v}%`} hide />
                    <YAxis
                      type="category"
                      dataKey="section"
                      width={100}
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <ChartTooltip
                      content={
                        <ChartTooltipContent
                          formatter={(value) => `${value}%`}
                          hideLabel
                        />
                      }
                    />
                    <Bar
                      dataKey="value"
                      radius={[0, 6, 6, 0]}
                      barSize={24}
                    >
                      {[
                        { fill: "#14b8a6" },
                        { fill: "#22c55e" },
                        { fill: "#f59e0b" },
                      ].map((entry, index) => (
                        <Cell key={index} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ChartContainer>
                <div className="flex justify-between text-xs text-muted-foreground px-1">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-sm bg-teal-500" />
                    Governance {Math.round(data.sectionProgress.governance)}%
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-sm bg-green-500" />
                    Environmental {Math.round(data.sectionProgress.environmental)}%
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-sm bg-amber-500" />
                    Social {Math.round(data.sectionProgress.social)}%
                  </span>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-center">
                <Shield className="h-8 w-8 text-muted-foreground/40 mb-2" />
                <p className="text-sm text-muted-foreground">
                  Complete your ESG questionnaire to see section progress.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => onNavigate("esg-questionnaire")}
                >
                  Start Questionnaire
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right: Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Activity</CardTitle>
            <CardDescription>Your latest actions and updates</CardDescription>
          </CardHeader>
          <CardContent>
            {data.recentActivity && data.recentActivity.length > 0 ? (
              <div className="space-y-4">
                {data.recentActivity.slice(0, 3).map((activity, idx) => (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className="relative mt-0.5">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                        {getActivityIcon(activity.type)}
                      </div>
                      {idx < data.recentActivity.length - 1 && (
                        <div className="absolute top-8 left-1/2 -translate-x-1/2 h-full w-px bg-border" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0 pb-4">
                      <p className="text-sm font-medium leading-snug">{activity.action}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {formatTimestamp(activity.timestamp)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-center">
                <Activity className="h-8 w-8 text-muted-foreground/40 mb-2" />
                <p className="text-sm text-muted-foreground">
                  No activity yet. Start by calculating your emissions or filling out the questionnaire.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Bottom Section: Quick Actions ──────────────────────── */}
      <div>
        <h2 className="text-base font-semibold mb-3">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Calculate Emissions */}
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow group"
            onClick={() => onNavigate("ghg-calculator")}
          >
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-600 group-hover:bg-emerald-500/20 transition-colors">
                <Calculator className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">Calculate Emissions</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Measure your carbon footprint
                </p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
            </CardContent>
          </Card>

          {/* Complete Questionnaire */}
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow group"
            onClick={() => onNavigate("esg-questionnaire")}
          >
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-teal-500/10 text-teal-600 group-hover:bg-teal-500/20 transition-colors">
                <ClipboardList className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">Complete Questionnaire</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Fill in SEDG indicators
                </p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
            </CardContent>
          </Card>

          {/* View Report */}
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow group"
            onClick={() => onNavigate("reports")}
          >
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-violet-500/10 text-violet-600 group-hover:bg-violet-500/20 transition-colors">
                <FileBarChart className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">View Report</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Generate your ESG report
                </p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}