'use client';

import {
  LayoutDashboard,
  Leaf,
  ClipboardList,
  FileBarChart,
  BookOpen,
  CreditCard,
  Sun,
  Moon,
  LogOut,
  X,
} from 'lucide-react';
import { SustainHubLogo } from '@/components/brand/logo';
import { useTheme } from 'next-themes';
import { usePortalStore } from '@/store/portal';
import { useAuthStore } from '@/store/auth';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Sheet,
  SheetContent,
  SheetTitle,
} from '@/components/ui/sheet';
import type { PortalView } from '@/types';

/* ------------------------------------------------------------------ */
/*  Navigation items                                                    */
/* ------------------------------------------------------------------ */
interface NavItem {
  view: PortalView;
  label: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { view: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { view: 'ghg-calculator', label: 'GHG Calculator', icon: Leaf },
  { view: 'esg-questionnaire', label: 'ESG Questionnaire', icon: ClipboardList },
  { view: 'reports', label: 'Reports', icon: FileBarChart },
  { view: 'resources', label: 'Resources', icon: BookOpen },
  { view: 'subscription', label: 'Subscription', icon: CreditCard },
];

/* ------------------------------------------------------------------ */
/*  Company size badge colours                                          */
/* ------------------------------------------------------------------ */
const sizeBadgeColor: Record<string, string> = {
  Micro: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
  Small: 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300',
  Medium: 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
  Large: 'bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300',
};

/* ------------------------------------------------------------------ */
/*  Props                                                               */
/* ------------------------------------------------------------------ */
interface SidebarProps {
  companyData: { companyName: string; companySize: string } | null;
}

/* ------------------------------------------------------------------ */
/*  SidebarNav (shared nav list rendered inside both desktop & Sheet) */
/* ------------------------------------------------------------------ */
function SidebarNav({ onSelect, activeView }: { onSelect: (v: PortalView) => void; activeView: PortalView }) {
  return (
    <nav className="flex flex-col gap-1 px-3" role="navigation" aria-label="Portal navigation">
      {navItems.map((item) => {
        const isActive = activeView === item.view;
        const Icon = item.icon;

        return (
          <Tooltip key={item.view}>
            <TooltipTrigger asChild>
              <button
                onClick={() => onSelect(item.view)}
                className={`
                  group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium
                  transition-colors cursor-pointer
                  ${
                    isActive
                      ? 'bg-primary/10 text-primary'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                  }
                `}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon className="size-[18px] shrink-0" />
                <span>{item.label}</span>
              </button>
            </TooltipTrigger>
            <TooltipContent side="right" sideOffset={8}>
              {item.label}
            </TooltipContent>
          </Tooltip>
        );
      })}
    </nav>
  );
}

/* ------------------------------------------------------------------ */
/*  SidebarBottom (user info, theme toggle, logout)                    */
/* ------------------------------------------------------------------ */
function SidebarBottom() {
  const { theme, setTheme } = useTheme();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const setView = usePortalStore((s) => s.setView);

  const userInitials = user?.name
    ? user.name
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2)
    : 'U';

  const handleLogout = () => {
    logout();
    setView('landing');
  };

  return (
    <div className="mt-auto flex flex-col gap-2 px-3 pb-4">
      <Separator />

      {/* Theme toggle */}
      <Button
        variant="ghost"
        size="sm"
        className="w-full justify-start gap-3 text-muted-foreground"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      >
        {theme === 'dark' ? <Sun className="size-[18px]" /> : <Moon className="size-[18px]" />}
        <span className="text-sm font-medium">{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
      </Button>

      {/* User info */}
      <div className="flex items-center gap-3 rounded-lg px-3 py-2">
        <Avatar className="size-8 shrink-0">
          <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
            {userInitials}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-1 flex-col overflow-hidden">
          <span className="truncate text-sm font-medium leading-tight">
            {user?.name ?? 'User'}
          </span>
          <span className="truncate text-xs text-muted-foreground">
            {user?.email ?? ''}
          </span>
        </div>
      </div>

      {/* Logout */}
      <Button
        variant="ghost"
        size="sm"
        className="w-full justify-start gap-3 text-muted-foreground hover:text-destructive"
        onClick={handleLogout}
      >
        <LogOut className="size-[18px]" />
        <span className="text-sm font-medium">Sign Out</span>
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Sidebar component                                              */
/* ------------------------------------------------------------------ */
export function Sidebar({ companyData }: SidebarProps) {
  const currentView = usePortalStore((s) => s.currentView);
  const sidebarOpen = usePortalStore((s) => s.sidebarOpen);
  const setView = usePortalStore((s) => s.setView);
  const setSidebarOpen = usePortalStore((s) => s.setSidebarOpen);

  const handleNavSelect = (view: PortalView) => {
    setView(view);
    setSidebarOpen(false); // close mobile sheet on navigation
  };

  /* ---- Shared content rendered in both desktop sidebar and Sheet ---- */
  const sidebarContent = (
    <div className="flex h-full flex-col">
      {/* Company branding header */}
      <div className="flex items-center gap-2 px-4 pt-5 pb-3">
        <SustainHubLogo size="sm" showText={false} />
        <div className="flex flex-col overflow-hidden">
          <span className="truncate text-sm font-semibold text-sidebar-foreground">
            {companyData?.companyName ?? 'SustainHub Portal'}
          </span>
          {companyData?.companySize && (
            <Badge
              variant="secondary"
              className={`mt-0.5 w-fit text-[10px] px-1.5 py-0 border-0 ${sizeBadgeColor[companyData.companySize] ?? ''}`}
            >
              {companyData.companySize}
            </Badge>
          )}
        </div>
      </div>

      <Separator className="mx-3 w-auto" />

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto py-3">
        <SidebarNav onSelect={handleNavSelect} activeView={currentView} />
      </div>

      {/* Bottom section */}
      <SidebarBottom />
    </div>
  );

  return (
    <>
      {/* ---- Desktop sidebar (always visible on lg+) ---- */}
      <aside
        className={`
          fixed inset-y-0 left-0 z-40 hidden lg:flex flex-col
          w-[260px] border-r border-sidebar-border bg-sidebar
          transition-transform duration-300 ease-in-out
        `}
        aria-label="Portal sidebar"
      >
        {sidebarContent}
      </aside>

      {/* ---- Mobile sidebar (Sheet overlay) ---- */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent
          side="left"
          className="w-[260px] max-w-[80vw] p-0 bg-sidebar border-sidebar-border"
        >
          {/* Accessible title for Sheet (visually hidden) */}
          <SheetTitle className="sr-only">Navigation Menu</SheetTitle>

          {/* Close button inside sheet */}
          <button
            onClick={() => setSidebarOpen(false)}
            className="absolute top-3 right-3 z-10 rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
            aria-label="Close menu"
          >
            <X className="size-4" />
          </button>

          {sidebarContent}
        </SheetContent>
      </Sheet>
    </>
  );
}
