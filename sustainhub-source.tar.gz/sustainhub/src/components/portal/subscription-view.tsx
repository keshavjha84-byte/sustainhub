'use client';

import { useEffect, useState } from 'react';
import {
  Check,
  Star,
  Zap,
  Building,
  HelpCircle,
  Shield,
  CreditCard,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { SUBSCRIPTION_PLANS } from '@/data/constants';
import { useToast } from '@/hooks/use-toast';

// ─── FAQ data ────────────────────────────────────────────────────────────────

const FAQ_ITEMS = [
  {
    question: 'Can I change my plan later?',
    answer: 'Yes, you can upgrade or downgrade at any time.',
  },
  {
    question: 'Is there a free trial?',
    answer: 'The Starter plan is free forever with basic features.',
  },
  {
    question: 'What payment methods do you accept?',
    answer:
      'We accept online banking (FPX), credit/debit cards, and bank transfers.',
  },
  {
    question: 'Do you offer discounts for annual billing?',
    answer: 'Yes! Annual billing saves you 20%. Contact us for details.',
  },
  {
    question: 'Is my data secure?',
    answer:
      'Absolutely. All data is encrypted and stored securely. We comply with PDPA regulations.',
  },
];

// ─── Plan icon mapping ───────────────────────────────────────────────────────

const PLAN_ICONS: Record<string, React.ElementType> = {
  Starter: Zap,
  Professional: Star,
  Enterprise: Building,
};

// ─── Props ───────────────────────────────────────────────────────────────────

interface SubscriptionViewProps {
  userId: string;
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function SubscriptionView({ userId }: SubscriptionViewProps) {
  const { toast } = useToast();
  const [currentPlanId, setCurrentPlanId] = useState<string | null>(null);
  const [switching, setSwitching] = useState(false);

  // Fetch the user's current subscription
  useEffect(() => {
    async function fetchSubscription() {
      try {
        const res = await fetch(`/api/subscription?userId=${userId}`);
        if (res.ok) {
          const data = await res.json();
          setCurrentPlanId(data.plan);
        }
      } catch {
        // Silently fail, user will see all plans as upgradeable
      }
    }
    fetchSubscription();
  }, [userId]);

  // Handle plan upgrade
  async function handleUpgrade(planId: string) {
    setSwitching(true);
    try {
      const res = await fetch('/api/subscription', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, plan: planId }),
      });
      if (res.ok) {
        setCurrentPlanId(planId);
        const planName =
          SUBSCRIPTION_PLANS.find((p) => p.id === planId)?.name ?? planId;
        toast({
          title: 'Plan updated',
          description: `You are now on the ${planName} plan.`,
        });
      } else {
        toast({
          title: 'Update failed',
          description: 'Something went wrong. Please try again.',
          variant: 'destructive',
        });
      }
    } catch {
      toast({
        title: 'Network error',
        description: 'Could not reach the server. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSwitching(false);
    }
  }

  return (
    <div className="space-y-8">
      {/* Page header */}
      <div className="text-center max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
          Choose Your Plan
        </h1>
        <p className="text-muted-foreground mt-2">
          Scale your ESG reporting as your business grows
        </p>
      </div>

      <Separator />

      {/* ── Pricing cards ──────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
        {SUBSCRIPTION_PLANS.map((plan) => {
          const isHighlighted = plan.highlighted;
          const isCurrentPlan = currentPlanId === plan.id;
          const PlanIcon = PLAN_ICONS[plan.name] ?? Zap;

          return (
            <Card
              key={plan.id}
              className={`relative flex flex-col transition-all duration-200 ${
                isHighlighted
                  ? 'border-primary shadow-lg md:scale-105 md:z-10'
                  : 'hover:shadow-md hover:-translate-y-0.5'
              }`}
            >
              {/* "Most Popular" badge */}
              {isHighlighted && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 shadow-sm">
                  <Star className="h-3 w-3 mr-1" />
                  Most Popular
                </Badge>
              )}

              <CardHeader className="text-center pb-2">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-3">
                  <PlanIcon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>

              <CardContent className="text-center space-y-6 flex-1">
                {/* Price */}
                <div className="pt-2">
                  <span className="text-4xl font-bold tracking-tight">
                    RM {plan.price}
                  </span>
                  <span className="text-muted-foreground text-sm">
                    /month
                  </span>
                </div>

                {/* Features */}
                <ul className="space-y-2.5 text-left">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm">
                      <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter className="pt-2">
                {isCurrentPlan ? (
                  <Button className="w-full" variant="outline" disabled>
                    Current Plan
                  </Button>
                ) : (
                  <Button
                    className="w-full"
                    variant={isHighlighted ? 'default' : 'outline'}
                    disabled={switching}
                    onClick={() => handleUpgrade(plan.id)}
                  >
                    {plan.cta ?? 'Upgrade'}
                  </Button>
                )}
              </CardFooter>
            </Card>
          );
        })}
      </div>

      {/* ── Trust indicators ───────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <Shield className="h-3.5 w-3.5" />
          PDPA Compliant
        </span>
        <span className="flex items-center gap-1.5">
          <CreditCard className="h-3.5 w-3.5" />
          FPX &amp; Card Payments
        </span>
        <span className="flex items-center gap-1.5">
          <Zap className="h-3.5 w-3.5" />
          Cancel Anytime
        </span>
      </div>

      <Separator />

      {/* ── FAQ ────────────────────────────────────────────────────────── */}
      <section>
        <div className="text-center mb-6">
          <h2 className="text-xl font-semibold flex items-center justify-center gap-2">
            <HelpCircle className="h-5 w-5 text-primary" />
            Frequently Asked Questions
          </h2>
        </div>
        <Card className="max-w-2xl mx-auto">
          <CardContent className="pt-6">
            <Accordion type="single" collapsible className="w-full">
              {FAQ_ITEMS.map((faq, idx) => (
                <AccordionItem key={idx} value={`faq-${idx}`}>
                  <AccordionTrigger className="text-sm font-medium hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}