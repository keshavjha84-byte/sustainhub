'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { EMISSION_FACTORS } from '@/data/constants';
import {
  Flame,
  Zap,
  Plus,
  Trash2,
  Save,
  Calculator,
  Info,
  TrendingUp,
  Clock,
  ChevronDown,
  ChevronRight,
  Factory,
  Truck,
  Wind,
  ThermometerSun,
  Package,
  Building,
  MapPin,
  ArrowUpDown,
  Users,
  Plane,
  Recycle,
  Hammer,
  ShoppingCart,
  HandCoins,
  Landmark,
  Globe,
  Leaf,
  Loader2,
  X,
} from 'lucide-react';
import type { EmissionItem, GhgEntry } from '@/types';

// ─── Emission Factor Lookups (comprehensive) ──────────────────────────────────

const FUEL_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Natural Gas': { factor: 2.02, unit: 'kg', efUnit: 'kg CO₂e/kg' },
  'Diesel': { factor: 2.68, unit: 'litres', efUnit: 'kg CO₂e/litre' },
  'Petrol': { factor: 2.31, unit: 'litres', efUnit: 'kg CO₂e/litre' },
  'LPG': { factor: 2.98, unit: 'kg', efUnit: 'kg CO₂e/kg' },
  'Fuel Oil': { factor: 3.15, unit: 'litres', efUnit: 'kg CO₂e/litre' },
  'Coal': { factor: 2.44, unit: 'kg', efUnit: 'kg CO₂e/kg' },
  'Biomass': { factor: 0.0, unit: 'kg', efUnit: 'kg CO₂e/kg (biogenic, net zero)' },
  'Kerosene': { factor: 2.53, unit: 'litres', efUnit: 'kg CO₂e/litre' },
};

const VEHICLE_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Passenger Car (Petrol)': { factor: 0.21, unit: 'km', efUnit: 'kg CO₂e/km' },
  'Passenger Car (Diesel)': { factor: 0.18, unit: 'km', efUnit: 'kg CO₂e/km' },
  'Motorcycle': { factor: 0.06, unit: 'km', efUnit: 'kg CO₂e/km' },
  'Van': { factor: 0.29, unit: 'km', efUnit: 'kg CO₂e/km' },
  'Heavy Truck': { factor: 0.96, unit: 'km', efUnit: 'kg CO₂e/km' },
  'Bus': { factor: 0.89, unit: 'km', efUnit: 'kg CO₂e/km' },
};

const REFRIGERANT_EF: Record<string, { gwp: number; efUnit: string }> = {
  'R-134a': { gwp: 1430, efUnit: 'kg CO₂e/kg' },
  'R-410A': { gwp: 2088, efUnit: 'kg CO₂e/kg' },
  'R-22': { gwp: 1810, efUnit: 'kg CO₂e/kg' },
  'R-32': { gwp: 675, efUnit: 'kg CO₂e/kg' },
  'R-407C': { gwp: 1774, efUnit: 'kg CO₂e/kg' },
  'R-290': { gwp: 3, efUnit: 'kg CO₂e/kg' },
};

const PROCESS_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Cement': { factor: 0.63, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Lime': { factor: 0.75, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Aluminium': { factor: 1.68, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Steel': { factor: 1.85, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Glass': { factor: 0.58, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
};

const GRID_EF: Record<string, { factor: number; label: string; efUnit: string }> = {
  'Peninsular': { factor: 0.6332, label: 'Peninsular Malaysia', efUnit: 'kg CO₂e/kWh' },
  'Sabah': { factor: 0.4138, label: 'Sabah', efUnit: 'kg CO₂e/kWh' },
  'Sarawak': { factor: 0.2450, label: 'Sarawak', efUnit: 'kg CO₂e/kWh' },
};

const MARKET_INSTRUMENTS: Record<string, { factor: number; efUnit: string }> = {
  'Grid Average': { factor: 0.6332, efUnit: 'kg CO₂e/kWh' },
  'REC (Renewable Energy Certificate)': { factor: 0.0, efUnit: 'kg CO₂e/kWh (zero-emission)' },
  'Solar PPA': { factor: 0.0, efUnit: 'kg CO₂e/kWh (zero-emission)' },
  'Biogas PPA': { factor: 0.12, efUnit: 'kg CO₂e/kWh' },
};

const TD_LOSS_FACTOR = 0.07; // 7% T&D losses for Malaysia

const INDUSTRY_FACTORS: Record<string, { factor: number; efUnit: string }> = {
  'Agriculture': { factor: 0.82, efUnit: 'kg CO₂e/RM' },
  'Construction': { factor: 0.47, efUnit: 'kg CO₂e/RM' },
  'Education': { factor: 0.15, efUnit: 'kg CO₂e/RM' },
  'Energy & Utilities': { factor: 1.23, efUnit: 'kg CO₂e/RM' },
  'Financial Services': { factor: 0.09, efUnit: 'kg CO₂e/RM' },
  'Healthcare': { factor: 0.31, efUnit: 'kg CO₂e/RM' },
  'Hospitality': { factor: 0.38, efUnit: 'kg CO₂e/RM' },
  'ICT & Technology': { factor: 0.12, efUnit: 'kg CO₂e/RM' },
  'Manufacturing': { factor: 0.56, efUnit: 'kg CO₂e/RM' },
  'Mining': { factor: 1.04, efUnit: 'kg CO₂e/RM' },
  'Oil & Gas': { factor: 1.35, efUnit: 'kg CO₂e/RM' },
  'Professional Services': { factor: 0.11, efUnit: 'kg CO₂e/RM' },
  'Property': { factor: 0.43, efUnit: 'kg CO₂e/RM' },
  'Retail & Wholesale': { factor: 0.29, efUnit: 'kg CO₂e/RM' },
  'Transport & Logistics': { factor: 0.67, efUnit: 'kg CO₂e/RM' },
  'Waste Management': { factor: 0.91, efUnit: 'kg CO₂e/RM' },
};

const TRANSPORT_MODES: Record<string, { factor: number; efUnit: string }> = {
  'Air (Short-haul)': { factor: 0.255, efUnit: 'kg CO₂e/p-km' },
  'Air (Long-haul)': { factor: 0.195, efUnit: 'kg CO₂e/p-km' },
  'Rail': { factor: 0.041, efUnit: 'kg CO₂e/p-km' },
  'Bus (Coach)': { factor: 0.027, efUnit: 'kg CO₂e/p-km' },
  'Private Car': { factor: 0.171, efUnit: 'kg CO₂e/p-km' },
  'Taxi/Grab': { factor: 0.147, efUnit: 'kg CO₂e/p-km' },
  'Motorcycle': { factor: 0.06, efUnit: 'kg CO₂e/p-km' },
};

const FREIGHT_MODES: Record<string, { factor: number; efUnit: string }> = {
  'Road (Lorry)': { factor: 0.096, efUnit: 'kg CO₂e/tonne-km' },
  'Rail (Freight)': { factor: 0.028, efUnit: 'kg CO₂e/tonne-km' },
  'Air (Cargo)': { factor: 1.128, efUnit: 'kg CO₂e/tonne-km' },
  'Sea (Container)': { factor: 0.016, efUnit: 'kg CO₂e/tonne-km' },
};

const WASTE_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Landfill (Mixed)': { factor: 0.56, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Landfill (Organic)': { factor: 0.68, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Recycling': { factor: 0.02, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Incineration': { factor: 0.35, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
};

const ENERGY_UPSTREAM_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Diesel (Upstream)': { factor: 0.28, unit: 'litres', efUnit: 'kg CO₂e/litre' },
  'Natural Gas (Upstream)': { factor: 0.34, unit: 'm³', efUnit: 'kg CO₂e/m³' },
  'Coal (Upstream)': { factor: 0.12, unit: 'kg', efUnit: 'kg CO₂e/kg' },
};

const LEASED_ASSET_EF: Record<string, { factor: number; efUnit: string }> = {
  'Office Space': { factor: 32.5, efUnit: 'kg CO₂e/m²' },
  'Warehouse': { factor: 18.2, efUnit: 'kg CO₂e/m²' },
  'Retail Space': { factor: 38.7, efUnit: 'kg CO₂e/m²' },
  'Industrial Space': { factor: 24.1, efUnit: 'kg CO₂e/m²' },
};

const PROCESSING_SOLD_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Metal Fabrication': { factor: 0.85, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Food Processing': { factor: 0.12, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Chemical Processing': { factor: 1.45, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Plastic Moulding': { factor: 1.72, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
};

const USE_SOLD_EF: Record<string, { factor: number; efUnit: string }> = {
  'Electrical Appliances (Avg)': { factor: 0.45, efUnit: 't CO₂e/unit/year' },
  'Vehicles (Avg)': { factor: 4.60, efUnit: 't CO₂e/unit/year' },
  'Electronics (Avg)': { factor: 0.08, efUnit: 't CO₂e/unit/year' },
  'Machinery (Avg)': { factor: 1.20, efUnit: 't CO₂e/unit/year' },
};

const END_OF_LIFE_EF: Record<string, { factor: number; unit: string; efUnit: string }> = {
  'Landfill': { factor: 0.42, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Recycling (Metals)': { factor: 0.05, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Recycling (Plastics)': { factor: 0.08, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
  'Incineration': { factor: 0.35, unit: 'tonnes', efUnit: 't CO₂e/tonne' },
};

// ─── Scope 3 Category Definitions ────────────────────────────────────────────

interface Scope3Category {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  inputType: 'spend' | 'distance' | 'weight-distance' | 'quantity' | 'leased-area';
  options?: { label: string; value: string; factor: number; unit: string; efUnit: string }[];
  defaultOption?: string;
  unit: string;
}

const SCOPE3_CATEGORIES: Scope3Category[] = [
  {
    id: 'cat1',
    name: '1. Purchased Goods & Services',
    icon: <ShoppingCart className="h-4 w-4" />,
    description: 'Extraction, production, and transportation of goods and services purchased by the company.',
    inputType: 'spend',
    options: Object.entries(INDUSTRY_FACTORS).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'RM', efUnit: v.efUnit })),
    defaultOption: 'Manufacturing',
    unit: 'RM',
  },
  {
    id: 'cat2',
    name: '2. Capital Goods',
    icon: <Building className="h-4 w-4" />,
    description: 'Production of capital assets like machinery, vehicles, buildings, and equipment.',
    inputType: 'spend',
    options: Object.entries(INDUSTRY_FACTORS).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'RM', efUnit: v.efUnit })),
    defaultOption: 'Manufacturing',
    unit: 'RM',
  },
  {
    id: 'cat3',
    name: '3. Fuel & Energy Activities',
    icon: <Flame className="h-4 w-4" />,
    description: 'Upstream emissions from fuel and energy not included in Scope 1 or 2.',
    inputType: 'quantity',
    options: Object.entries(ENERGY_UPSTREAM_EF).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: v.unit, efUnit: v.efUnit })),
    defaultOption: 'Diesel (Upstream)',
    unit: 'litres',
  },
  {
    id: 'cat4',
    name: '4. Upstream Transportation',
    icon: <Truck className="h-4 w-4" />,
    description: 'Transportation and distribution of purchased goods in vehicles not owned by the company.',
    inputType: 'weight-distance',
    options: Object.entries(FREIGHT_MODES).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'tonne-km', efUnit: v.efUnit })),
    defaultOption: 'Road (Lorry)',
    unit: 'tonne-km',
  },
  {
    id: 'cat5',
    name: '5. Waste Generated',
    icon: <Recycle className="h-4 w-4" />,
    description: 'Disposal and treatment of waste generated in company operations.',
    inputType: 'quantity',
    options: Object.entries(WASTE_EF).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: v.unit, efUnit: v.efUnit })),
    defaultOption: 'Landfill (Mixed)',
    unit: 'tonnes',
  },
  {
    id: 'cat6',
    name: '6. Business Travel',
    icon: <Plane className="h-4 w-4" />,
    description: 'Transportation of employees for business purposes in vehicles not owned by the company.',
    inputType: 'distance',
    options: Object.entries(TRANSPORT_MODES).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'p-km', efUnit: v.efUnit })),
    defaultOption: 'Air (Short-haul)',
    unit: 'passenger-km',
  },
  {
    id: 'cat7',
    name: '7. Employee Commuting',
    icon: <Users className="h-4 w-4" />,
    description: 'Transportation of employees between home and workplace.',
    inputType: 'distance',
    options: Object.entries(TRANSPORT_MODES).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'p-km', efUnit: v.efUnit })),
    defaultOption: 'Private Car',
    unit: 'passenger-km',
  },
  {
    id: 'cat8',
    name: '8. Upstream Leased Assets',
    icon: <Landmark className="h-4 w-4" />,
    description: 'Emissions from leased assets not included in Scope 1 or 2.',
    inputType: 'leased-area',
    options: Object.entries(LEASED_ASSET_EF).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'm²', efUnit: v.efUnit })),
    defaultOption: 'Office Space',
    unit: 'm²',
  },
  {
    id: 'cat9',
    name: '9. Downstream Transportation',
    icon: <ArrowUpDown className="h-4 w-4" />,
    description: 'Transportation and distribution of sold products.',
    inputType: 'weight-distance',
    options: Object.entries(FREIGHT_MODES).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'tonne-km', efUnit: v.efUnit })),
    defaultOption: 'Road (Lorry)',
    unit: 'tonne-km',
  },
  {
    id: 'cat10',
    name: '10. Processing Sold Products',
    icon: <Hammer className="h-4 w-4" />,
    description: 'Processing of sold products by third parties (e.g., further manufacturing).',
    inputType: 'spend',
    options: Object.entries(INDUSTRY_FACTORS).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'RM', efUnit: v.efUnit })),
    defaultOption: 'Manufacturing',
    unit: 'RM',
  },
  {
    id: 'cat11',
    name: '11. Use Sold Products',
    icon: <Globe className="h-4 w-4" />,
    description: 'Direct use-phase emissions from products sold by the company.',
    inputType: 'spend',
    options: Object.entries(INDUSTRY_FACTORS).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'RM', efUnit: v.efUnit })),
    defaultOption: 'Manufacturing',
    unit: 'RM',
  },
  {
    id: 'cat12',
    name: '12. End-of-Life Treatment',
    icon: <Recycle className="h-4 w-4" />,
    description: 'Emissions from waste disposal of products sold at end-of-life.',
    inputType: 'quantity',
    options: Object.entries(END_OF_LIFE_EF).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: v.unit, efUnit: v.efUnit })),
    defaultOption: 'Landfill',
    unit: 'tonnes',
  },
  {
    id: 'cat13',
    name: '13. Downstream Leased Assets',
    icon: <Building className="h-4 w-4" />,
    description: 'Emissions from leased assets owned by the company and leased to other entities.',
    inputType: 'leased-area',
    options: Object.entries(LEASED_ASSET_EF).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'm²', efUnit: v.efUnit })),
    defaultOption: 'Office Space',
    unit: 'm²',
  },
  {
    id: 'cat14',
    name: '14. Franchises',
    icon: <HandCoins className="h-4 w-4" />,
    description: 'Emissions from franchisee operations not included in other categories.',
    inputType: 'spend',
    options: Object.entries(INDUSTRY_FACTORS).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'RM', efUnit: v.efUnit })),
    defaultOption: 'Retail & Wholesale',
    unit: 'RM',
  },
  {
    id: 'cat15',
    name: '15. Investments',
    icon: <TrendingUp className="h-4 w-4" />,
    description: 'Emissions from the company\'s investments (equity, debt, project finance).',
    inputType: 'spend',
    options: Object.entries(INDUSTRY_FACTORS).map(([k, v]) => ({ label: k, value: k, factor: v.factor, unit: 'RM', efUnit: v.efUnit })),
    defaultOption: 'Financial Services',
    unit: 'RM',
  },
];

// ─── Helpers ────────────────────────────────────────────────────────────────

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
] as const;

function getCurrentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function formatPeriod(period: string): string {
  if (!period) return '';
  const [year, month] = period.split('-');
  const monthIdx = parseInt(month, 10) - 1;
  if (isNaN(monthIdx) || monthIdx < 0 || monthIdx > 11) return period;
  return `${MONTHS[monthIdx]} ${year}`;
}

function fmt(n: number): string {
  return n.toFixed(4);
}

function fmtShort(n: number): string {
  if (n >= 1000) return (n / 1000).toFixed(2) + ' kt';
  if (n >= 1) return n.toFixed(2);
  return n.toFixed(4);
}

// ─── Entry Row Type ────────────────────────────────────────────────────────

interface EntryRow {
  id: string;
  sourceType: string;
  quantity: string;
  extraField?: string; // for leakage rate, distance, tonnes etc.
}

function createRow(defaultType: string): EntryRow {
  return { id: crypto.randomUUID(), sourceType: defaultType, quantity: '' };
}

// ─── Sub-component: Entry Row ──────────────────────────────────────────────

function EntryRowCard({
  row,
  index,
  efLabel,
  calculatedEmissions,
  canDelete,
  sourceOptions,
  onUpdate,
  onRemove,
  extraField,
  extraFieldLabel,
  extraFieldValue,
  onExtraFieldChange,
}: {
  row: EntryRow;
  index: number;
  efLabel: string;
  calculatedEmissions: number;
  canDelete: boolean;
  sourceOptions: { label: string; value: string; factorLabel?: string }[];
  onUpdate: (id: string, field: 'sourceType' | 'quantity', value: string) => void;
  onRemove: (id: string) => void;
  extraField?: React.ReactNode;
  extraFieldLabel?: string;
  extraFieldValue?: string;
  onExtraFieldChange?: (id: string, value: string) => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.2 }}
      className="relative rounded-lg border bg-muted/30 p-4"
    >
      <div className="absolute -top-2.5 left-4">
        <Badge variant="secondary" className="text-[10px] font-medium">
          #{index + 1}
        </Badge>
      </div>

      <div className="mt-1 grid gap-4 sm:grid-cols-[1fr_1fr_auto_auto_auto]">
        <div className="space-y-1.5">
          <Label className="text-xs font-medium">Type / Source</Label>
          <Select
            value={row.sourceType}
            onValueChange={(v) => onUpdate(row.id, 'sourceType', v)}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sourceOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  <span className="flex items-center gap-2">
                    {opt.label}
                    {opt.factorLabel && (
                      <span className="text-xs text-muted-foreground">{opt.factorLabel}</span>
                    )}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {extraField && (
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">{extraFieldLabel || 'Additional'}</Label>
            {extraField}
          </div>
        )}

        <div className="space-y-1.5">
          <Label className="text-xs font-medium">Quantity</Label>
          <Input
            type="number"
            min="0"
            step="any"
            placeholder="0"
            value={row.quantity}
            onChange={(e) => onUpdate(row.id, 'quantity', e.target.value)}
          />
        </div>

        <div className="flex flex-col items-end justify-end space-y-1">
          <span className="text-[10px] text-muted-foreground">Emissions</span>
          <p className="text-base font-semibold text-emerald-700 dark:text-emerald-400">
            {fmt(calculatedEmissions)}
          </p>
          <span className="text-[10px] text-muted-foreground">tCO₂e</span>
        </div>

        <div className="flex items-end">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 text-destructive hover:bg-destructive/10 hover:text-destructive"
            onClick={() => onRemove(row.id)}
            disabled={!canDelete}
            aria-label="Delete entry"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <p className="mt-2 flex items-center gap-1 text-[10px] text-muted-foreground">
        <Info className="h-3 w-3" />
        {efLabel}
      </p>
    </motion.div>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────

interface GhgCalculatorViewProps {
  userId: string;
  companyId: string;
}

export default function GhgCalculatorView({ userId, companyId }: GhgCalculatorViewProps) {
  const { toast } = useToast();

  // ── Reporting Period ────────────────────────────────────────────────────
  const [reportingPeriod, setReportingPeriod] = useState(getCurrentPeriod);
  const [selectedYear, setSelectedYear] = useState(String(new Date().getFullYear()));
  const [selectedMonth, setSelectedMonth] = useState(String(new Date().getMonth() + 1));

  useEffect(() => {
    setReportingPeriod(`${selectedYear}-${selectedMonth.padStart(2, '0')}`);
  }, [selectedYear, selectedMonth]);

  // ── Scope 1 State ────────────────────────────────────────────────────────
  const [stationaryRows, setStationaryRows] = useState<EntryRow[]>([createRow('Diesel')]);
  const [mobileRows, setMobileRows] = useState<EntryRow[]>([createRow('Passenger Car (Petrol)')]);
  const [fugitiveRows, setFugitiveRows] = useState<EntryRow[]>([createRow('R-134a')]);
  const [processRows, setProcessRows] = useState<EntryRow[]>([createRow('Cement')]);

  // ── Scope 2 State ────────────────────────────────────────────────────────
  const [scope2Method, setScope2Method] = useState<'location' | 'market' | 'both'>('location');
  const [locationRows, setLocationRows] = useState<EntryRow[]>([createRow('Peninsular')]);
  const [marketRows, setMarketRows] = useState<EntryRow[]>([createRow('Grid Average')]);
  const [tdLossRows, setTdLossRows] = useState<EntryRow[]>([createRow('Peninsular')]);

  // ── Scope 3 State ────────────────────────────────────────────────────────
  const [scope3Rows, setScope3Rows] = useState<Record<string, EntryRow[]>>(() => {
    const init: Record<string, EntryRow[]> = {};
    for (const cat of SCOPE3_CATEGORIES) {
      init[cat.id] = [createRow(cat.defaultOption || cat.options?.[0]?.value || '')];
    }
    return init;
  });
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({});

  // ── Submission ────────────────────────────────────────────────────────────
  const [previousSubmissions, setPreviousSubmissions] = useState<GhgEntry[]>([]);
  const [loadingSubmissions, setLoadingSubmissions] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmissions, setShowSubmissions] = useState(false);

  // ── Generic row handlers ──────────────────────────────────────────────────
  function updateRows(setter: React.Dispatch<React.SetStateAction<EntryRow[]>>) {
    return (id: string, field: 'sourceType' | 'quantity', value: string) => {
      setter((prev) => prev.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
    };
  }

  function addRow(setter: React.Dispatch<React.SetStateAction<EntryRow[]>>, defaultType: string) {
    setter((prev) => [...prev, createRow(defaultType)]);
  }

  function removeRow(setter: React.Dispatch<React.SetStateAction<EntryRow[]>>) {
    return (id: string) => {
      setter((prev) => {
        if (prev.length <= 1) return prev;
        return prev.filter((r) => r.id !== id);
      });
    };
  }

  // Scope 3 specific handlers
  function updateScope3Row(catId: string, id: string, field: 'sourceType' | 'quantity', value: string) {
    setScope3Rows((prev) => ({
      ...prev,
      [catId]: prev[catId].map((r) => (r.id === id ? { ...r, [field]: value } : r)),
    }));
  }

  function addScope3Row(catId: string, defaultType: string) {
    setScope3Rows((prev) => ({
      ...prev,
      [catId]: [...prev[catId], createRow(defaultType)],
    }));
  }

  function removeScope3Row(catId: string, id: string) {
    setScope3Rows((prev) => ({
      ...prev,
      [catId]: prev[catId].length <= 1 ? prev[catId] : prev[catId].filter((r) => r.id !== id),
    }));
  }

  // ── Fugitive: update extra field (leakage rate) ──────────────────────────
  function updateFugitiveExtra(id: string, value: string) {
    setFugitiveRows((prev) => prev.map((r) => (r.id === id ? { ...r, extraField: value } : r)));
  }

  // ── Computed: Scope 1 ───────────────────────────────────────────────────
  const scope1StationaryItems = useMemo(() => {
    return stationaryRows.reduce<EmissionItem[]>((acc, row) => {
      const info = FUEL_EF[row.sourceType];
      if (!info) return acc;
      const qty = parseFloat(row.quantity) || 0;
      acc.push({
        scope: 1,
        category: 'Stationary Combustion',
        subCategory: row.sourceType,
        activityData: qty,
        activityUnit: info.unit,
        emissionFactor: info.factor,
        efUnit: info.efUnit,
        emissions: (qty * info.factor) / 1000,
      });
      return acc;
    }, []);
  }, [stationaryRows]);

  const scope1MobileItems = useMemo(() => {
    return mobileRows.reduce<EmissionItem[]>((acc, row) => {
      const info = VEHICLE_EF[row.sourceType];
      if (!info) return acc;
      const dist = parseFloat(row.quantity) || 0;
      acc.push({
        scope: 1,
        category: 'Mobile Combustion',
        subCategory: row.sourceType,
        activityData: dist,
        activityUnit: info.unit,
        emissionFactor: info.factor,
        efUnit: info.efUnit,
        emissions: (dist * info.factor) / 1000,
      });
      return acc;
    }, []);
  }, [mobileRows]);

  const scope1FugitiveItems = useMemo(() => {
    return fugitiveRows.reduce<EmissionItem[]>((acc, row) => {
      const info = REFRIGERANT_EF[row.sourceType];
      if (!info) return acc;
      const qty = parseFloat(row.quantity) || 0;
      const leakage = parseFloat(row.extraField || '0') / 100;
      const emittedQty = qty * leakage;
      acc.push({
        scope: 1,
        category: 'Fugitive Emissions',
        subCategory: row.sourceType,
        activityData: qty,
        activityUnit: 'kg',
        emissionFactor: info.gwp,
        efUnit: info.efUnit,
        emissions: (emittedQty * info.gwp) / 1000,
        metadata: JSON.stringify({ gwp: info.gwp, leakagePct: parseFloat(row.extraField || '0') }),
      });
      return acc;
    }, []);
  }, [fugitiveRows]);

  const scope1ProcessItems = useMemo(() => {
    return processRows.reduce<EmissionItem[]>((acc, row) => {
      const info = PROCESS_EF[row.sourceType];
      if (!info) return acc;
      const qty = parseFloat(row.quantity) || 0;
      acc.push({
        scope: 1,
        category: 'Process Emissions',
        subCategory: row.sourceType,
        activityData: qty,
        activityUnit: info.unit,
        emissionFactor: info.factor,
        efUnit: info.efUnit,
        emissions: qty * info.factor,
      });
      return acc;
    }, []);
  }, [processRows]);

  const scope1Total = useMemo(
    () =>
      [...scope1StationaryItems, ...scope1MobileItems, ...scope1FugitiveItems, ...scope1ProcessItems]
        .reduce((sum, i) => sum + i.emissions, 0),
    [scope1StationaryItems, scope1MobileItems, scope1FugitiveItems, scope1ProcessItems],
  );

  // ── Computed: Scope 2 ───────────────────────────────────────────────────
  const scope2LocationItems = useMemo(() => {
    return locationRows.reduce<EmissionItem[]>((acc, row) => {
      const info = GRID_EF[row.sourceType];
      if (!info) return acc;
      const kwh = parseFloat(row.quantity) || 0;
      acc.push({
        scope: 2,
        category: 'Electricity (Location-based)',
        subCategory: info.label,
        activityData: kwh,
        activityUnit: 'kWh',
        emissionFactor: info.factor,
        efUnit: info.efUnit,
        emissions: (kwh * info.factor) / 1000,
      });
      return acc;
    }, []);
  }, [locationRows]);

  const scope2MarketItems = useMemo(() => {
    return marketRows.reduce<EmissionItem[]>((acc, row) => {
      const info = MARKET_INSTRUMENTS[row.sourceType];
      if (!info) return acc;
      const kwh = parseFloat(row.quantity) || 0;
      acc.push({
        scope: 2,
        category: 'Electricity (Market-based)',
        subCategory: row.sourceType,
        activityData: kwh,
        activityUnit: 'kWh',
        emissionFactor: info.factor,
        efUnit: info.efUnit,
        emissions: (kwh * info.factor) / 1000,
      });
      return acc;
    }, []);
  }, [marketRows]);

  const scope2TdLossItems = useMemo(() => {
    return tdLossRows.reduce<EmissionItem[]>((acc, row) => {
      const info = GRID_EF[row.sourceType];
      if (!info) return acc;
      const kwh = parseFloat(row.quantity) || 0;
      const lossEmissions = kwh * info.factor * TD_LOSS_FACTOR;
      acc.push({
        scope: 2,
        category: 'T&D Losses',
        subCategory: info.label,
        activityData: kwh,
        activityUnit: 'kWh',
        emissionFactor: info.factor * TD_LOSS_FACTOR,
        efUnit: `kg CO₂e/kWh (${(TD_LOSS_FACTOR * 100).toFixed(0)}% loss)`,
        emissions: lossEmissions / 1000,
      });
      return acc;
    }, []);
  }, [tdLossRows]);

  const scope2Total = useMemo(() => {
    const base = scope2Method === 'location'
      ? scope2LocationItems.reduce((s, i) => s + i.emissions, 0)
      : scope2MarketItems.reduce((s, i) => s + i.emissions, 0);
    const td = scope2TdLossItems.reduce((s, i) => s + i.emissions, 0);
    return base + td;
  }, [scope2Method, scope2LocationItems, scope2MarketItems, scope2TdLossItems]);

  // ── Computed: Scope 3 ───────────────────────────────────────────────────
  const scope3AllItems: EmissionItem[] = useMemo(() => {
    const items: EmissionItem[] = [];
    for (const cat of SCOPE3_CATEGORIES) {
      const rows = scope3Rows[cat.id] || [];
      for (const row of rows) {
        const opt = cat.options?.find((o) => o.value === row.sourceType);
        if (!opt) continue;
        const qty = parseFloat(row.quantity) || 0;
        if (cat.inputType === 'spend') {
          // RM × EF / 1000
          items.push({
            scope: 3,
            category: cat.name,
            subCategory: row.sourceType,
            activityData: qty,
            activityUnit: 'RM',
            emissionFactor: opt.factor,
            efUnit: opt.efUnit,
            emissions: (qty * opt.factor) / 1000,
          });
        } else if (cat.inputType === 'distance') {
          // p-km × EF / 1000
          items.push({
            scope: 3,
            category: cat.name,
            subCategory: row.sourceType,
            activityData: qty,
            activityUnit: 'p-km',
            emissionFactor: opt.factor,
            efUnit: opt.efUnit,
            emissions: (qty * opt.factor) / 1000,
          });
        } else if (cat.inputType === 'weight-distance') {
          // already tonne-km
          items.push({
            scope: 3,
            category: cat.name,
            subCategory: row.sourceType,
            activityData: qty,
            activityUnit: 'tonne-km',
            emissionFactor: opt.factor,
            efUnit: opt.efUnit,
            emissions: (qty * opt.factor) / 1000,
          });
        } else if (cat.inputType === 'leased-area') {
          // m² × EF / 1000
          items.push({
            scope: 3,
            category: cat.name,
            subCategory: row.sourceType,
            activityData: qty,
            activityUnit: 'm²',
            emissionFactor: opt.factor,
            efUnit: opt.efUnit,
            emissions: (qty * opt.factor) / 1000,
          });
        } else if (cat.inputType === 'quantity') {
          // tonnes × EF (if EF is tCO2e/tonne, no conversion needed)
          const isTonnes = opt.unit === 'tonnes';
          items.push({
            scope: 3,
            category: cat.name,
            subCategory: row.sourceType,
            activityData: qty,
            activityUnit: opt.unit,
            emissionFactor: opt.factor,
            efUnit: opt.efUnit,
            emissions: isTonnes ? qty * opt.factor : (qty * opt.factor) / 1000,
          });
        }
      }
    }
    return items;
  }, [scope3Rows]);

  const scope3Total = useMemo(
    () => scope3AllItems.reduce((sum, i) => sum + i.emissions, 0),
    [scope3AllItems],
  );

  const totalEmissions = scope1Total + scope2Total + scope3Total;

  // ── All emission items combined (for submission) ─────────────────────────
  const allEmissionItems: EmissionItem[] = useMemo(() => {
    return [
      ...scope1StationaryItems,
      ...scope1MobileItems,
      ...scope1FugitiveItems,
      ...scope1ProcessItems,
      ...(scope2Method === 'location' || scope2Method === 'both' ? scope2LocationItems : []),
      ...(scope2Method === 'market' || scope2Method === 'both' ? scope2MarketItems : []),
      ...scope2TdLossItems,
      ...scope3AllItems,
    ];
  }, [
    scope1StationaryItems, scope1MobileItems, scope1FugitiveItems, scope1ProcessItems,
    scope2Method, scope2LocationItems, scope2MarketItems, scope2TdLossItems,
    scope3AllItems,
  ]);

  // ── Fetch previous submissions ──────────────────────────────────────────
  useEffect(() => {
    async function fetchSubmissions() {
      try {
        setLoadingSubmissions(true);
        const res = await fetch(`/api/ghg?userId=${encodeURIComponent(userId)}`);
        if (res.ok) {
          const data = await res.json();
          setPreviousSubmissions(Array.isArray(data) ? data : data.entries ?? []);
        }
      } catch {
        // silently ignore
      } finally {
        setLoadingSubmissions(false);
      }
    }
    fetchSubmissions();
  }, [userId]);

  // ── Submit handler ──────────────────────────────────────────────────────
  const handleSubmit = useCallback(async () => {
    const validItems = allEmissionItems.filter((i) => i.activityData > 0);
    if (validItems.length === 0) {
      toast({
        title: 'No data to submit',
        description: 'Please enter at least one emission entry.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/ghg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          companyId,
          reportingPeriod,
          scope2Method,
          emissionItems: validItems,
          scope1Total,
          scope2Total,
          scope3Total,
          totalEmissions,
        }),
      });

      if (res.ok) {
        toast({
          title: 'Submission saved',
          description: `GHG emissions for ${formatPeriod(reportingPeriod)} saved successfully.`,
        });
        const refreshRes = await fetch(`/api/ghg?userId=${encodeURIComponent(userId)}`);
        if (refreshRes.ok) {
          const data = await refreshRes.json();
          setPreviousSubmissions(Array.isArray(data) ? data : data.entries ?? []);
        }
        // Reset all rows
        setStationaryRows([createRow('Diesel')]);
        setMobileRows([createRow('Passenger Car (Petrol)')]);
        setFugitiveRows([createRow('R-134a')]);
        setProcessRows([createRow('Cement')]);
        setLocationRows([createRow('Peninsular')]);
        setMarketRows([createRow('Grid Average')]);
        setTdLossRows([createRow('Peninsular')]);
        const freshScope3: Record<string, EntryRow[]> = {};
        for (const cat of SCOPE3_CATEGORIES) {
          freshScope3[cat.id] = [createRow(cat.defaultOption || cat.options?.[0]?.value || '')];
        }
        setScope3Rows(freshScope3);
      } else {
        const err = await res.json().catch(() => ({}));
        toast({
          title: 'Submission failed',
          description: err.error ?? 'Something went wrong. Please try again.',
          variant: 'destructive',
        });
      }
    } catch {
      toast({
        title: 'Network error',
        description: 'Could not reach the server. Please check your connection.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [
    userId, companyId, reportingPeriod, scope2Method, allEmissionItems,
    scope1Total, scope2Total, scope3Total, totalEmissions, toast,
  ]);

  // ── Visual bar widths ────────────────────────────────────────────────────
  const barData = useMemo(() => {
    const total = totalEmissions || 1;
    return {
      scope1: (scope1Total / total) * 100,
      scope2: (scope2Total / total) * 100,
      scope3: (scope3Total / total) * 100,
    };
  }, [totalEmissions, scope1Total, scope2Total, scope3Total]);

  // ─── Render ──────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Calculator className="h-6 w-6 text-emerald-600" />
          <h2 className="text-2xl font-bold tracking-tight">GHG Emissions Calculator</h2>
        </div>
        <Badge variant="outline" className="w-fit gap-1.5 text-xs border-emerald-300 text-emerald-700 dark:border-emerald-700 dark:text-emerald-400">
          <Clock className="h-3 w-3" />
          {formatPeriod(reportingPeriod)}
        </Badge>
      </div>

      {/* Reporting Period Selector */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
            <div className="flex-1 space-y-1.5">
              <Label className="text-sm font-medium">Reporting Month</Label>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select month" />
                </SelectTrigger>
                <SelectContent>
                  {MONTHS.map((m, i) => (
                    <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 space-y-1.5">
              <Label className="text-sm font-medium">Reporting Year</Label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select year" />
                </SelectTrigger>
                <SelectContent>
                  {[2023, 2024, 2025].map((y) => (
                    <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-2 border-emerald-200 bg-emerald-50/50 dark:border-emerald-800 dark:bg-emerald-950/30">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-emerald-600" />
              Total Emissions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-400">{fmt(totalEmissions)}</p>
            <p className="mt-1 text-xs text-muted-foreground">tCO₂e</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-600">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Flame className="h-4 w-4 text-green-600" />
              Scope 1: Direct
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-700 dark:text-green-400">{fmt(scope1Total)}</p>
            <p className="mt-1 text-xs text-muted-foreground">tCO₂e</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-teal-600">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Zap className="h-4 w-4 text-teal-600" />
              Scope 2: Indirect Energy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-teal-700 dark:text-teal-400">{fmt(scope2Total)}</p>
            <p className="mt-1 text-xs text-muted-foreground">tCO₂e</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-600">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Truck className="h-4 w-4 text-amber-600" />
              Scope 3: Value Chain
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-amber-700 dark:text-amber-400">{fmt(scope3Total)}</p>
            <p className="mt-1 text-xs text-muted-foreground">tCO₂e</p>
          </CardContent>
        </Card>
      </div>

      {/* Visual Breakdown Bar */}
      {totalEmissions > 0 && (
        <Card>
          <CardContent className="pt-6">
            <p className="mb-3 text-sm font-medium text-muted-foreground">Emissions Breakdown</p>
            <div className="flex h-8 w-full overflow-hidden rounded-md">
              <div
                className="flex items-center justify-center bg-green-600 text-xs font-medium text-white transition-all duration-500"
                style={{ width: `${Math.max(barData.scope1, 2)}%` }}
              >
                {barData.scope1 > 10 && 'S1'}
              </div>
              <div
                className="flex items-center justify-center bg-teal-600 text-xs font-medium text-white transition-all duration-500"
                style={{ width: `${Math.max(barData.scope2, 2)}%` }}
              >
                {barData.scope2 > 10 && 'S2'}
              </div>
              <div
                className="flex items-center justify-center bg-amber-500 text-xs font-medium text-white transition-all duration-500"
                style={{ width: `${Math.max(barData.scope3, 2)}%` }}
              >
                {barData.scope3 > 10 && 'S3'}
              </div>
            </div>
            <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-green-600" />
                Scope 1: {fmt(scope1Total)} tCO₂e ({barData.scope1.toFixed(1)}%)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-teal-600" />
                Scope 2: {fmt(scope2Total)} tCO₂e ({barData.scope2.toFixed(1)}%)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-amber-500" />
                Scope 3: {fmt(scope3Total)} tCO₂e ({barData.scope3.toFixed(1)}%)
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Tabs */}
      <Tabs defaultValue="scope1" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="scope1" className="gap-1.5">
            <Flame className="h-4 w-4" />
            <span className="hidden sm:inline">Scope 1:</span>Direct
          </TabsTrigger>
          <TabsTrigger value="scope2" className="gap-1.5">
            <Zap className="h-4 w-4" />
            <span className="hidden sm:inline">Scope 2:</span>Energy
          </TabsTrigger>
          <TabsTrigger value="scope3" className="gap-1.5">
            <Truck className="h-4 w-4" />
            <span className="hidden sm:inline">Scope 3:</span>Value Chain
          </TabsTrigger>
        </TabsList>

        {/* ═══════ SCOPE 1 ═══════════════════════════════════════════════════ */}
        <TabsContent value="scope1" className="space-y-4 pt-4">
          <AnimatePresence mode="wait">
            <motion.div
              key="scope1-content"
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 }}
              transition={{ duration: 0.25 }}
              className="space-y-4"
            >
              {/* 1. Stationary Combustion */}
              <ScopeSection
                title="Stationary Combustion"
                icon={<Factory className="h-5 w-5 text-green-600" />}
                description="Direct emissions from fuel combustion in stationary sources such as boilers, furnaces, and generators."
                rows={stationaryRows}
                sourceOptions={Object.entries(FUEL_EF).map(([k, v]) => ({
                  label: k, value: k, factorLabel: `(${v.factor} ${v.efUnit})`,
                }))}
                getEFLabel={(sourceType) => {
                  const info = FUEL_EF[sourceType];
                  return info ? `EF: ${info.factor} ${info.efUnit} (MGTC/GHG Protocol)` : '';
                }}
                getEmissions={(row) => {
                  const info = FUEL_EF[row.sourceType];
                  const qty = parseFloat(row.quantity) || 0;
                  return info ? (qty * info.factor) / 1000 : 0;
                }}
                defaultAddType="Diesel"
                onUpdate={updateRows(setStationaryRows)}
                onAdd={() => addRow(setStationaryRows, 'Diesel')}
                onRemove={removeRow(setStationaryRows)}
              />

              {/* 2. Mobile Combustion */}
              <ScopeSection
                title="Mobile Combustion"
                icon={<Truck className="h-5 w-5 text-green-600" />}
                description="Direct emissions from fuel combustion in company-owned or leased vehicles."
                rows={mobileRows}
                sourceOptions={Object.entries(VEHICLE_EF).map(([k, v]) => ({
                  label: k, value: k, factorLabel: `(${v.factor} ${v.efUnit})`,
                }))}
                getEFLabel={(sourceType) => {
                  const info = VEHICLE_EF[sourceType];
                  return info ? `EF: ${info.factor} ${info.efUnit}` : '';
                }}
                getEmissions={(row) => {
                  const info = VEHICLE_EF[row.sourceType];
                  const dist = parseFloat(row.quantity) || 0;
                  return info ? (dist * info.factor) / 1000 : 0;
                }}
                defaultAddType="Passenger Car (Petrol)"
                onUpdate={updateRows(setMobileRows)}
                onAdd={() => addRow(setMobileRows, 'Passenger Car (Petrol)')}
                onRemove={removeRow(setMobileRows)}
              />

              {/* 3. Fugitive Emissions */}
              <Collapsible defaultOpen className="rounded-lg border">
                <CollapsibleTrigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Wind className="h-5 w-5 text-green-600" />
                    <div className="text-left">
                      <p className="font-medium">Fugitive Emissions</p>
                      <p className="text-xs text-muted-foreground">
                        Refrigerant leaks, venting, and other intentional/unintentional releases.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {fmtShort(scope1FugitiveItems.reduce((s, i) => s + i.emissions, 0))} tCO₂e
                    </Badge>
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="border-t p-4 space-y-4 bg-muted/20">
                    {fugitiveRows.map((row, idx) => {
                      const info = REFRIGERANT_EF[row.sourceType];
                      const qty = parseFloat(row.quantity) || 0;
                      const leakage = parseFloat(row.extraField || '0') / 100;
                      const emitted = qty * leakage;
                      const emissions = info ? (emitted * info.gwp) / 1000 : 0;

                      return (
                        <motion.div
                          key={row.id}
                          initial={{ opacity: 0, y: -8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -8 }}
                          className="relative rounded-lg border bg-white p-4 dark:bg-card"
                        >
                          <div className="absolute -top-2.5 left-4">
                            <Badge variant="secondary" className="text-[10px]">#{idx + 1}</Badge>
                          </div>

                          <div className="mt-1 grid gap-4 sm:grid-cols-[1fr_1fr_1fr_auto_auto_auto]">
                            <div className="space-y-1.5">
                              <Label className="text-xs font-medium">Refrigerant</Label>
                              <Select
                                value={row.sourceType}
                                onValueChange={(v) => updateRows(setFugitiveRows)(row.id, 'sourceType', v)}
                              >
                                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {Object.entries(REFRIGERANT_EF).map(([k, v]) => (
                                    <SelectItem key={k} value={k}>
                                      <span className="flex items-center gap-2">
                                        {k}
                                        <span className="text-xs text-muted-foreground">(GWP: {v.gwp})</span>
                                      </span>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div className="space-y-1.5">
                              <Label className="text-xs font-medium">Quantity (kg)</Label>
                              <Input
                                type="number"
                                min="0"
                                step="any"
                                placeholder="0"
                                value={row.quantity}
                                onChange={(e) => updateRows(setFugitiveRows)(row.id, 'quantity', e.target.value)}
                              />
                            </div>

                            <div className="space-y-1.5">
                              <Label className="text-xs font-medium">Leakage Rate (%)</Label>
                              <Input
                                type="number"
                                min="0"
                                max="100"
                                step="0.1"
                                placeholder="0"
                                value={row.extraField || ''}
                                onChange={(e) => updateFugitiveExtra(row.id, e.target.value)}
                              />
                            </div>

                            <div className="flex flex-col items-end justify-end space-y-1">
                              <span className="text-[10px] text-muted-foreground">Emissions</span>
                              <p className="text-base font-semibold text-emerald-700 dark:text-emerald-400">
                                {fmt(emissions)}
                              </p>
                              <span className="text-[10px] text-muted-foreground">tCO₂e</span>
                            </div>

                            <div className="flex items-end">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-10 w-10 text-destructive hover:bg-destructive/10 hover:text-destructive"
                                onClick={() => removeRow(setFugitiveRows)(row.id)}
                                disabled={fugitiveRows.length <= 1}
                                aria-label="Delete entry"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          <p className="mt-2 flex items-center gap-1 text-[10px] text-muted-foreground">
                            <Info className="h-3 w-3" />
                            {info ? `GWP: ${info.gwp} | Leaked: ${emitted.toFixed(2)} kg | EF: qty × leakage% × GWP / 1000` : ''}
                          </p>
                        </motion.div>
                      );
                    })}

                    <Button variant="outline" onClick={() => addRow(setFugitiveRows, 'R-134a')} className="w-full gap-2">
                      <Plus className="h-4 w-4" /> Add Fugitive Entry
                    </Button>
                  </div>
                </CollapsibleContent>
              </Collapsible>

              {/* 4. Process Emissions */}
              <ScopeSection
                title="Process Emissions"
                icon={<ThermometerSun className="h-5 w-5 text-green-600" />}
                description="Emissions from chemical or physical processes (e.g., cement production, metal smelting)."
                rows={processRows}
                sourceOptions={Object.entries(PROCESS_EF).map(([k, v]) => ({
                  label: k, value: k, factorLabel: `(${v.factor} ${v.efUnit})`,
                }))}
                getEFLabel={(sourceType) => {
                  const info = PROCESS_EF[sourceType];
                  return info ? `EF: ${info.factor} ${info.efUnit}` : '';
                }}
                getEmissions={(row) => {
                  const info = PROCESS_EF[row.sourceType];
                  const qty = parseFloat(row.quantity) || 0;
                  return info ? qty * info.factor : 0;
                }}
                defaultAddType="Cement"
                onUpdate={updateRows(setProcessRows)}
                onAdd={() => addRow(setProcessRows, 'Cement')}
                onRemove={removeRow(setProcessRows)}
              />

              {/* Scope 1 Subtotal */}
              <div className="flex items-center justify-between rounded-lg bg-green-50 px-4 py-3 dark:bg-green-950/30">
                <span className="flex items-center gap-2 font-medium text-green-800 dark:text-green-300">
                  <Flame className="h-4 w-4" />
                  Scope 1 Total
                </span>
                <span className="text-xl font-bold text-green-700 dark:text-green-400">
                  {fmt(scope1Total)} tCO₂e
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </TabsContent>

        {/* ═══════ SCOPE 2 ═══════════════════════════════════════════════════ */}
        <TabsContent value="scope2" className="space-y-4 pt-4">
          <AnimatePresence mode="wait">
            <motion.div
              key="scope2-content"
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 }}
              transition={{ duration: 0.25 }}
              className="space-y-4"
            >
              {/* Method Toggle */}
              <Card className="border-emerald-200 dark:border-emerald-800">
                <CardContent className="pt-6">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="font-medium">Scope 2 Calculation Method</p>
                      <p className="text-xs text-muted-foreground">
                        Choose location-based (grid average) or market-based (instrument-specific) or both.
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {(['location', 'market', 'both'] as const).map((method) => (
                        <Button
                          key={method}
                          variant={scope2Method === method ? 'default' : 'outline'}
                          size="sm"
                          className={
                            scope2Method === method
                              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                              : ''
                          }
                          onClick={() => setScope2Method(method)}
                        >
                          {method === 'location' ? 'Location-based' : method === 'market' ? 'Market-based' : 'Both'}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Location-based / Market-based side by side or stacked */}
              <div className={`grid gap-4 ${(scope2Method === 'both') ? 'lg:grid-cols-2' : ''}`}>
                {/* Location-based */}
                {(scope2Method === 'location' || scope2Method === 'both') && (
                  <Card className={scope2Method === 'both' ? '' : ''}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-base">
                        <MapPin className="h-5 w-5 text-teal-600" />
                        Location-based
                        <Badge variant="secondary" className="text-[10px]">Grid Average</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {locationRows.map((row, idx) => {
                        const info = GRID_EF[row.sourceType];
                        const kwh = parseFloat(row.quantity) || 0;
                        const emissions = info ? (kwh * info.factor) / 1000 : 0;

                        return (
                          <EntryRowCard
                            key={row.id}
                            row={row}
                            index={idx}
                            efLabel={info ? `${info.label}: ${info.factor} kg CO₂e/kWh` : ''}
                            calculatedEmissions={emissions}
                            canDelete={locationRows.length > 1}
                            sourceOptions={Object.entries(GRID_EF).map(([k, v]) => ({
                              label: v.label, value: k, factorLabel: `(${v.factor})`,
                            }))}
                            onUpdate={updateRows(setLocationRows)}
                            onRemove={removeRow(setLocationRows)}
                          />
                        );
                      })}
                      <Button variant="outline" onClick={() => addRow(setLocationRows, 'Peninsular')} className="w-full gap-2">
                        <Plus className="h-4 w-4" /> Add Entry
                      </Button>

                      <div className="rounded-lg bg-teal-50 px-3 py-2 text-sm dark:bg-teal-950/30">
                        <span className="text-teal-800 dark:text-teal-300 font-medium">Subtotal: </span>
                        <span className="font-bold text-teal-700 dark:text-teal-400">
                          {fmt(scope2LocationItems.reduce((s, i) => s + i.emissions, 0))} tCO₂e
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Market-based */}
                {(scope2Method === 'market' || scope2Method === 'both') && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-base">
                        <Package className="h-5 w-5 text-teal-600" />
                        Market-based
                        <Badge variant="secondary" className="text-[10px]">Contract/Instrument</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {marketRows.map((row, idx) => {
                        const info = MARKET_INSTRUMENTS[row.sourceType];
                        const kwh = parseFloat(row.quantity) || 0;
                        const emissions = info ? (kwh * info.factor) / 1000 : 0;

                        return (
                          <EntryRowCard
                            key={row.id}
                            row={row}
                            index={idx}
                            efLabel={info ? `${row.sourceType}: ${info.factor} kg CO₂e/kWh` : ''}
                            calculatedEmissions={emissions}
                            canDelete={marketRows.length > 1}
                            sourceOptions={Object.entries(MARKET_INSTRUMENTS).map(([k, v]) => ({
                              label: k, value: k, factorLabel: `(${v.factor})`,
                            }))}
                            onUpdate={updateRows(setMarketRows)}
                            onRemove={removeRow(setMarketRows)}
                          />
                        );
                      })}
                      <Button variant="outline" onClick={() => addRow(setMarketRows, 'Grid Average')} className="w-full gap-2">
                        <Plus className="h-4 w-4" /> Add Entry
                      </Button>

                      <div className="rounded-lg bg-teal-50 px-3 py-2 text-sm dark:bg-teal-950/30">
                        <span className="text-teal-800 dark:text-teal-300 font-medium">Subtotal: </span>
                        <span className="font-bold text-teal-700 dark:text-teal-400">
                          {fmt(scope2MarketItems.reduce((s, i) => s + i.emissions, 0))} tCO₂e
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* T&D Losses */}
              <Collapsible defaultOpen className="rounded-lg border">
                <CollapsibleTrigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Wind className="h-5 w-5 text-teal-600" />
                    <div className="text-left">
                      <p className="font-medium">Transmission & Distribution Losses</p>
                      <p className="text-xs text-muted-foreground">
                        Scope 3 Cat 3 (shown here for convenience). Applies {(TD_LOSS_FACTOR * 100).toFixed(0)}% loss factor.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {fmtShort(scope2TdLossItems.reduce((s, i) => s + i.emissions, 0))} tCO₂e
                    </Badge>
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform [[data-state=open]>&]:rotate-180" />
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="border-t p-4 space-y-4 bg-muted/20">
                    {tdLossRows.map((row, idx) => {
                      const info = GRID_EF[row.sourceType];
                      const kwh = parseFloat(row.quantity) || 0;
                      const emissions = info ? (kwh * info.factor * TD_LOSS_FACTOR) / 1000 : 0;

                      return (
                        <EntryRowCard
                          key={row.id}
                          row={row}
                          index={idx}
                          efLabel={info ? `EF: ${info.factor} × ${(TD_LOSS_FACTOR * 100).toFixed(0)}% loss = ${(info.factor * TD_LOSS_FACTOR).toFixed(4)} kg CO₂e/kWh` : ''}
                          calculatedEmissions={emissions}
                          canDelete={tdLossRows.length > 1}
                          sourceOptions={Object.entries(GRID_EF).map(([k, v]) => ({
                            label: v.label, value: k, factorLabel: `(${v.factor})`,
                          }))}
                          onUpdate={updateRows(setTdLossRows)}
                          onRemove={removeRow(setTdLossRows)}
                        />
                      );
                    })}
                    <Button variant="outline" onClick={() => addRow(setTdLossRows, 'Peninsular')} className="w-full gap-2">
                      <Plus className="h-4 w-4" /> Add T&D Entry
                    </Button>
                  </div>
                </CollapsibleContent>
              </Collapsible>

              {/* Scope 2 Subtotal */}
              <div className="flex items-center justify-between rounded-lg bg-teal-50 px-4 py-3 dark:bg-teal-950/30">
                <span className="flex items-center gap-2 font-medium text-teal-800 dark:text-teal-300">
                  <Zap className="h-4 w-4" />
                  Scope 2 Total ({scope2Method === 'location' ? 'Location' : scope2Method === 'market' ? 'Market' : 'Both'})
                </span>
                <span className="text-xl font-bold text-teal-700 dark:text-teal-400">
                  {fmt(scope2Total)} tCO₂e
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </TabsContent>

        {/* ═══════ SCOPE 3 ═══════════════════════════════════════════════════ */}
        <TabsContent value="scope3" className="space-y-4 pt-4">
          <AnimatePresence mode="wait">
            <motion.div
              key="scope3-content"
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 }}
              transition={{ duration: 0.25 }}
              className="space-y-3"
            >
              {/* Upstream header */}
              <div className="flex items-center gap-2 pt-1">
                <Badge className="bg-green-600 text-white text-xs">Upstream (Cat 1–8)</Badge>
                <Separator className="flex-1" />
              </div>

              {/* Upstream Categories */}
              {SCOPE3_CATEGORIES.slice(0, 8).map((cat) => {
                const rows = scope3Rows[cat.id] || [];
                const isOpen = openCategories[cat.id] ?? false;
                const catItems = scope3AllItems.filter((i) => i.category === cat.name);
                const catTotal = catItems.reduce((s, i) => s + i.emissions, 0);

                return (
                  <Collapsible
                    key={cat.id}
                    open={isOpen}
                    onOpenChange={(v) => setOpenCategories((prev) => ({ ...prev, [cat.id]: v }))}
                    className="rounded-lg border"
                  >
                    <CollapsibleTrigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <span className="text-green-600">{cat.icon}</span>
                        <div className="text-left">
                          <p className="font-medium text-sm">{cat.name}</p>
                        </div>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent side="top" className="max-w-xs">
                            <p className="text-xs">{cat.description}</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-[10px]">
                          {catTotal > 0 ? fmtShort(catTotal) + ' tCO₂e' : '-'}
                        </Badge>
                        <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? 'rotate-90' : ''}`} />
                      </div>
                    </CollapsibleTrigger>

                    <AnimatePresence>
                      {isOpen && (
                        <CollapsibleContent forceMount>
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25 }}
                            className="overflow-hidden"
                          >
                            <div className="border-t p-4 space-y-4 bg-muted/20">
                              {rows.map((row, idx) => {
                                const opt = cat.options?.find((o) => o.value === row.sourceType);
                                const qty = parseFloat(row.quantity) || 0;
                                let emissions = 0;
                                if (opt) {
                                  if (cat.inputType === 'spend' || cat.inputType === 'distance' || cat.inputType === 'weight-distance' || cat.inputType === 'leased-area') {
                                    emissions = (qty * opt.factor) / 1000;
                                  } else if (cat.inputType === 'quantity' && opt.unit === 'tonnes') {
                                    emissions = qty * opt.factor;
                                  } else {
                                    emissions = (qty * opt.factor) / 1000;
                                  }
                                }

                                return (
                                  <EntryRowCard
                                    key={row.id}
                                    row={row}
                                    index={idx}
                                    efLabel={opt ? `EF: ${opt.factor} ${opt.efUnit}` : ''}
                                    calculatedEmissions={emissions}
                                    canDelete={rows.length > 1}
                                    sourceOptions={(cat.options || []).map((o) => ({
                                      label: o.label,
                                      value: o.value,
                                      factorLabel: `(${o.factor} ${o.efUnit})`,
                                    }))}
                                    onUpdate={(id, field, value) => updateScope3Row(cat.id, id, field, value)}
                                    onRemove={(id) => removeScope3Row(cat.id, id)}
                                  />
                                );
                              })}
                              <Button
                                variant="outline"
                                onClick={() => addScope3Row(cat.id, cat.defaultOption || cat.options?.[0]?.value || '')}
                                className="w-full gap-2"
                              >
                                <Plus className="h-4 w-4" /> Add Entry
                              </Button>
                            </div>
                          </motion.div>
                        </CollapsibleContent>
                      )}
                    </AnimatePresence>
                  </Collapsible>
                );
              })}

              {/* Downstream header */}
              <div className="flex items-center gap-2 pt-2">
                <Badge className="bg-amber-600 text-white text-xs">Downstream (Cat 9–15)</Badge>
                <Separator className="flex-1" />
              </div>

              {/* Downstream Categories */}
              {SCOPE3_CATEGORIES.slice(8).map((cat) => {
                const rows = scope3Rows[cat.id] || [];
                const isOpen = openCategories[cat.id] ?? false;
                const catItems = scope3AllItems.filter((i) => i.category === cat.name);
                const catTotal = catItems.reduce((s, i) => s + i.emissions, 0);

                return (
                  <Collapsible
                    key={cat.id}
                    open={isOpen}
                    onOpenChange={(v) => setOpenCategories((prev) => ({ ...prev, [cat.id]: v }))}
                    className="rounded-lg border"
                  >
                    <CollapsibleTrigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <span className="text-amber-600">{cat.icon}</span>
                        <div className="text-left">
                          <p className="font-medium text-sm">{cat.name}</p>
                        </div>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent side="top" className="max-w-xs">
                            <p className="text-xs">{cat.description}</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-[10px]">
                          {catTotal > 0 ? fmtShort(catTotal) + ' tCO₂e' : '-'}
                        </Badge>
                        <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? 'rotate-90' : ''}`} />
                      </div>
                    </CollapsibleTrigger>

                    <AnimatePresence>
                      {isOpen && (
                        <CollapsibleContent forceMount>
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25 }}
                            className="overflow-hidden"
                          >
                            <div className="border-t p-4 space-y-4 bg-muted/20">
                              {rows.map((row, idx) => {
                                const opt = cat.options?.find((o) => o.value === row.sourceType);
                                const qty = parseFloat(row.quantity) || 0;
                                let emissions = 0;
                                if (opt) {
                                  if (cat.inputType === 'spend' || cat.inputType === 'distance' || cat.inputType === 'weight-distance' || cat.inputType === 'leased-area') {
                                    emissions = (qty * opt.factor) / 1000;
                                  } else if (cat.inputType === 'quantity' && opt.unit === 'tonnes') {
                                    emissions = qty * opt.factor;
                                  } else {
                                    emissions = (qty * opt.factor) / 1000;
                                  }
                                }

                                return (
                                  <EntryRowCard
                                    key={row.id}
                                    row={row}
                                    index={idx}
                                    efLabel={opt ? `EF: ${opt.factor} ${opt.efUnit}` : ''}
                                    calculatedEmissions={emissions}
                                    canDelete={rows.length > 1}
                                    sourceOptions={(cat.options || []).map((o) => ({
                                      label: o.label,
                                      value: o.value,
                                      factorLabel: `(${o.factor} ${o.efUnit})`,
                                    }))}
                                    onUpdate={(id, field, value) => updateScope3Row(cat.id, id, field, value)}
                                    onRemove={(id) => removeScope3Row(cat.id, id)}
                                  />
                                );
                              })}
                              <Button
                                variant="outline"
                                onClick={() => addScope3Row(cat.id, cat.defaultOption || cat.options?.[0]?.value || '')}
                                className="w-full gap-2"
                              >
                                <Plus className="h-4 w-4" /> Add Entry
                              </Button>
                            </div>
                          </motion.div>
                        </CollapsibleContent>
                      )}
                    </AnimatePresence>
                  </Collapsible>
                );
              })}

              {/* Scope 3 Subtotal */}
              <div className="flex items-center justify-between rounded-lg bg-amber-50 px-4 py-3 dark:bg-amber-950/30">
                <span className="flex items-center gap-2 font-medium text-amber-800 dark:text-amber-300">
                  <Truck className="h-4 w-4" />
                  Scope 3 Total
                </span>
                <span className="text-xl font-bold text-amber-700 dark:text-amber-400">
                  {fmt(scope3Total)} tCO₂e
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </TabsContent>
      </Tabs>

      {/* Submit Section */}
      <div className="flex flex-col gap-3 rounded-lg border bg-muted/30 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="text-sm text-muted-foreground">
          {totalEmissions > 0 ? (
            <>
              <span className="font-medium text-green-700 dark:text-green-400">S1: {fmt(scope1Total)}</span>
              {' + '}
              <span className="font-medium text-teal-700 dark:text-teal-400">S2: {fmt(scope2Total)}</span>
              {' + '}
              <span className="font-medium text-amber-700 dark:text-amber-400">S3: {fmt(scope3Total)}</span>
              {' = '}
              <span className="font-bold text-emerald-700 dark:text-emerald-400">Total: {fmt(totalEmissions)} tCO₂e</span>
            </>
          ) : (
            'Enter emission data in the tabs above to see calculations.'
          )}
        </div>
        <Button
          onClick={handleSubmit}
          disabled={isSubmitting || totalEmissions <= 0}
          className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
          size="lg"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4" />
              Save &amp; Submit
            </>
          )}
        </Button>
      </div>

      {/* Previous Submissions */}
      <Card>
        <Collapsible open={showSubmissions} onOpenChange={setShowSubmissions}>
          <CardHeader className="cursor-pointer select-none" onClick={() => setShowSubmissions(!showSubmissions)}>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-muted-foreground" />
                Previous Submissions
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">{previousSubmissions.length} records</Badge>
                <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${showSubmissions ? 'rotate-180' : ''}`} />
              </div>
            </div>
          </CardHeader>

          <AnimatePresence>
            {showSubmissions && (
              <CollapsibleContent forceMount>
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <CardContent>
                    {loadingSubmissions ? (
                      <div className="space-y-3">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="flex items-center justify-between">
                            <Skeleton className="h-5 w-40" />
                            <Skeleton className="h-5 w-24" />
                            <Skeleton className="h-5 w-16" />
                          </div>
                        ))}
                      </div>
                    ) : previousSubmissions.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        <Leaf className="mb-2 h-8 w-8 text-muted-foreground/50" />
                        <p className="text-sm text-muted-foreground">
                          No previous submissions found. Submit your first GHG emissions report above.
                        </p>
                      </div>
                    ) : (
                      <div className="max-h-96 space-y-3 overflow-y-auto pr-1">
                        {previousSubmissions.map((entry) => (
                          <div
                            key={entry.id}
                            className="flex flex-col gap-1 rounded-lg border px-4 py-3 transition-colors hover:bg-muted/50 sm:flex-row sm:items-center sm:justify-between"
                          >
                            <div className="flex flex-col gap-0.5">
                              <span className="font-medium">{formatPeriod(entry.reportingPeriod)}</span>
                              <span className="text-xs text-muted-foreground">
                                {entry.createdAt
                                  ? new Date(entry.createdAt).toLocaleDateString('en-MY', {
                                      day: 'numeric', month: 'short', year: 'numeric',
                                    })
                                  : '-'}
                              </span>
                            </div>
                            <div className="flex flex-wrap items-center gap-2 text-sm">
                              {entry.scope1Total > 0 && (
                                <span className="text-muted-foreground">
                                  S1:<span className="ml-0.5 font-medium text-green-700 dark:text-green-400">{fmtShort(entry.scope1Total)}</span>
                                </span>
                              )}
                              {entry.scope2Total > 0 && (
                                <span className="text-muted-foreground">
                                  S2:<span className="ml-0.5 font-medium text-teal-700 dark:text-teal-400">{fmtShort(entry.scope2Total)}</span>
                                </span>
                              )}
                              {entry.scope3Total > 0 && (
                                <span className="text-muted-foreground">
                                  S3:<span className="ml-0.5 font-medium text-amber-700 dark:text-amber-400">{fmtShort(entry.scope3Total)}</span>
                                </span>
                              )}
                              <Badge variant="secondary" className="min-w-[6rem] justify-center font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
                                {fmtShort(entry.totalEmissions)} tCO₂e
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </motion.div>
              </CollapsibleContent>
            )}
          </AnimatePresence>
        </Collapsible>
      </Card>
    </div>
  );
}

// ─── Reusable Scope Section Sub-component ──────────────────────────────────

function ScopeSection({
  title,
  icon,
  description,
  rows,
  sourceOptions,
  getEFLabel,
  getEmissions,
  defaultAddType,
  onUpdate,
  onAdd,
  onRemove,
}: {
  title: string;
  icon: React.ReactNode;
  description: string;
  rows: EntryRow[];
  sourceOptions: { label: string; value: string; factorLabel?: string }[];
  getEFLabel: (sourceType: string) => string;
  getEmissions: (row: EntryRow) => number;
  defaultAddType: string;
  onUpdate: (id: string, field: 'sourceType' | 'quantity', value: string) => void;
  onAdd: () => void;
  onRemove: (id: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(true);
  const subtotal = useMemo(() => rows.reduce((sum, r) => sum + getEmissions(r), 0), [rows, getEmissions]);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="rounded-lg border">
      <CollapsibleTrigger className="flex w-full items-center justify-between p-4 hover:bg-muted/50 transition-colors">
        <div className="flex items-center gap-3">
          {icon}
          <div className="text-left">
            <p className="font-medium">{title}</p>
            <p className="text-xs text-muted-foreground">{description}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {subtotal > 0 ? fmtShort(subtotal) + ' tCO₂e' : '-'}
          </Badge>
          <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? 'rotate-90' : ''}`} />
        </div>
      </CollapsibleTrigger>

      <AnimatePresence>
        {isOpen && (
          <CollapsibleContent forceMount>
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="border-t p-4 space-y-4 bg-muted/20">
                {rows.map((row, idx) => (
                  <EntryRowCard
                    key={row.id}
                    row={row}
                    index={idx}
                    efLabel={getEFLabel(row.sourceType)}
                    calculatedEmissions={getEmissions(row)}
                    canDelete={rows.length > 1}
                    sourceOptions={sourceOptions}
                    onUpdate={onUpdate}
                    onRemove={onRemove}
                  />
                ))}
                <Button variant="outline" onClick={onAdd} className="w-full gap-2">
                  <Plus className="h-4 w-4" /> Add {title} Entry
                </Button>
              </div>
            </motion.div>
          </CollapsibleContent>
        )}
      </AnimatePresence>
    </Collapsible>
  );
}
