'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2,
  Briefcase,
  MapPin,
  Check,
  Loader2,
  ArrowLeft,
  ArrowRight,
  CircleCheckBig,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import {
  INDUSTRY_SECTORS,
  REVENUE_RANGES,
  MALAYSIAN_STATES,
  classifyCompany,
} from '@/data/constants';
import type { OnboardingFormData, CompanyData } from '@/types';

interface OnboardingViewProps {
  userId: string;
  companyId?: string;
  onComplete: () => void;
}

const STEPS = [
  { number: 1, title: 'Company Basics', icon: Building2 },
  { number: 2, title: 'Business Profile', icon: Briefcase },
  { number: 3, title: 'Location & Review', icon: MapPin },
] as const;

const INITIAL_FORM: OnboardingFormData = {
  companyName: '',
  registrationNumber: '',
  industrySector: '',
  annualRevenue: '',
  numberOfEmployees: 0,
  state: '',
};

const COMPANY_SIZE_COLORS: Record<string, string> = {
  Micro: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300',
  Small: 'bg-sky-100 text-sky-800 dark:bg-sky-900/30 dark:text-sky-300',
  Medium: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
  Large: 'bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300',
};

export default function OnboardingView({
  userId,
  companyId,
  onComplete,
}: OnboardingViewProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [form, setForm] = useState<OnboardingFormData>({ ...INITIAL_FORM });
  const [errors, setErrors] = useState<Partial<Record<keyof OnboardingFormData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(!!companyId);
  const { toast } = useToast();

  // Fetch existing company data if editing
  useEffect(() => {
    if (!companyId) return;

    async function fetchCompany() {
      try {
        const res = await fetch(`/api/company?userId=${encodeURIComponent(userId)}`);
        if (!res.ok) throw new Error('Failed to fetch company data');
        const data: CompanyData = await res.json();

        setForm({
          companyName: data.companyName || '',
          registrationNumber: data.registrationNumber || '',
          industrySector: data.industrySector || '',
          annualRevenue: data.annualRevenue || '',
          numberOfEmployees: data.numberOfEmployees || 0,
          state: data.state || '',
        });
      } catch {
        toast({
          title: 'Error',
          description: 'Failed to load existing company data.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    }

    fetchCompany();
  }, [companyId, userId, toast]);

  const updateField = useCallback(
    <K extends keyof OnboardingFormData>(field: K, value: OnboardingFormData[K]) => {
      setForm((prev) => ({ ...prev, [field]: value }));
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    },
    [],
  );

  // ─── Validation ───────────────────────────────────────────────────────
  function validateStep(step: number): boolean {
    const newErrors: Partial<Record<keyof OnboardingFormData, string>> = {};

    if (step === 0) {
      if (!form.companyName.trim()) {
        newErrors.companyName = 'Company name is required.';
      }
    } else if (step === 1) {
      if (!form.industrySector) {
        newErrors.industrySector = 'Please select an industry sector.';
      }
      if (!form.annualRevenue) {
        newErrors.annualRevenue = 'Please select an annual revenue range.';
      }
      if (!form.numberOfEmployees || form.numberOfEmployees <= 0) {
        newErrors.numberOfEmployees = 'Please enter a valid number of employees.';
      }
    } else if (step === 2) {
      if (!form.state) {
        newErrors.state = 'Please select a state.';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleNext() {
    if (!validateStep(currentStep)) return;
    setCurrentStep((s) => Math.min(s + 1, STEPS.length - 1));
  }

  function handleBack() {
    setErrors({});
    setCurrentStep((s) => Math.max(s - 1, 0));
  }

  // ─── Submit ───────────────────────────────────────────────────────────
  async function handleSubmit() {
    if (!validateStep(currentStep)) return;

    setIsSubmitting(true);
    try {
      const payload = {
        ...form,
        numberOfEmployees: Number(form.numberOfEmployees),
        companySize: classifyCompany(form.annualRevenue, Number(form.numberOfEmployees)),
      };

      const res = await fetch('/api/company', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, ...payload }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || 'Failed to save company profile.');
      }

      toast({
        title: 'Company profile saved!',
        description: 'Your company information has been saved successfully.',
      });

      setIsSuccess(true);

      // Auto-redirect after showing success animation
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch (err) {
      toast({
        title: 'Submission failed',
        description: err instanceof Error ? err.message : 'An unexpected error occurred.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  // ─── Computed values ──────────────────────────────────────────────────
  const companySize =
    form.annualRevenue && form.numberOfEmployees > 0
      ? classifyCompany(form.annualRevenue, form.numberOfEmployees)
      : null;

  const progressPercent = ((currentStep + 1) / STEPS.length) * 100;

  // ─── Loading state ────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Loading company data...</p>
        </div>
      </div>
    );
  }

  // ─── Success state ────────────────────────────────────────────────────
  if (isSuccess) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          className="flex flex-col items-center gap-4 text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 300 }}
            className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/30"
          >
            <CircleCheckBig className="h-10 w-10 text-emerald-600 dark:text-emerald-400" />
          </motion.div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Company profile saved!</h2>
            <p className="mt-1 text-muted-foreground">
              Redirecting you to the dashboard...
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  // ─── Step Indicator ───────────────────────────────────────────────────
  function StepIndicator() {
    return (
      <div className="mb-8">
        {/* Step circles + connectors */}
        <div className="flex items-center justify-between">
          {STEPS.map((step, idx) => {
            const isCompleted = idx < currentStep;
            const isCurrent = idx === currentStep;
            const Icon = step.icon;

            return (
              <div key={step.number} className="flex flex-1 items-center">
                <div className="flex flex-col items-center gap-2">
                  <div
                    className={`
                      flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all duration-300
                      ${
                        isCompleted
                          ? 'border-emerald-500 bg-emerald-500 text-white'
                          : isCurrent
                            ? 'border-primary bg-primary text-primary-foreground shadow-md'
                            : 'border-muted-foreground/30 bg-background text-muted-foreground'
                      }
                    `}
                  >
                    {isCompleted ? (
                      <Check className="h-5 w-5" />
                    ) : (
                      <Icon className="h-4 w-4" />
                    )}
                  </div>
                  <span
                    className={`text-xs font-medium whitespace-nowrap ${
                      isCurrent
                        ? 'text-primary'
                        : isCompleted
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-muted-foreground'
                    }`}
                  >
                    {step.title}
                  </span>
                </div>
                {idx < STEPS.length - 1 && (
                  <div className="mx-3 mt-[-1.5rem] h-0.5 flex-1">
                    <div
                      className={`h-full rounded-full transition-colors duration-300 ${
                        idx < currentStep
                          ? 'bg-emerald-500'
                          : 'bg-muted-foreground/20'
                      }`}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Progress bar */}
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            Step {currentStep + 1} of {STEPS.length}
          </span>
          <Progress value={progressPercent} className="h-1.5 w-40" />
        </div>
      </div>
    );
  }

  // ─── Step 1: Company Basics ───────────────────────────────────────────
  function StepCompanyBasics() {
    return (
      <motion.div
        key="step-1"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.25 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Company Basics</CardTitle>
            <CardDescription>
              Let&apos;s start with the essential details about your company.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="companyName">
                Company Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="companyName"
                placeholder="Enter your registered company name"
                value={form.companyName}
                onChange={(e) => updateField('companyName', e.target.value)}
                aria-invalid={!!errors.companyName}
                className={errors.companyName ? 'border-destructive' : ''}
              />
              {errors.companyName && (
                <p className="text-sm text-destructive">{errors.companyName}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="registrationNumber">Registration Number</Label>
              <Input
                id="registrationNumber"
                placeholder="e.g., 202301234567"
                value={form.registrationNumber}
                onChange={(e) => updateField('registrationNumber', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                SSM registration number (optional)
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // ─── Step 2: Business Profile ─────────────────────────────────────────
  function StepBusinessProfile() {
    return (
      <motion.div
        key="step-2"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.25 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Business Profile</CardTitle>
            <CardDescription>
              Tell us about your business to help tailor your ESG journey.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="industrySector">
                Industry Sector <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.industrySector}
                onValueChange={(val) => updateField('industrySector', val)}
              >
                <SelectTrigger
                  id="industrySector"
                  className={`w-full ${errors.industrySector ? 'border-destructive' : ''}`}
                >
                  <SelectValue placeholder="Select your industry sector" />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {INDUSTRY_SECTORS.map((sector) => (
                    <SelectItem key={sector} value={sector}>
                      {sector}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.industrySector && (
                <p className="text-sm text-destructive">{errors.industrySector}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="annualRevenue">
                Annual Revenue <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.annualRevenue}
                onValueChange={(val) => updateField('annualRevenue', val)}
              >
                <SelectTrigger
                  id="annualRevenue"
                  className={`w-full ${errors.annualRevenue ? 'border-destructive' : ''}`}
                >
                  <SelectValue placeholder="Select your annual revenue range" />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {REVENUE_RANGES.map((range) => (
                    <SelectItem key={range} value={range}>
                      {range}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.annualRevenue && (
                <p className="text-sm text-destructive">{errors.annualRevenue}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="numberOfEmployees">
                Number of Employees <span className="text-destructive">*</span>
              </Label>
              <Input
                id="numberOfEmployees"
                type="number"
                min={1}
                placeholder="e.g., 50"
                value={form.numberOfEmployees || ''}
                onChange={(e) =>
                  updateField('numberOfEmployees', parseInt(e.target.value, 10) || 0)
                }
                aria-invalid={!!errors.numberOfEmployees}
                className={errors.numberOfEmployees ? 'border-destructive' : ''}
              />
              {errors.numberOfEmployees && (
                <p className="text-sm text-destructive">{errors.numberOfEmployees}</p>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // ─── Step 3: Location & Review ────────────────────────────────────────
  function StepLocationReview() {
    return (
      <motion.div
        key="step-3"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.25 }}
      >
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Location</CardTitle>
              <CardDescription>
                Where is your company based?
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="state">
                  State <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={form.state}
                  onValueChange={(val) => updateField('state', val)}
                >
                  <SelectTrigger
                    id="state"
                    className={`w-full ${errors.state ? 'border-destructive' : ''}`}
                  >
                    <SelectValue placeholder="Select your state" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {MALAYSIAN_STATES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.state && (
                  <p className="text-sm text-destructive">{errors.state}</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Review Your Information</CardTitle>
              <CardDescription>
                Please verify all details before submitting.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border bg-muted/30 p-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <ReviewItem label="Company Name" value={form.companyName} />
                  <ReviewItem
                    label="Registration Number"
                    value={form.registrationNumber || '-'}
                  />
                  <ReviewItem label="Industry Sector" value={form.industrySector} />
                  <ReviewItem label="Annual Revenue" value={form.annualRevenue} />
                  <ReviewItem
                    label="Number of Employees"
                    value={
                      form.numberOfEmployees
                        ? form.numberOfEmployees.toLocaleString()
                        : '-'
                    }
                  />
                  <ReviewItem label="State" value={form.state} />
                </div>

                {/* Company size classification */}
                {companySize && (
                  <div className="mt-4 border-t pt-4">
                    <p className="text-sm text-muted-foreground">
                      Based on your revenue and employee count, your company is classified as:{' '}
                      <span
                        className={`inline-block mt-1 rounded-full px-3 py-0.5 text-sm font-semibold ${
                          COMPANY_SIZE_COLORS[companySize] || 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {companySize}
                      </span>
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    );
  }

  // ─── Render ───────────────────────────────────────────────────────────
  return (
    <section className="mx-auto w-full max-w-2xl px-4 py-8 sm:py-12" aria-label="Company Onboarding">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          {companyId ? 'Edit Company Profile' : 'Set Up Your Company Profile'}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {companyId
            ? 'Update your company information below.'
            : 'Complete these steps to get started with SustainHub.'}
        </p>
      </div>

      <StepIndicator />

      <AnimatePresence mode="wait">
        {currentStep === 0 && <StepCompanyBasics />}
        {currentStep === 1 && <StepBusinessProfile />}
        {currentStep === 2 && <StepLocationReview />}
      </AnimatePresence>

      {/* Navigation buttons */}
      <div className="mt-6 flex items-center justify-between">
        <Button
          variant="outline"
          onClick={handleBack}
          disabled={currentStep === 0}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>

        {currentStep < STEPS.length - 1 ? (
          <Button onClick={handleNext} className="gap-2">
            Next
            <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="gap-2 bg-emerald-600 text-white hover:bg-emerald-700"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Check className="h-4 w-4" />
                Submit Profile
              </>
            )}
          </Button>
        )}
      </div>
    </section>
  );
}

// ─── Helper: Review Item ────────────────────────────────────────────────
function ReviewItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="space-y-0.5">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold text-foreground">{value || '-'}</p>
    </div>
  );
}