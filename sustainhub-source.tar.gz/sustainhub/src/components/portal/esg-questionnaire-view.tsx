'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  RadioGroup,
  RadioGroupItem,
} from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import {
  ESG_INDICATORS,
  GOVERNANCE_INDICATORS,
  ENVIRONMENTAL_INDICATORS,
  SOCIAL_INDICATORS,
} from '@/data/esg-indicators';
import { useToast } from '@/hooks/use-toast';
import {
  Shield,
  Leaf,
  Users,
  ChevronLeft,
  ChevronRight,
  Save,
  CheckCircle,
  HelpCircle,
  AlertCircle,
  ChevronDown,
  StickyNote,
} from 'lucide-react';
import type { EsgIndicator } from '@/types';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface EsgQuestionnaireViewProps {
  userId: string;
  companyId: string;
}

interface SavedResponse {
  indicatorCode: string;
  indicatorLabel: string;
  section: string;
  responseValue: string | null;
  notes: string | null;
}

type SectionKey = 'Governance' | 'Environmental' | 'Social';

interface SectionMeta {
  key: SectionKey;
  label: string;
  description: string;
  icon: React.ReactNode;
  indicators: EsgIndicator[];
  accentBorder: string;
  accentBg: string;
  accentBadge: string;
  accentText: string;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const SECTIONS: SectionMeta[] = [
  {
    key: 'Governance',
    label: 'Governance',
    description: 'Corporate governance practices and board structure',
    icon: <Shield className="size-4" />,
    indicators: GOVERNANCE_INDICATORS,
    accentBorder: 'border-l-teal-500',
    accentBg: 'bg-teal-50 dark:bg-teal-950/30',
    accentBadge: 'bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300',
    accentText: 'text-teal-600 dark:text-teal-400',
  },
  {
    key: 'Environmental',
    label: 'Environmental',
    description: 'Environmental impact and resource management',
    icon: <Leaf className="size-4" />,
    indicators: ENVIRONMENTAL_INDICATORS,
    accentBorder: 'border-l-green-500',
    accentBg: 'bg-green-50 dark:bg-green-950/30',
    accentBadge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',
    accentText: 'text-green-600 dark:text-green-400',
  },
  {
    key: 'Social',
    label: 'Social',
    description: 'Social responsibility and employee welfare',
    icon: <Users className="size-4" />,
    indicators: SOCIAL_INDICATORS,
    accentBorder: 'border-l-amber-500',
    accentBg: 'bg-amber-50 dark:bg-amber-950/30',
    accentBadge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    accentText: 'text-amber-600 dark:text-amber-400',
  },
];

const TOTAL_INDICATORS = ESG_INDICATORS.length; // 35

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function EsgQuestionnaireView({
  userId,
  companyId,
}: EsgQuestionnaireViewProps) {
  const { toast } = useToast();

  // -- State ----------------------------------------------------------------
  const [activeSectionIndex, setActiveSectionIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // responses keyed by indicator code
  const [responses, setResponses] = useState<Record<string, string>>({});
  // notes keyed by indicator code
  const [notes, setNotes] = useState<Record<string, string>>({});
  // which notes are expanded
  const [expandedNotes, setExpandedNotes] = useState<Record<string, boolean>>({});

  // auto-save debounce timer ref
  const autoSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const initialized = useRef(false);

  const activeSection = SECTIONS[activeSectionIndex];

  // -- Progress -------------------------------------------------------------
  const completedCount = ESG_INDICATORS.filter(
    (ind) => responses[ind.code]?.trim() !== ''
  ).length;
  const progressPercent = Math.round((completedCount / TOTAL_INDICATORS) * 100);

  // Section completion
  const getSectionCompletion = (section: SectionMeta) => {
    const filled = section.indicators.filter(
      (ind) => responses[ind.code]?.trim() !== ''
    ).length;
    return filled;
  };

  // -- Fetch existing data --------------------------------------------------
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    const fetchData = async () => {
      try {
        const res = await fetch(`/api/esg?userId=${userId}&companyId=${companyId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.responses && Array.isArray(data.responses)) {
            const rMap: Record<string, string> = {};
            const nMap: Record<string, string> = {};
            (data.responses as SavedResponse[]).forEach((r: SavedResponse) => {
              if (r.responseValue) rMap[r.indicatorCode] = r.responseValue;
              if (r.notes) nMap[r.indicatorCode] = r.notes;
            });
            setResponses(rMap);
            setNotes(nMap);
          }
        }
      } catch {
        // Silently fail, user can still fill the form
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [userId, companyId]);

  // -- Auto-save on change --------------------------------------------------
  const triggerAutoSave = useCallback(() => {
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(() => {
      saveCurrentSection(true); // silent
    }, 1500);
    }, [activeSectionIndex]);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    };
  }, []);

  // -- Update handlers ------------------------------------------------------
  const handleResponseChange = (code: string, value: string) => {
    setResponses((prev) => ({ ...prev, [code]: value }));
    triggerAutoSave();
  };

  const handleNotesChange = (code: string, value: string) => {
    setNotes((prev) => ({ ...prev, [code]: value }));
    triggerAutoSave();
  };

  const toggleNotes = (code: string) => {
    setExpandedNotes((prev) => ({ ...prev, [code]: !prev[code] }));
  };

  // -- Save / Submit --------------------------------------------------------
  const buildPayload = (sectionOnly?: SectionKey) => {
    const indicators = sectionOnly
      ? ESG_INDICATORS.filter((i) => i.section === sectionOnly)
      : ESG_INDICATORS;

    const reportingPeriod = `${new Date().getFullYear()}`;
    const resps = indicators.map((ind) => ({
      indicatorCode: ind.code,
      indicatorLabel: ind.label,
      section: ind.section,
      responseValue: responses[ind.code] || null,
      notes: notes[ind.code] || null,
    }));

    return { userId, companyId, reportingPeriod, responses: resps };
  };

  const saveCurrentSection = async (silent = false) => {
    setIsSaving(true);
    try {
      const payload = buildPayload(activeSection.key);
      const res = await fetch('/api/esg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('Save failed');
      if (!silent) {
        toast({
          title: 'Progress saved',
          description: `${activeSection.label} section saved successfully.`,
        });
      }
    } catch {
      if (!silent) {
        toast({
          title: 'Save failed',
          description: 'Could not save progress. Please try again.',
          variant: 'destructive',
        });
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const payload = buildPayload();
      const res = await fetch('/api/esg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, submit: true }),
      });
      if (!res.ok) throw new Error('Submit failed');
      toast({
        title: 'Questionnaire submitted!',
        description: 'Your ESG questionnaire has been submitted successfully.',
      });
    } catch {
      toast({
        title: 'Submission failed',
        description: 'Could not submit questionnaire. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // -- Navigation -----------------------------------------------------------
  const goToSection = (index: number) => {
    setActiveSectionIndex(index);
  };

  const goNext = () => {
    if (activeSectionIndex < SECTIONS.length - 1) {
      setActiveSectionIndex((i) => i + 1);
    }
  };

  const goPrev = () => {
    if (activeSectionIndex > 0) {
      setActiveSectionIndex((i) => i - 1);
    }
  };

  // -- Required validation --------------------------------------------------
  const getMissingRequired = (section: SectionMeta) => {
    return section.indicators.filter(
      (ind) => ind.required && !responses[ind.code]?.trim()
    );
  };

  // -- Render: Indicator Input -----------------------------------------------
  const renderIndicatorInput = (indicator: EsgIndicator) => {
    const value = responses[indicator.code] || '';

    switch (indicator.type) {
      case 'text':
        return (
          <Textarea
            placeholder={indicator.placeholder || ''}
            value={value}
            onChange={(e) => handleResponseChange(indicator.code, e.target.value)}
            onBlur={() => saveCurrentSection(true)}
            className="min-h-[80px] resize-y"
          />
        );

      case 'number':
        return (
          <Input
            type="number"
            step="any"
            placeholder={indicator.placeholder || ''}
            value={value}
            onChange={(e) => handleResponseChange(indicator.code, e.target.value)}
            onBlur={() => saveCurrentSection(true)}
          />
        );

      case 'percentage':
        return (
          <div className="relative">
            <Input
              type="number"
              step="any"
              min="0"
              max="100"
              placeholder={indicator.placeholder || '0'}
              value={value}
              onChange={(e) => handleResponseChange(indicator.code, e.target.value)}
              onBlur={() => saveCurrentSection(true)}
              className="pr-8"
            />
            <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
              %
            </span>
          </div>
        );

      case 'yesno':
        return (
          <RadioGroup
            value={value}
            onValueChange={(v) => handleResponseChange(indicator.code, v)}
            className="flex gap-3"
          >
            {/* Yes pill */}
            <label
              className={`flex cursor-pointer items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-all ${
                value === 'Yes'
                  ? 'border-primary bg-primary text-primary-foreground shadow-sm'
                  : 'border-input bg-background hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              <RadioGroupItem value="Yes" className="sr-only" />
              <CheckCircle className="size-4" />
              Yes
            </label>
            {/* No pill */}
            <label
              className={`flex cursor-pointer items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-all ${
                value === 'No'
                  ? 'border-destructive bg-destructive text-destructive-foreground shadow-sm'
                  : 'border-input bg-background hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              <RadioGroupItem value="No" className="sr-only" />
              <AlertCircle className="size-4" />
              No
            </label>
          </RadioGroup>
        );

      case 'select':
        return (
          <Select
            value={value}
            onValueChange={(v) => handleResponseChange(indicator.code, v)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select an option..." />
            </SelectTrigger>
            <SelectContent>
              {indicator.options?.map((opt) => (
                <SelectItem key={opt} value={opt}>
                  {opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      default:
        return null;
    }
  };

  // -- Render: Loading State ------------------------------------------------
  if (isLoading) {
    return (
      <div className="mx-auto w-full max-w-3xl space-y-6 p-4 sm:p-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-full" />
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  // -- Render ---------------------------------------------------------------
  return (
    <TooltipProvider>
      <div className="mx-auto w-full max-w-3xl space-y-6 p-4 sm:p-6">
        {/* ===== Header ===== */}
        <div className="space-y-2">
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
            SEDG Questionnaire
          </h2>
          <p className="text-muted-foreground text-sm">
            Complete all 35 indicators across the three ESG pillars to assess your
            company&apos;s sustainability performance.
          </p>
        </div>

        {/* ===== Overall Progress ===== */}
        <Card className="p-4">
          <div className="flex items-center justify-between text-sm font-medium">
            <span>Overall Progress</span>
            <span className="text-muted-foreground">
              {completedCount} / {TOTAL_INDICATORS} indicators completed
            </span>
          </div>
          <Progress value={progressPercent} className="mt-2 h-2.5" />
        </Card>

        {/* ===== Section Tabs ===== */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3">
          {SECTIONS.map((section, idx) => {
            const sectionCompleted = getSectionCompletion(section);
            const isActive = idx === activeSectionIndex;

            return (
              <button
                key={section.key}
                onClick={() => goToSection(idx)}
                className={`flex flex-col items-center gap-1.5 rounded-lg border-2 p-3 text-sm transition-all hover:shadow-sm sm:flex-row sm:gap-2 sm:px-4 ${
                  isActive
                    ? `${section.accentBorder} ${section.accentBg} shadow-sm`
                    : 'border-transparent bg-muted/50 hover:bg-muted'
                }`}
              >
                <span className={`flex items-center gap-1.5 font-semibold ${isActive ? section.accentText : ''}`}>
                  {section.icon}
                  <span className="hidden sm:inline">{section.label}</span>
                  <span className="sm:hidden">{section.label.slice(0, 3)}</span>
                </span>
                <Badge
                  variant={sectionCompleted > 0 ? 'default' : 'secondary'}
                  className={`text-xs ${isActive ? section.accentBadge : ''}`}
                >
                  {sectionCompleted}/{section.indicators.length}
                </Badge>
              </button>
            );
          })}
        </div>

        {/* ===== Active Section ===== */}
        <Card className="overflow-hidden">
          <CardHeader className={`${activeSection.accentBg} border-b`}>
            <div className="flex items-center gap-2">
              <span className={activeSection.accentText}>{activeSection.icon}</span>
              <CardTitle className="text-lg">{activeSection.label}</CardTitle>
            </div>
            <p className="text-muted-foreground text-sm">
              {activeSection.description}
            </p>
          </CardHeader>

          <CardContent className="space-y-4 p-4 sm:p-6">
            {activeSection.indicators.map((indicator) => {
              const hasValue = responses[indicator.code]?.trim() !== '';
              const hasNotes = notes[indicator.code]?.trim() !== '';
              const isExpanded = expandedNotes[indicator.code] || false;

              return (
                <div
                  key={indicator.code}
                  className={`rounded-lg border-l-4 p-4 transition-colors ${
                    activeSection.accentBorder
                  } ${
                    hasValue
                      ? activeSection.accentBg
                      : 'bg-card'
                  }`}
                >
                  {/* Indicator Label Row */}
                  <div className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5 shrink-0 font-mono text-xs">
                      {indicator.code}
                    </Badge>

                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-1.5">
                        <Label
                          htmlFor={indicator.code}
                          className="text-sm font-medium leading-snug"
                        >
                          {indicator.label}
                        </Label>
                        {indicator.required && (
                          <span className="text-destructive text-xs font-bold">*</span>
                        )}
                        {indicator.tooltip && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                type="button"
                                className="text-muted-foreground hover:text-foreground transition-colors"
                                aria-label={`Help for ${indicator.label}`}
                              >
                                <HelpCircle className="size-3.5" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent
                              side="right"
                              className="max-w-xs text-xs leading-relaxed"
                              sideOffset={8}
                            >
                              {indicator.tooltip}
                            </TooltipContent>
                          </Tooltip>
                        )}
                        {hasValue && (
                          <CheckCircle className="ml-auto size-4 shrink-0 text-green-500" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Input */}
                  <div className="mt-3" id={indicator.code}>
                    {renderIndicatorInput(indicator)}
                  </div>

                  {/* Notes Collapsible */}
                  <Collapsible
                    open={isExpanded}
                    onOpenChange={(open) => toggleNotes(indicator.code)}
                    className="mt-2"
                  >
                    <CollapsibleTrigger asChild>
                      <button
                        type="button"
                        className="text-muted-foreground hover:text-foreground flex items-center gap-1 text-xs transition-colors"
                      >
                        <StickyNote className="size-3" />
                        {hasNotes ? 'Edit notes' : 'Add notes'}
                        <ChevronDown
                          className={`size-3 transition-transform ${
                            isExpanded ? 'rotate-180' : ''
                          }`}
                        />
                        {hasNotes && (
                          <Badge variant="secondary" className="ml-1 text-[10px] px-1.5 py-0">
                            has note
                          </Badge>
                        )}
                      </button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-2">
                      <Textarea
                        placeholder="Optional notes for this indicator..."
                        value={notes[indicator.code] || ''}
                        onChange={(e) =>
                          handleNotesChange(indicator.code, e.target.value)
                        }
                        onBlur={() => saveCurrentSection(true)}
                        className="min-h-[60px] resize-y text-xs"
                      />
                    </CollapsibleContent>
                  </Collapsible>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* ===== Navigation & Actions ===== */}
        <Separator />

        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
          {/* Left: Prev button */}
          <Button
            variant="outline"
            onClick={goPrev}
            disabled={activeSectionIndex === 0}
            className="gap-1.5"
          >
            <ChevronLeft className="size-4" />
            Previous Section
          </Button>

          {/* Right: Save, Next, Submit */}
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => saveCurrentSection(false)}
              disabled={isSaving}
              className="gap-1.5"
            >
              <Save className="size-4" />
              {isSaving ? 'Saving...' : 'Save Progress'}
            </Button>

            {activeSectionIndex < SECTIONS.length - 1 ? (
              <Button onClick={goNext} className="gap-1.5">
                Next Section
                <ChevronRight className="size-4" />
              </Button>
            ) : (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    disabled={isSubmitting}
                    className="gap-1.5 bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle className="size-4" />
                    {isSubmitting ? 'Submitting...' : 'Submit All'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Submit Questionnaire?</AlertDialogTitle>
                    <AlertDialogDescription>
                      You are about to submit your SEDG questionnaire with{' '}
                      <strong>{completedCount}</strong> of{' '}
                      <strong>{TOTAL_INDICATORS}</strong> indicators completed.
                      {getMissingRequired(SECTIONS[2]).length > 0 && (
                        <span className="mt-2 block text-destructive">
                          Note: There are{' '}
                          {getMissingRequired(SECTIONS[2]).length} required
                          indicators in the Social section that have not been
                          filled.
                        </span>
                      )}
                      <span className="mt-2 block">
                        Once submitted, you can still edit your responses later.
                      </span>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleSubmit}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Confirm Submit
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}