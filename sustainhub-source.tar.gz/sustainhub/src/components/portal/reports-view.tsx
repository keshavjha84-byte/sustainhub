"use client";

import { useQuery } from "@tanstack/react-query";
import {
  Printer,
  Download,
  FileText,
  Building,
  Leaf,
  Shield,
  Users,
  AlertTriangle,
  Flame,
  Zap,
  Factory,
  ArrowDownUp,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { GhgEntry, EsgResponse, CompanyData, EmissionItem } from "@/types";

// ── Types ───────────────────────────────────────────────────────────
interface DashboardSummary {
  esgReadinessScore: number;
  totalEmissions: number | null;
  latestReportingPeriod: string | null;
  completedIndicators: number;
  totalIndicators: number;
  sectionProgress: {
    governance: number;
    environmental: number;
    social: number;
  };
  company: CompanyData | null;
}

interface ReportsViewProps {
  userId: string;
}

// ── Helpers ─────────────────────────────────────────────────────────
function getScoreColor(score: number): string {
  if (score < 30) return "#ef4444";
  if (score <= 60) return "#f59e0b";
  return "#10b981";
}

function getScoreLabel(score: number): string {
  if (score < 30) return "Early Stage";
  if (score <= 60) return "Developing";
  return "Advanced";
}

function getScoreRecommendation(score: number): string {
  if (score < 30) {
    return "Your ESG readiness is in the early stages. Focus on completing the SEDG questionnaire and calculating your GHG emissions baseline. Prioritise governance structures and environmental data collection to build a foundation for sustainable reporting.";
  }
  if (score <= 60) {
    return "Good progress on your ESG journey. Continue filling in outstanding SEDG indicators and work towards reducing your carbon footprint. Consider setting measurable targets for each ESG pillar to demonstrate ongoing commitment to sustainability.";
  }
  return "Excellent ESG readiness! Your organisation demonstrates strong sustainability practices. Maintain your reporting cadence, set ambitious reduction targets, and explore opportunities to lead in your industry sector. Consider sharing your progress with stakeholders.";
  }

function getSectionRowBg(section: string): string {
  switch (section) {
    case "Governance":
      return "bg-teal-500/5";
    case "Environmental":
      return "bg-green-500/5";
    case "Social":
      return "bg-amber-500/5";
    default:
      return "";
  }
}

function getSectionBadgeColor(section: string): string {
  switch (section) {
    case "Governance":
      return "bg-teal-500/10 text-teal-700 border-teal-200";
    case "Environmental":
      return "bg-green-500/10 text-green-700 border-green-200";
    case "Social":
      return "bg-amber-500/10 text-amber-700 border-amber-200";
    default:
      return "";
  }
}

function formatEmissions(val: number): string {
  if (val === 0) return "0.000";
  return val.toFixed(3);
}

function todayDateString(): string {
  return new Date().toLocaleDateString("en-MY", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

// ── GHG Backward-Compatibility Helpers ────────────────────────────

/** Convert old scope1Items/scope2Items to EmissionItem[] */
function normalizeEmissionItems(entry: GhgEntry): EmissionItem[] {
  // New format already has emissionItems
  if (entry.emissionItems && entry.emissionItems.length > 0) {
    return entry.emissionItems;
  }
  const items: EmissionItem[] = [];
  // Convert old Scope1Item[]
  if (entry.scope1Items && entry.scope1Items.length > 0) {
    for (const s1 of entry.scope1Items) {
      items.push({
        scope: 1,
        category: "Stationary Combustion",
        sourceName: s1.fuelType,
        activityData: s1.quantity,
        activityUnit: s1.unit,
        emissionFactor: s1.quantity > 0 ? s1.emissions / s1.quantity : 0,
        efUnit: "tCO₂e/unit",
        emissions: s1.emissions,
      });
    }
  }
  // Convert old Scope2Item[]
  if (entry.scope2Items && entry.scope2Items.length > 0) {
    for (const s2 of entry.scope2Items) {
      items.push({
        scope: 2,
        category: "Electricity Consumption",
        sourceName: `Grid (${s2.gridLocation})`,
        activityData: s2.electricityKwh,
        activityUnit: "kWh",
        emissionFactor: s2.emissionFactor,
        efUnit: "tCO₂e/kWh",
        emissions: s2.emissions,
      });
    }
  }
  return items;
}

/** Group emission items by category, returning sorted entries */
function groupByCategory(items: EmissionItem[]): { category: string; items: EmissionItem[]; total: number }[] {
  const map = new Map<string, EmissionItem[]>();
  for (const item of items) {
    const key = item.category || "Uncategorised";
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(item);
  }
  return Array.from(map.entries())
    .map(([category, items]) => ({
      category,
      items,
      total: items.reduce((sum, i) => sum + i.emissions, 0),
    }))
    .sort((a, b) => b.total - a.total);
}

/** Scope 1 category icon mapping */
function getScope1CategoryIcon(cat: string) {
  switch (cat) {
    case "Stationary Combustion":
    case "Mobile Combustion":
      return <Flame className="h-3.5 w-3.5" />;
    case "Fugitive Emissions":
      return <Factory className="h-3.5 w-3.5" />;
    case "Process Emissions":
      return <ArrowDownUp className="h-3.5 w-3.5" />;
    default:
      return <Leaf className="h-3.5 w-3.5" />;
  }
}

/** Scope badge colour */
function getScopeBadgeClass(scope: number): string {
  switch (scope) {
    case 1:
      return "bg-emerald-500/10 text-emerald-700 border-emerald-200";
    case 2:
      return "bg-amber-500/10 text-amber-700 border-amber-200";
    case 3:
      return "bg-blue-500/10 text-blue-700 border-blue-200";
    default:
      return "";
  }
}

/** Percentage bar */
function PctBar({ pct, color = "bg-emerald-500" }: { pct: number; color?: string }) {
  return (
    <div className="w-full bg-muted/60 rounded-full h-2 overflow-hidden">
      <div
        className={`h-full rounded-full transition-all duration-500 ${color}`}
        style={{ width: `${Math.min(pct, 100)}%` }}
      />
    </div>
  );
}

// ── Gauge Component ─────────────────────────────────────────────────
function ScoreGauge({ score }: { score: number }) {
  const color = getScoreColor(score);
  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const halfCircumference = circumference / 2;
  const progress = (score / 100) * halfCircumference;

  return (
    <div className="flex flex-col items-center">
      <svg width="160" height="90" viewBox="0 0 160 90">
        {/* Background arc */}
        <path
          d="M 20 80 A 60 60 0 0 1 140 80"
          fill="none"
          stroke="currentColor"
          strokeWidth="12"
          strokeLinecap="round"
          className="text-muted/30"
        />
        {/* Progress arc */}
        <path
          d="M 20 80 A 60 60 0 0 1 140 80"
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={halfCircumference}
          strokeDashoffset={halfCircumference - progress}
          className="transition-all duration-700 ease-out"
        />
        {/* Score text */}
        <text
          x="80"
          y="72"
          textAnchor="middle"
          className="text-2xl font-bold"
          fill={color}
          fontSize="28"
          fontWeight="bold"
        >
          {Math.round(score)}%
        </text>
      </svg>
      <p className="text-sm font-medium mt-1" style={{ color }}>
        {getScoreLabel(score)}
      </p>
    </div>
  );
}

// ── Loading Skeleton ────────────────────────────────────────────────
function ReportsSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-7 w-64" />
          <Skeleton className="h-4 w-48" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}>
          <CardHeader>
            <Skeleton className="h-5 w-48" />
            <Skeleton className="h-4 w-32" />
          </CardHeader>
          <CardContent className="space-y-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ── Main Component ──────────────────────────────────────────────────
export default function ReportsView({ userId }: ReportsViewProps) {
  // Fetch dashboard summary
  const { data: summary, isLoading: summaryLoading } = useQuery<DashboardSummary>({
    queryKey: ["dashboard", userId],
    queryFn: async () => {
      const res = await fetch(`/api/dashboard?userId=${userId}`);
      if (!res.ok) throw new Error("Failed to fetch dashboard");
      return res.json();
    },
    refetchOnWindowFocus: false,
  });

  // Fetch GHG entries
  const { data: ghgEntries, isLoading: ghgLoading } = useQuery<GhgEntry[]>({
    queryKey: ["ghg", userId],
    queryFn: async () => {
      const res = await fetch(`/api/ghg?userId=${userId}`);
      if (!res.ok) throw new Error("Failed to fetch GHG data");
      const data = await res.json();
      return data.entries ?? data;
    },
    refetchOnWindowFocus: false,
  });

  // Fetch ESG responses
  const { data: esgResponses, isLoading: esgLoading } = useQuery<EsgResponse[]>({
    queryKey: ["esg", userId],
    queryFn: async () => {
      const res = await fetch(`/api/esg?userId=${userId}`);
      if (!res.ok) throw new Error("Failed to fetch ESG data");
      const data = await res.json();
      return data.responses ?? data;
    },
    refetchOnWindowFocus: false,
  });

  const isLoading = summaryLoading || ghgLoading || esgLoading;
  const hasData =
    (ghgEntries && ghgEntries.length > 0) ||
    (esgResponses && esgResponses.length > 0) ||
    (summary && (summary.totalEmissions !== null || summary.completedIndicators > 0));

  const latestGhg = ghgEntries && ghgEntries.length > 0 ? ghgEntries[0] : null;

  // Group ESG responses by section
  const governanceResponses = (esgResponses || []).filter((r) => r.section === "Governance");
  const environmentalResponses = (esgResponses || []).filter((r) => r.section === "Environmental");
  const socialResponses = (esgResponses || []).filter((r) => r.section === "Social");

  if (isLoading) return <ReportsSkeleton />;

  if (!hasData) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <FileText className="h-12 w-12 text-muted-foreground/40 mb-4" />
        <h3 className="text-lg font-semibold mb-1">No Report Data Available</h3>
        <p className="text-sm text-muted-foreground max-w-md">
          Complete your GHG Calculator and ESG Questionnaire to generate a comprehensive ESG report.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 print:space-y-4">
      {/* Print CSS via style tag */}
      <style>{`
        @media print {
          .no-print { display: none !important; }
          .print-break { page-break-before: always; }
          body { background: white !important; }
          main { padding: 0 !important; }
        }
      `}</style>

      {/* ── Report Header ─────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 no-print">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">ESG Compliance Report</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Generated on {todayDateString()}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.print()}
          >
            <Printer className="mr-2 h-4 w-4" />
            Print Report
          </Button>
        </div>
      </div>

      {/* Report Title Card */}
      <Card className="border-2">
        <CardContent className="py-8">
          <div className="text-center space-y-2">
            <h2 className="text-xl font-bold tracking-tight">
              {summary?.company?.companyName || "Your Company"}
            </h2>
            <p className="text-sm text-muted-foreground">
              {summary?.company?.industrySector && (
                <span className="inline-flex items-center gap-1">
                  <Building className="h-3.5 w-3.5" />
                  {summary.company.industrySector}
                </span>
              )}
            </p>
            <p className="text-sm text-muted-foreground">
              Reporting Period: {summary?.latestReportingPeriod || "Not specified"}
            </p>
            <Separator className="my-4" />
            <p className="text-xs text-muted-foreground">
              This report is generated by the SustainHub platform and is intended for internal use and stakeholder disclosure.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* ── Section 1: Company Information ─────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Building className="h-4 w-4" />
            Company Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          {summary?.company ? (
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium w-1/3 text-muted-foreground">Company Name</TableCell>
                  <TableCell>{summary.company.companyName}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-muted-foreground">Registration No.</TableCell>
                  <TableCell>{summary.company.registrationNumber || "N/A"}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-muted-foreground">Industry Sector</TableCell>
                  <TableCell>{summary.company.industrySector}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-muted-foreground">Company Size</TableCell>
                  <TableCell>{summary.company.companySize}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-muted-foreground">Annual Revenue</TableCell>
                  <TableCell>{summary.company.annualRevenue || "N/A"}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-muted-foreground">Number of Employees</TableCell>
                  <TableCell>{summary.company.numberOfEmployees?.toLocaleString() || "N/A"}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-muted-foreground">State</TableCell>
                  <TableCell>{summary.company.state || "N/A"}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              Company information not available. Please complete your onboarding.
            </p>
          )}
        </CardContent>
      </Card>

      {/* ── Section 2: GHG Emissions Summary ───────────────────── */}
      {(() => {
        const allItems = latestGhg ? normalizeEmissionItems(latestGhg) : [];
        const scope1Items = allItems.filter((i) => i.scope === 1);
        const scope2Items = allItems.filter((i) => i.scope === 2);
        const scope3Items = allItems.filter((i) => i.scope === 3);
        const scope1Total = latestGhg?.scope1Total ?? scope1Items.reduce((s, i) => s + i.emissions, 0);
        const scope2Total = latestGhg?.scope2Total ?? scope2Items.reduce((s, i) => s + i.emissions, 0);
        const scope3Total = latestGhg?.scope3Total ?? scope3Items.reduce((s, i) => s + i.emissions, 0);
        const grandTotal = scope1Total + scope2Total + scope3Total;
        const scope1Pct = grandTotal > 0 ? (scope1Total / grandTotal) * 100 : 0;
        const scope2Pct = grandTotal > 0 ? (scope2Total / grandTotal) * 100 : 0;
        const scope3Pct = grandTotal > 0 ? (scope3Total / grandTotal) * 100 : 0;

        const scope1Categories = groupByCategory(scope1Items);
        const scope3Categories = groupByCategory(scope3Items);
        const scope3Top5 = scope3Categories.slice(0, 5);

        return (
          <Card className="print-break">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Leaf className="h-4 w-4" />
                GHG Emissions Summary
              </CardTitle>
              <CardDescription>
                Total greenhouse gas emissions measured in tonnes of CO₂ equivalent (tCO₂e)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {latestGhg ? (
                <>
                  {/* Total Emissions Highlight */}
                  <div className="rounded-lg border bg-emerald-500/5 p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Total Emissions (All Scopes)</p>
                        <p className="text-3xl font-bold mt-1 text-emerald-700">
                          {formatEmissions(grandTotal)}{" "}
                          <span className="text-base font-normal text-muted-foreground">tCO₂e</span>
                        </p>
                      </div>
                      {latestGhg.reportingPeriod && (
                        <Badge variant="outline" className="self-start">
                          {latestGhg.reportingPeriod}
                        </Badge>
                      )}
                    </div>

                    {/* Scope percentage bars */}
                    <div className="space-y-2.5">
                      {/* Scope 1 */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={getScopeBadgeClass(1)}>Scope 1</Badge>
                            <span className="font-medium">Direct Emissions</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-emerald-700">{formatEmissions(scope1Total)} tCO₂e</span>
                            <span className="text-xs text-muted-foreground w-10 text-right">{scope1Pct.toFixed(1)}%</span>
                          </div>
                        </div>
                        <PctBar pct={scope1Pct} color="bg-emerald-500" />
                      </div>

                      {/* Scope 2 */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={getScopeBadgeClass(2)}>Scope 2</Badge>
                            <span className="font-medium">Indirect Emissions</span>
                            {latestGhg.scope2Method && (
                              <span className="text-xs text-muted-foreground">({latestGhg.scope2Method})</span>
                            )}
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-amber-700">{formatEmissions(scope2Total)} tCO₂e</span>
                            <span className="text-xs text-muted-foreground w-10 text-right">{scope2Pct.toFixed(1)}%</span>
                          </div>
                        </div>
                        <PctBar pct={scope2Pct} color="bg-amber-500" />
                      </div>

                      {/* Scope 3 */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={getScopeBadgeClass(3)}>Scope 3</Badge>
                            <span className="font-medium">Value Chain Emissions</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-blue-700">{formatEmissions(scope3Total)} tCO₂e</span>
                            <span className="text-xs text-muted-foreground w-10 text-right">{scope3Pct.toFixed(1)}%</span>
                          </div>
                        </div>
                        <PctBar pct={scope3Pct} color="bg-blue-500" />
                      </div>
                    </div>
                  </div>

                  {/* Scope 1 Category Breakdown */}
                  {scope1Categories.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold flex items-center gap-2">
                        <Flame className="h-4 w-4 text-emerald-600" />
                        Scope 1: Direct Emissions by Category
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {scope1Categories.map((cat) => {
                          const catPct = scope1Total > 0 ? (cat.total / scope1Total) * 100 : 0;
                          return (
                            <div key={cat.category} className="rounded-lg border p-3 space-y-1.5">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5 text-sm font-medium">
                                  {getScope1CategoryIcon(cat.category)}
                                  {cat.category}
                                </div>
                                <span className="text-xs text-muted-foreground">{catPct.toFixed(1)}%</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <PctBar pct={catPct} color="bg-emerald-500" />
                                <span className="text-sm font-mono text-emerald-700 ml-3 whitespace-nowrap">
                                  {formatEmissions(cat.total)}
                                </span>
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {cat.items.length} source{cat.items.length !== 1 ? "s" : ""}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Scope 2 Method */}
                  {scope2Total > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold flex items-center gap-2">
                        <Zap className="h-4 w-4 text-amber-600" />
                        Scope 2: Indirect Emissions (Electricity)
                      </h4>
                      <div className="rounded-lg border p-3 space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Calculation Method</span>
                          <Badge variant="outline" className={getScopeBadgeClass(2)}>
                            {latestGhg.scope2Method || "Location-based"}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Total Scope 2 Emissions</span>
                          <span className="font-mono font-medium text-amber-700">{formatEmissions(scope2Total)} tCO₂e</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Electricity Sources</span>
                          <span className="font-medium">{scope2Items.length} entry{scope2Items.length !== 1 ? "s" : ""}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Scope 3 Top Categories */}
                  {scope3Total > 0 && scope3Top5.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold flex items-center gap-2">
                        <Factory className="h-4 w-4 text-blue-600" />
                        Scope 3: Top Categories by Emissions
                      </h4>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Category</TableHead>
                            <TableHead className="text-right">Emissions (tCO₂e)</TableHead>
                            <TableHead className="text-right w-20">% of Total</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {scope3Top5.map((cat) => {
                            const pct = grandTotal > 0 ? (cat.total / grandTotal) * 100 : 0;
                            return (
                              <TableRow key={cat.category}>
                                <TableCell className="font-medium text-sm">
                                  <div className="flex items-center gap-2">
                                    <Badge variant="outline" className={getScopeBadgeClass(3)}>S3</Badge>
                                    {cat.category}
                                    {cat.items[0]?.subCategory && (
                                      <span className="text-xs text-muted-foreground">({cat.items[0].subCategory})</span>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell className="text-right font-mono text-sm">
                                  {formatEmissions(cat.total)}
                                </TableCell>
                                <TableCell className="text-right text-sm text-muted-foreground">
                                  {pct.toFixed(1)}%
                                </TableCell>
                              </TableRow>
                            );
                          })}
                          {scope3Categories.length > 5 && (
                            <TableRow className="text-muted-foreground">
                              <TableCell className="text-sm italic">
                                + {scope3Categories.length - 5} more categor{scope3Categories.length - 5 !== 1 ? "ies" : "y"}
                              </TableCell>
                              <TableCell />
                              <TableCell />
                            </TableRow>
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Leaf className="h-8 w-8 text-muted-foreground/40 mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No GHG emissions data available. Use the GHG Calculator to measure your carbon footprint.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })()}

      {/* ── Section 2b: Emissions by Category ────────────────────── */}
      {(() => {
        const allItems = latestGhg ? normalizeEmissionItems(latestGhg) : [];
        if (allItems.length === 0) return null;
        const scope1Items = allItems.filter((i) => i.scope === 1);
        const scope2Items = allItems.filter((i) => i.scope === 2);
        const scope3Items = allItems.filter((i) => i.scope === 3);
        const scope1Cats = groupByCategory(scope1Items);
        const scope2Cats = groupByCategory(scope2Items);
        const scope3Cats = groupByCategory(scope3Items);
        const grandTotal = allItems.reduce((s, i) => s + i.emissions, 0);

        const scope3Upstream = scope3Cats.filter((c) => {
          const num = parseInt(c.category.match(/\d+/)?.[0] ?? "0");
          return num >= 1 && num <= 8;
        });
        const scope3Downstream = scope3Cats.filter((c) => {
          const num = parseInt(c.category.match(/\d+/)?.[0] ?? "0");
          return num >= 9 && num <= 15;
        });

        return (
          <Card className="print-break">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Leaf className="h-4 w-4" />
                Emissions by Category
              </CardTitle>
              <CardDescription>
                Detailed breakdown of emission sources grouped by GHG Protocol category
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* ── Scope 1 Categories ── */}
              {scope1Cats.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className={getScopeBadgeClass(1)}>Scope 1</Badge>
                    <h4 className="text-sm font-semibold">Direct Emissions</h4>
                  </div>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-emerald-500/5">
                          <TableHead>Category</TableHead>
                          <TableHead className="text-right">Sources</TableHead>
                          <TableHead className="text-right">Activity</TableHead>
                          <TableHead className="text-right">Emissions (tCO₂e)</TableHead>
                          <TableHead className="text-right w-20">% of Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {scope1Cats.map((cat) => {
                          const pct = grandTotal > 0 ? (cat.total / grandTotal) * 100 : 0;
                          return (
                            <TableRow key={cat.category}>
                              <TableCell className="font-medium text-sm">
                                <div className="flex items-center gap-1.5">
                                  {getScope1CategoryIcon(cat.category)}
                                  {cat.category}
                                </div>
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">
                                {cat.items.length}
                              </TableCell>
                              <TableCell className="text-right text-xs text-muted-foreground">
                                {cat.items.map((i) => i.sourceName || i.subCategory || "N/A").join(", ")}
                              </TableCell>
                              <TableCell className="text-right font-mono text-sm text-emerald-700">
                                {formatEmissions(cat.total)}
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">
                                {pct.toFixed(1)}%
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* ── Scope 2 ── */}
              {scope2Cats.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className={getScopeBadgeClass(2)}>Scope 2</Badge>
                    <h4 className="text-sm font-semibold">Indirect Emissions: Electricity</h4>
                  </div>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-amber-500/5">
                          <TableHead>Source</TableHead>
                          <TableHead className="text-right">Activity (kWh)</TableHead>
                          <TableHead className="text-right">Emission Factor</TableHead>
                          <TableHead className="text-right">Emissions (tCO₂e)</TableHead>
                          <TableHead className="text-right w-20">% of Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {scope2Items.map((item, idx) => {
                          const pct = grandTotal > 0 ? (item.emissions / grandTotal) * 100 : 0;
                          return (
                            <TableRow key={idx}>
                              <TableCell className="font-medium text-sm">
                                {item.sourceName || item.subCategory || "Electricity"}
                              </TableCell>
                              <TableCell className="text-right text-sm font-mono">
                                {item.activityData.toLocaleString()} {item.activityUnit}
                              </TableCell>
                              <TableCell className="text-right text-sm font-mono text-muted-foreground">
                                {item.emissionFactor.toFixed(4)} {item.efUnit}
                              </TableCell>
                              <TableCell className="text-right font-mono text-sm text-amber-700">
                                {formatEmissions(item.emissions)}
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">
                                {pct.toFixed(1)}%
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* ── Scope 3 Upstream ── */}
              {scope3Upstream.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className={getScopeBadgeClass(3)}>Scope 3</Badge>
                    <h4 className="text-sm font-semibold">Upstream Emissions (Categories 1–8)</h4>
                  </div>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-blue-500/5">
                          <TableHead>Category</TableHead>
                          <TableHead>Sub-category</TableHead>
                          <TableHead className="text-right">Sources</TableHead>
                          <TableHead className="text-right">Emissions (tCO₂e)</TableHead>
                          <TableHead className="text-right w-20">% of Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {scope3Upstream.map((cat) => {
                          const pct = grandTotal > 0 ? (cat.total / grandTotal) * 100 : 0;
                          return (
                            <TableRow key={cat.category}>
                              <TableCell className="font-medium text-sm">{cat.category}</TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {cat.items.map((i) => i.subCategory || i.sourceName || "N/A").filter((v, i, a) => a.indexOf(v) === i).join(", ")}
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">{cat.items.length}</TableCell>
                              <TableCell className="text-right font-mono text-sm text-blue-700">{formatEmissions(cat.total)}</TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">{pct.toFixed(1)}%</TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* ── Scope 3 Downstream ── */}
              {scope3Downstream.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className={getScopeBadgeClass(3)}>Scope 3</Badge>
                    <h4 className="text-sm font-semibold">Downstream Emissions (Categories 9–15)</h4>
                  </div>
                  <div className="rounded-md border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-blue-500/5">
                          <TableHead>Category</TableHead>
                          <TableHead>Sub-category</TableHead>
                          <TableHead className="text-right">Sources</TableHead>
                          <TableHead className="text-right">Emissions (tCO₂e)</TableHead>
                          <TableHead className="text-right w-20">% of Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {scope3Downstream.map((cat) => {
                          const pct = grandTotal > 0 ? (cat.total / grandTotal) * 100 : 0;
                          return (
                            <TableRow key={cat.category}>
                              <TableCell className="font-medium text-sm">{cat.category}</TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {cat.items.map((i) => i.subCategory || i.sourceName || "N/A").filter((v, i, a) => a.indexOf(v) === i).join(", ")}
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">{cat.items.length}</TableCell>
                              <TableCell className="text-right font-mono text-sm text-blue-700">{formatEmissions(cat.total)}</TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">{pct.toFixed(1)}%</TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })()}

      {/* ── Section 3: SEDG Disclosure Table ───────────────────── */}
      <Card className="print-break">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="h-4 w-4" />
            SEDG Disclosure Table
          </CardTitle>
          <CardDescription>
            Sustainable Energy Development Governance (35 Indicators)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {esgResponses && esgResponses.length > 0 ? (
            <div className="max-h-[600px] overflow-y-auto rounded-md border print:max-h-none">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Code</TableHead>
                    <TableHead className="w-28">Section</TableHead>
                    <TableHead>Indicator</TableHead>
                    <TableHead className="w-48">Response</TableHead>
                    <TableHead className="w-28 text-center">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {/* Governance section header */}
                  {governanceResponses.length > 0 && (
                    <>
                      <TableRow className="bg-teal-500/10 hover:bg-teal-500/10">
                        <TableCell colSpan={5} className="font-bold">
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-teal-600" />
                            Governance ({governanceResponses.length} indicators)
                          </div>
                        </TableCell>
                      </TableRow>
                      {governanceResponses.map((r) => (
                        <TableRow key={r.id} className={getSectionRowBg(r.section)}>
                          <TableCell className="font-mono text-xs">{r.indicatorCode}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getSectionBadgeColor(r.section)}>
                              {r.section}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{r.indicatorLabel}</TableCell>
                          <TableCell className="text-sm max-w-48 truncate">
                            {r.responseValue || (
                              <span className="text-muted-foreground italic">Not provided</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {r.responseValue ? (
                              <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-200">Complete</Badge>
                            ) : (
                              <Badge variant="outline" className="text-muted-foreground">Incomplete</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </>
                  )}

                  {/* Environmental section header */}
                  {environmentalResponses.length > 0 && (
                    <>
                      <TableRow className="bg-green-500/10 hover:bg-green-500/10">
                        <TableCell colSpan={5} className="font-bold">
                          <div className="flex items-center gap-2">
                            <Leaf className="h-4 w-4 text-green-600" />
                            Environmental ({environmentalResponses.length} indicators)
                          </div>
                        </TableCell>
                      </TableRow>
                      {environmentalResponses.map((r) => (
                        <TableRow key={r.id} className={getSectionRowBg(r.section)}>
                          <TableCell className="font-mono text-xs">{r.indicatorCode}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getSectionBadgeColor(r.section)}>
                              {r.section}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{r.indicatorLabel}</TableCell>
                          <TableCell className="text-sm max-w-48 truncate">
                            {r.responseValue || (
                              <span className="text-muted-foreground italic">Not provided</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {r.responseValue ? (
                              <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-200">Complete</Badge>
                            ) : (
                              <Badge variant="outline" className="text-muted-foreground">Incomplete</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </>
                  )}

                  {/* Social section header */}
                  {socialResponses.length > 0 && (
                    <>
                      <TableRow className="bg-amber-500/10 hover:bg-amber-500/10">
                        <TableCell colSpan={5} className="font-bold">
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-amber-600" />
                            Social ({socialResponses.length} indicators)
                          </div>
                        </TableCell>
                      </TableRow>
                      {socialResponses.map((r) => (
                        <TableRow key={r.id} className={getSectionRowBg(r.section)}>
                          <TableCell className="font-mono text-xs">{r.indicatorCode}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getSectionBadgeColor(r.section)}>
                              {r.section}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{r.indicatorLabel}</TableCell>
                          <TableCell className="text-sm max-w-48 truncate">
                            {r.responseValue || (
                              <span className="text-muted-foreground italic">Not provided</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {r.responseValue ? (
                              <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-200">Complete</Badge>
                            ) : (
                              <Badge variant="outline" className="text-muted-foreground">Incomplete</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </>
                  )}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Shield className="h-8 w-8 text-muted-foreground/40 mb-2" />
              <p className="text-sm text-muted-foreground">
                No SEDG questionnaire responses available. Complete the ESG Questionnaire to populate this table.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Section 4: ESG Readiness Summary ───────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">ESG Readiness Summary</CardTitle>
          <CardDescription>Overall assessment based on your data completeness and quality</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {summary ? (
            <>
              {/* Overall Score Gauge */}
              <div className="flex justify-center py-4">
                <ScoreGauge score={summary.esgReadinessScore} />
              </div>

              {/* Section-by-section scores */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="rounded-lg border p-4 text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Shield className="h-4 w-4 text-teal-600" />
                    <span className="text-sm font-medium">Governance</span>
                  </div>
                  <p className="text-2xl font-bold" style={{ color: getScoreColor(summary.sectionProgress.governance) }}>
                    {Math.round(summary.sectionProgress.governance)}%
                  </p>
                </div>
                <div className="rounded-lg border p-4 text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Leaf className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium">Environmental</span>
                  </div>
                  <p className="text-2xl font-bold" style={{ color: getScoreColor(summary.sectionProgress.environmental) }}>
                    {Math.round(summary.sectionProgress.environmental)}%
                  </p>
                </div>
                <div className="rounded-lg border p-4 text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Users className="h-4 w-4 text-amber-600" />
                    <span className="text-sm font-medium">Social</span>
                  </div>
                  <p className="text-2xl font-bold" style={{ color: getScoreColor(summary.sectionProgress.social) }}>
                    {Math.round(summary.sectionProgress.social)}%
                  </p>
                </div>
              </div>

              {/* Stats summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-lg bg-muted/50 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Total Score</p>
                  <p className="text-lg font-bold">{summary.esgReadinessScore}%</p>
                </div>
                <div className="rounded-lg bg-muted/50 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Indicators</p>
                  <p className="text-lg font-bold">
                    {summary.completedIndicators}/{summary.totalIndicators}
                  </p>
                </div>
                <div className="rounded-lg bg-muted/50 p-3 text-center">
                  <p className="text-xs text-muted-foreground">GHG Emissions</p>
                  <p className="text-lg font-bold">
                    {summary.totalEmissions !== null ? `${formatEmissions(summary.totalEmissions)}` : "N/A"}
                  </p>
                </div>
                <div className="rounded-lg bg-muted/50 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Status</p>
                  <p className="text-lg font-bold" style={{ color: getScoreColor(summary.esgReadinessScore) }}>
                    {getScoreLabel(summary.esgReadinessScore)}
                  </p>
                </div>
              </div>

              <Separator />

              {/* Recommendation */}
              <div>
                <h4 className="text-sm font-semibold mb-2">Recommendation</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {getScoreRecommendation(summary.esgReadinessScore)}
                </p>
              </div>
            </>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              Unable to calculate readiness score. Please ensure you have completed the onboarding process.
            </p>
          )}
        </CardContent>
      </Card>

      {/* ── Section 5: Declaration ─────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Declaration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border bg-muted/30 p-6 space-y-3 text-sm text-muted-foreground leading-relaxed">
            <p>
              I hereby declare that the information provided in this report is true and accurate to the best
              of my knowledge. The data presented has been collected and reported in accordance with the
              Bursa Malaysia Sustainability Reporting Guide and the Requirements on Sustainability Statement
              for Main Market Listed Issuers.
            </p>
            <p>
              This ESG compliance report has been prepared using the SustainHub platform and reflects
              the organisation&apos;s environmental, social, and governance performance for the reporting
              period specified herein.
            </p>
            <Separator />
            <div className="grid grid-cols-2 gap-8 pt-2">
              <div>
                <p className="font-medium text-foreground">Authorised Signatory</p>
                <div className="mt-8 border-b border-dashed" />
                <p className="mt-1 text-xs">Name &amp; Signature</p>
              </div>
              <div>
                <p className="font-medium text-foreground">Date</p>
                <div className="mt-8 border-b border-dashed" />
                <p className="mt-1 text-xs">{todayDateString()}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}