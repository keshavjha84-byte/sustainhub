/**
 * Emission Factors Database - SustainHub Malaysia
 *
 * GHG Protocol-compliant emission factors for Malaysian SMEs.
 * Sources:
 *   - Malaysia PETRONAS / Energy Commission (TNB grid factors 2023)
 *   - IPCC 2006 Guidelines / 2019 Refinement
 *   - IPCC AR5 GWP values (CO₂=1, CH₄=28, N₂O=265)
 *   - Malaysia-specific factors where available; IPCC defaults as fallback
 *
 * All values are typed constants, no runtime data fetching.
 * Importable by both frontend and backend (no Node.js-specific imports).
 */

// ---------------------------------------------------------------------------
// Shared Types
// ---------------------------------------------------------------------------

/** Net Calorific Value / energy density for a fuel */
export interface NcvData {
  /** Net calorific value in MJ per unit of fuel */
  mjPerUnit: number;
  /** Unit description, e.g. "m³", "L", "kg" */
  unit: string;
}

/** Individual gas emission factor (kg of gas per unit of fuel/activity) */
export interface GasEmissionFactor {
  /** kg CO₂ per unit */
  co2: number;
  /** kg CH₄ per unit */
  ch4: number;
  /** kg N₂O per unit */
  n2o: number;
}

/** Combined emission factor with CO₂, CH₄, N₂O breakdown and NCV */
export interface FuelEmissionFactor extends GasEmissionFactor {
  /** Net calorific value */
  ncv: NcvData;
  /** Unit of fuel quantity (e.g. "m³", "L", "kg") */
  unit: string;
  /** Human-readable label */
  label: string;
  /** Whether CO₂ is biogenic (reported separately, not counted in totals) */
  biogenic?: boolean;
}

/** Mobile combustion emission factor (kg CO₂e per km) */
export interface MobileCombustionFactor {
  /** kg CO₂ per km */
  co2PerKm: number;
  /** kg CH₄ per km */
  ch4PerKm: number;
  /** kg N₂O per km */
  n2oPerKm: number;
  /** Fuel type used */
  fuel: 'petrol' | 'diesel';
  /** Human-readable label */
  label: string;
}

/** Refrigerant data for fugitive emission calculations */
export interface RefrigerantFactor {
  /** Refrigerant identifier */
  code: string;
  /** Human-readable name */
  name: string;
  /** GWP from IPCC AR5 */
  gwp: number;
  /** Default annual leakage rate as a fraction (0–1) */
  defaultLeakageRate: number;
}

/** Process emission factor (tCO₂ per tonne of product) */
export interface ProcessEmissionFactor {
  /** Process / product name */
  process: string;
  /** Emission factor in tCO₂ per tonne of product */
  factor: number; // tCO₂/tonne
  /** IPCC source reference */
  source: string;
}

/** Grid electricity emission factor */
export interface GridEmissionFactor {
  /** Grid region name */
  region: string;
  /** Label for display */
  label: string;
  /** Location-based emission factor (kg CO₂e / kWh) */
  locationBased: number;
  /** Market-based emission factor (kg CO₂e / kWh), if applicable */
  marketBased?: number;
}

/** Market-based instrument for Scope 2 */
export interface MarketBasedInstrument {
  /** Instrument name */
  name: string;
  /** kg CO₂e / kWh */
  factor: number;
  /** Description */
  description: string;
}

/** Transmission & Distribution loss factor */
export interface TDLossFactor {
  /** Grid region */
  region: string;
  /** Loss fraction (0–1) */
  lossFactor: number;
}

/** Transport emission intensity factor */
export interface TransportFactor {
  /** Mode of transport */
  mode: string;
  /** kg CO₂e per tonne-km (freight) */
  kgCo2ePerTonneKm?: number;
  /** kg CO₂e per passenger-km (passenger), if applicable */
  kgCo2ePerPassengerKm?: number;
}

/** Waste treatment emission factor */
export interface WasteFactor {
  /** Treatment method */
  method: string;
  /** tCO₂e per tonne of waste */
  tCo2ePerTonne: number;
}

/** Scope 3 category definition */
export interface Scope3Category {
  /** Category number (1–15) */
  category: number;
  /** GHG Protocol category name */
  name: string;
  /** Default calculation method */
  defaultMethod: 'spend-based' | 'activity-based' | 'hybrid';
  /** Brief description */
  description: string;
}

/** Industry-average emission intensity for spend-based calculations */
export interface IndustryEmissionIntensity {
  /** Industry sector name */
  industry: string;
  /** Emission intensity in tCO₂e per RM million of spend */
  tCo2ePerRmMillion: number;
}

// ---------------------------------------------------------------------------
// Global Warming Potentials (IPCC AR5)
// ---------------------------------------------------------------------------

export const GWP_AR5 = {
  co2: 1,
  ch4: 28,
  n2o: 265,
  /** Frequently-used HFC GWPs */
  hfcs: {
    'HFC-134a': 1430,
    'HFC-32': 675,
    'HFC-125': 3500,
    'HFC-143a': 4470,
    'HFC-227ea': 3220,
    'HFC-245fa': 1030,
  },
} as const;

// ---------------------------------------------------------------------------
// Scope 1, 1A: Stationary Combustion
// ---------------------------------------------------------------------------

export const STATIONARY_COMBUSTION_FACTORS: Record<string, FuelEmissionFactor> = {
  natural_gas: {
    label: 'Natural Gas',
    co2: 2.02,   // kg CO₂/m³ (PETRONAS Malaysia)
    ch4: 0.006,  // kg CH₄/m³
    n2o: 0.0001, // kg N₂O/m³
    ncv: { mjPerUnit: 38.93, unit: 'm³' },
    unit: 'm³',
  },
  diesel: {
    label: 'Diesel',
    co2: 2.68,   // kg CO₂/L (Malaysia)
    ch4: 0.0003, // kg CH₄/L
    n2o: 0.0001, // kg N₂O/L
    ncv: { mjPerUnit: 38.6, unit: 'L' },
    unit: 'L',
  },
  petrol: {
    label: 'Petrol / Gasoline',
    co2: 2.31,   // kg CO₂/L (Malaysia)
    ch4: 0.0003, // kg CH₄/L
    n2o: 0.0001, // kg N₂O/L
    ncv: { mjPerUnit: 34.2, unit: 'L' },
    unit: 'L',
  },
  lpg: {
    label: 'LPG',
    co2: 2.98,   // kg CO₂/kg (Malaysia)
    ch4: 0.001,  // kg CH₄/kg
    n2o: 0.0001, // kg N₂O/kg
    ncv: { mjPerUnit: 46.0, unit: 'kg' },
    unit: 'kg',
  },
  fuel_oil_heavy: {
    label: 'Fuel Oil (Heavy)',
    co2: 3.15,   // kg CO₂/L
    ch4: 0.0003, // kg CH₄/L
    n2o: 0.0002, // kg N₂O/L
    ncv: { mjPerUnit: 40.5, unit: 'L' },
    unit: 'L',
  },
  coal_bituminous: {
    label: 'Coal (Bituminous)',
    co2: 2.53,   // kg CO₂/kg (IPCC 2006 default)
    ch4: 0.001,  // kg CH₄/kg
    n2o: 0.0003, // kg N₂O/kg
    ncv: { mjPerUnit: 24.0, unit: 'kg' },
    unit: 'kg',
  },
  biomass_wood_pellets: {
    label: 'Biomass (Wood Pellets)',
    co2: 0,      // Biogenic, reported separately, not in totals
    ch4: 0,
    n2o: 0,
    ncv: { mjPerUnit: 17.0, unit: 'kg' },
    unit: 'kg',
    biogenic: true,
  },
  kerosene_jet_a1: {
    label: 'Kerosene / Jet A-1',
    co2: 2.51,   // kg CO₂/L
    ch4: 0.0003, // kg CH₄/L
    n2o: 0.0001, // kg N₂O/L
    ncv: { mjPerUnit: 34.9, unit: 'L' },
    unit: 'L',
  },
} as const;

/** Fuel type keys for dropdowns */
export const STATIONARY_FUEL_KEYS = Object.keys(
  STATIONARY_COMBUSTION_FACTORS
) as (keyof typeof STATIONARY_COMBUSTION_FACTORS)[];

// ---------------------------------------------------------------------------
// Scope 1, 1B: Mobile Combustion
// ---------------------------------------------------------------------------

export const MOBILE_COMBUSTION_FACTORS: Record<string, MobileCombustionFactor> = {
  passenger_car_petrol: {
    label: 'Passenger Car (Petrol)',
    co2PerKm: 0.21,
    ch4PerKm: 0.00005,
    n2oPerKm: 0.00001,
    fuel: 'petrol',
  },
  passenger_car_diesel: {
    label: 'Passenger Car (Diesel)',
    co2PerKm: 0.17,
    ch4PerKm: 0.00003,
    n2oPerKm: 0.00003,
    fuel: 'diesel',
  },
  motorcycle_petrol: {
    label: 'Motorcycle (Petrol)',
    co2PerKm: 0.09,
    ch4PerKm: 0.0001,
    n2oPerKm: 0.00001,
    fuel: 'petrol',
  },
  van_light_truck_diesel: {
    label: 'Van / Light Truck (Diesel)',
    co2PerKm: 0.29,
    ch4PerKm: 0.00003,
    n2oPerKm: 0.00003,
    fuel: 'diesel',
  },
  heavy_truck_diesel: {
    label: 'Heavy Truck (Diesel)',
    co2PerKm: 0.92,
    ch4PerKm: 0.00003,
    n2oPerKm: 0.00003,
    fuel: 'diesel',
  },
  bus_diesel: {
    label: 'Bus (Diesel)',
    co2PerKm: 1.03,
    ch4PerKm: 0.00003,
    n2oPerKm: 0.00003,
    fuel: 'diesel',
  },
} as const;

/** Vehicle type keys for dropdowns */
export const VEHICLE_TYPE_KEYS = Object.keys(
  MOBILE_COMBUSTION_FACTORS
) as (keyof typeof MOBILE_COMBUSTION_FACTORS)[];

// ---------------------------------------------------------------------------
// Scope 1, 1C: Fugitive Emissions (Refrigerant Leaks)
// ---------------------------------------------------------------------------

export const REFRIGERANT_FACTORS: Record<string, RefrigerantFactor> = {
  R_134a: {
    code: 'R-134a',
    name: 'R-134a (HFC-134a)',
    gwp: 1430,
    defaultLeakageRate: 0.10, // 10%
  },
  R_410A: {
    code: 'R-410A',
    name: 'R-410A (HFC-32/125 Blend)',
    gwp: 2088,
    defaultLeakageRate: 0.10,
  },
  R_22: {
    code: 'R-22',
    name: 'R-22 (HCFC-22)',
    gwp: 1810,
    defaultLeakageRate: 0.10,
  },
  R_32: {
    code: 'R-32',
    name: 'R-32 (HFC-32)',
    gwp: 675,
    defaultLeakageRate: 0.10,
  },
  R_407C: {
    code: 'R-407C',
    name: 'R-407C (HFC-32/125/143a Blend)',
    gwp: 1774,
    defaultLeakageRate: 0.10,
  },
  R_290: {
    code: 'R-290',
    name: 'R-290 Propane',
    gwp: 3,
    defaultLeakageRate: 0.10,
  },
} as const;

/** Refrigerant keys for dropdowns */
export const REFRIGERANT_KEYS = Object.keys(
  REFRIGERANT_FACTORS
) as (keyof typeof REFRIGERANT_FACTORS)[];

// ---------------------------------------------------------------------------
// Scope 1, 1D: Process Emissions
// ---------------------------------------------------------------------------

export const PROCESS_EMISSION_FACTORS: Record<string, ProcessEmissionFactor> = {
  cement: {
    process: 'Cement Production',
    factor: 0.625, // tCO₂/tonne clinker
    source: 'IPCC 2006, Tier 2 default',
  },
  lime: {
    process: 'Lime Production',
    factor: 0.75, // tCO₂/tonne lime
    source: 'IPCC 2006, Tier 2 default',
  },
  aluminium: {
    process: 'Aluminium Production',
    factor: 1.6, // tCO₂/tonne aluminium
    source: 'IPCC 2006, Tier 2 default',
  },
  steel_eaf: {
    process: 'Steel (Electric Arc Furnace)',
    factor: 0.4, // tCO₂/tonne steel
    source: 'IPCC 2006, Tier 2 default',
  },
  glass: {
    process: 'Glass Production',
    factor: 0.2, // tCO₂/tonne glass
    source: 'IPCC 2006, Tier 2 default',
  },
} as const;

/** Process type keys for dropdowns */
export const PROCESS_TYPE_KEYS = Object.keys(
  PROCESS_EMISSION_FACTORS
) as (keyof typeof PROCESS_EMISSION_FACTORS)[];

// ---------------------------------------------------------------------------
// Scope 2, Location-Based (Grid Average)
// ---------------------------------------------------------------------------

export const SCOPE2_LOCATION_FACTORS: Record<string, GridEmissionFactor> = {
  peninsular: {
    region: 'Peninsular',
    label: 'Peninsular Malaysia Grid (TNB)',
    locationBased: 0.6332, // kg CO₂e/kWh (Energy Commission 2023)
  },
  sabah: {
    region: 'Sabah',
    label: 'Sabah Grid (SESB)',
    locationBased: 0.4138, // kg CO₂e/kWh
  },
  sarawak: {
    region: 'Sarawak',
    label: 'Sarawak Grid (SEB)',
    locationBased: 0.2450, // kg CO₂e/kWh
  },
  labuan: {
    region: 'Labuan',
    label: 'Labuan (Peninsular Grid)',
    locationBased: 0.6332, // uses Peninsular grid
  },
} as const;

/** Grid region keys for dropdowns */
export const GRID_REGION_KEYS = Object.keys(
  SCOPE2_LOCATION_FACTORS
) as (keyof typeof SCOPE2_LOCATION_FACTORS)[];

// ---------------------------------------------------------------------------
// Scope 2, Market-Based Instruments
// ---------------------------------------------------------------------------

export const SCOPE2_MARKET_INSTRUMENTS: Record<string, MarketBasedInstrument> = {
  tnb_rec: {
    name: 'TNB Renewable Energy Certificate',
    factor: 0.0, // kg CO₂e/kWh
    description: 'Renewable energy certificate from TNB',
  },
  malaysia_residual_mix: {
    name: 'Malaysia Average Residual Mix Factor',
    factor: 0.5530, // kg CO₂e/kWh
    description: 'Residual mix factor for Malaysia when supplier-specific data unavailable',
  },
  biogas_ppa: {
    name: 'Biogas PPA',
    factor: 0.0, // kg CO₂e/kWh (attributed to biogenic)
    description: 'Power Purchase Agreement for biogas-generated electricity',
  },
  solar_ppa: {
    name: 'Solar PPA',
    factor: 0.0, // kg CO₂e/kWh
    description: 'Power Purchase Agreement for solar-generated electricity',
  },
} as const;

/** Market-based instrument keys */
export const MARKET_INSTRUMENT_KEYS = Object.keys(
  SCOPE2_MARKET_INSTRUMENTS
) as (keyof typeof SCOPE2_MARKET_INSTRUMENTS)[];

// ---------------------------------------------------------------------------
// Scope 3, Category Definitions
// ---------------------------------------------------------------------------

export const SCOPE3_CATEGORIES: Scope3Category[] = [
  {
    category: 1,
    name: 'Purchased Goods & Services',
    defaultMethod: 'spend-based',
    description:
      'Extraction, production, and transportation of goods and services purchased or acquired by the reporting company, not including capital goods or fuel/energy already accounted in Scope 1/2.',
  },
  {
    category: 2,
    name: 'Capital Goods',
    defaultMethod: 'spend-based',
    description:
      'Extraction, production, and transportation of capital goods (e.g. machinery, vehicles, buildings) used by the reporting company, depreciated over their useful life.',
  },
  {
    category: 3,
    name: 'Fuel & Energy-Related Activities',
    defaultMethod: 'activity-based',
    description:
      'Upstream emissions from fuel/energy production and T&D losses not included in Scope 1 or 2. Includes well-to-tank emissions and transmission & distribution losses.',
  },
  {
    category: 4,
    name: 'Upstream Transportation & Distribution',
    defaultMethod: 'activity-based',
    description:
      'Transportation and distribution of purchased goods, materials, and fuels in vehicles and facilities not owned or controlled by the reporting company.',
  },
  {
    category: 5,
    name: 'Waste Generated in Operations',
    defaultMethod: 'activity-based',
    description:
      'Third-party treatment and disposal of waste generated in the reporting company\'s operations (landfill, recycling, incineration).',
  },
  {
    category: 6,
    name: 'Business Travel',
    defaultMethod: 'activity-based',
    description:
      'Transportation of employees for business-related activities in vehicles not owned by the company (air, rail, taxi, rental car).',
  },
  {
    category: 7,
    name: 'Employee Commuting',
    defaultMethod: 'activity-based',
    description:
      'Transportation of employees between their homes and workplaces (car, motorcycle, bus, rail, walking, cycling).',
  },
  {
    category: 8,
    name: 'Upstream Leased Assets',
    defaultMethod: 'activity-based',
    description:
      'Scope 1 and Scope 2 emissions from the operation of assets leased by the reporting company (lessee) where lessor retains operational control.',
  },
  {
    category: 9,
    name: 'Downstream Transportation & Distribution',
    defaultMethod: 'activity-based',
    description:
      'Transportation and distribution of sold products in vehicles and facilities not owned or controlled by the reporting company.',
  },
  {
    category: 10,
    name: 'Processing of Sold Products',
    defaultMethod: 'activity-based',
    description:
      'Processing of sold products into further products by third parties (e.g. raw materials refined, components assembled).',
  },
  {
    category: 11,
    name: 'Use of Sold Products',
    defaultMethod: 'activity-based',
    description:
      'End-use of sold products by the consumer (e.g. energy consumption of appliances, fuel combustion in vehicles).',
  },
  {
    category: 12,
    name: 'End-of-Life Treatment of Sold Products',
    defaultMethod: 'activity-based',
    description:
      'Waste disposal and treatment of sold products at end of life (recycling, landfill, incineration).',
  },
  {
    category: 13,
    name: 'Downstream Leased Assets',
    defaultMethod: 'activity-based',
    description:
      'Scope 1 and Scope 2 emissions from the operation of assets owned by the reporting company and leased to other entities.',
  },
  {
    category: 14,
    name: 'Franchises',
    defaultMethod: 'activity-based',
    description:
      'Scope 1 and Scope 2 emissions from the operation of franchises not included in Scope 1 or 2 of the reporting company.',
  },
  {
    category: 15,
    name: 'Investments',
    defaultMethod: 'spend-based',
    description:
      'Financed emissions: the reporting company\'s proportional share of Scope 1, 2, and 3 emissions from investments (equity, debt, project finance). Equity share method is the default.',
  },
] as const;

/** Lookup map for Scope 3 categories by number */
export const SCOPE3_CATEGORY_MAP: Record<number, Scope3Category> =
  Object.fromEntries(
    SCOPE3_CATEGORIES.map((cat) => [cat.category, cat])
  );

// ---------------------------------------------------------------------------
// Scope 3, T&D Loss Factors (Category 3)
// ---------------------------------------------------------------------------

export const TD_LOSS_FACTORS: Record<string, TDLossFactor> = {
  peninsular: {
    region: 'Peninsular Malaysia',
    lossFactor: 0.075, // 7.5%
  },
  sabah: {
    region: 'Sabah',
    lossFactor: 0.12, // 12%
  },
  sarawak: {
    region: 'Sarawak',
    lossFactor: 0.08, // 8%
  },
} as const;

// ---------------------------------------------------------------------------
// Scope 3, Upstream / Downstream Transport (Categories 4 & 9)
// ---------------------------------------------------------------------------

export const TRANSPORT_FACTORS: Record<string, TransportFactor> = {
  truck_average: {
    mode: 'Truck (Average)',
    kgCo2ePerTonneKm: 0.102,
  },
  rail: {
    mode: 'Rail',
    kgCo2ePerTonneKm: 0.028,
  },
  air_freight: {
    mode: 'Air Freight',
    kgCo2ePerTonneKm: 1.18,
  },
  domestic_air_passenger: {
    mode: 'Domestic Air (Passenger)',
    kgCo2ePerPassengerKm: 0.255,
  },
  international_air_passenger: {
    mode: 'International Air (Passenger)',
    kgCo2ePerPassengerKm: 0.195,
  },
} as const;

// ---------------------------------------------------------------------------
// Scope 3, Waste Treatment (Category 5 & 12)
// ---------------------------------------------------------------------------

export const WASTE_FACTORS: Record<string, WasteFactor> = {
  landfill: {
    method: 'Landfill',
    tCo2ePerTonne: 0.588,
  },
  recycling: {
    method: 'Recycling',
    tCo2ePerTonne: 0.02,
  },
  incineration: {
    method: 'Incineration',
    tCo2ePerTonne: 0.35,
  },
} as const;

// ---------------------------------------------------------------------------
// Scope 3, Business Travel (Category 6)
// ---------------------------------------------------------------------------

export const BUSINESS_TRAVEL_FACTORS = {
  car: {
    mode: 'Car',
    kgCo2ePerKm: 0.21,
  },
  domestic_air: {
    mode: 'Domestic Air',
    kgCo2ePerPassengerKm: 0.255,
  },
  international_air: {
    mode: 'International Air',
    kgCo2ePerPassengerKm: 0.195,
  },
} as const;

// ---------------------------------------------------------------------------
// Scope 3, Employee Commuting (Category 7)
// ---------------------------------------------------------------------------

export const EMPLOYEE_COMMUTING_FACTORS = {
  car: {
    mode: 'Car',
    kgCo2ePerKm: 0.21,
  },
  motorcycle: {
    mode: 'Motorcycle',
    kgCo2ePerKm: 0.09,
  },
  bus: {
    mode: 'Bus',
    kgCo2ePerKm: 0.089,
  },
  rail: {
    mode: 'Rail (LRT/MRT/KTM)',
    kgCo2ePerKm: 0.041,
  },
  walking_cycling: {
    mode: 'Walking / Cycling',
    kgCo2ePerKm: 0,
  },
} as const;

// ---------------------------------------------------------------------------
// Scope 3, Industry-Average Emission Intensities (Categories 1 & 2)
// ---------------------------------------------------------------------------

export const INDUSTRY_EMISSION_INTENSITIES: IndustryEmissionIntensity[] = [
  { industry: 'Agriculture & Plantation', tCo2ePerRmMillion: 580 },
  { industry: 'Construction', tCo2ePerRmMillion: 320 },
  { industry: 'Education', tCo2ePerRmMillion: 85 },
  { industry: 'Energy & Utilities', tCo2ePerRmMillion: 740 },
  { industry: 'Financial Services', tCo2ePerRmMillion: 48 },
  { industry: 'Healthcare', tCo2ePerRmMillion: 105 },
  { industry: 'Hospitality & Tourism', tCo2ePerRmMillion: 290 },
  { industry: 'ICT & Technology', tCo2ePerRmMillion: 62 },
  { industry: 'Manufacturing', tCo2ePerRmMillion: 480 },
  { industry: 'Mining & Quarrying', tCo2ePerRmMillion: 610 },
  { industry: 'Oil & Gas', tCo2ePerRmMillion: 820 },
  { industry: 'Professional Services', tCo2ePerRmMillion: 52 },
  { industry: 'Property & Real Estate', tCo2ePerRmMillion: 260 },
  { industry: 'Retail & Wholesale', tCo2ePerRmMillion: 210 },
  { industry: 'Transportation & Logistics', tCo2ePerRmMillion: 440 },
  { industry: 'Waste Management', tCo2ePerRmMillion: 350 },
  { industry: 'Other', tCo2ePerRmMillion: 200 },
] as const;

/** Lookup map by industry name */
export const INDUSTRY_EMISSION_INTENSITY_MAP: Record<string, number> =
  Object.fromEntries(
    INDUSTRY_EMISSION_INTENSITIES.map((item) => [
      item.industry,
      item.tCo2ePerRmMillion,
    ])
  );

// ---------------------------------------------------------------------------
// Scope 3, Financed Emissions Default (Category 15)
// ---------------------------------------------------------------------------

/** Default financed emissions parameters */
export const FINANCED_EMISSIONS_DEFAULTS = {
  /** Equity share method: percentage ownership used as default */
  equityShareMethod: true,
  /** Default assumption: reporting company owns < 20% (no operational control) */
  defaultOwnershipPercentage: 0.10, // 10%
  /** Description */
  description:
    'Category 15 (Investments) uses the equity share method by default. The reporting company calculates its proportional share of Scope 1, 2, and 3 emissions from equity investments based on ownership percentage.',
} as const;

// ---------------------------------------------------------------------------
// Helper: CO₂e Calculation
// ---------------------------------------------------------------------------

/**
 * Calculate CO₂e from individual gas emissions using IPCC AR5 GWPs.
 * @param co2  kg CO₂
 * @param ch4  kg CH₄
 * @param n2o  kg N₂O
 * @returns total kg CO₂e
 */
export function calculateCo2e(
  co2: number,
  ch4: number,
  n2o: number
): number {
  return co2 * GWP_AR5.co2 + ch4 * GWP_AR5.ch4 + n2o * GWP_AR5.n2o;
}

/**
 * Calculate CO₂e for a stationary combustion fuel given a quantity.
 * @param fuelKey  key from STATIONARY_COMBUSTION_FACTORS
 * @param quantity  amount of fuel consumed
 * @returns total kg CO₂e (0 for biogenic fuels)
 */
export function calculateStationaryCombustionCo2e(
  fuelKey: keyof typeof STATIONARY_COMBUSTION_FACTORS,
  quantity: number
): number {
  const fuel = STATIONARY_COMBUSTION_FACTORS[fuelKey];
  if (fuel.biogenic) return 0;
  return calculateCo2e(
    fuel.co2 * quantity,
    fuel.ch4 * quantity,
    fuel.n2o * quantity
  );
}

/**
 * Calculate CO₂e for a refrigerant leak.
 * @param refrigerantKey  key from REFRIGERANT_FACTORS
 * @param chargeKg  total refrigerant charge in kg
 * @param leakageRate  optional override; defaults to refrigerant's defaultLeakageRate
 * @returns kg CO₂e
 */
export function calculateRefrigerantLeakCo2e(
  refrigerantKey: keyof typeof REFRIGERANT_FACTORS,
  chargeKg: number,
  leakageRate?: number
): number {
  const ref = REFRIGERANT_FACTORS[refrigerantKey];
  const rate = leakageRate ?? ref.defaultLeakageRate;
  return chargeKg * rate * ref.gwp;
}

/**
 * Calculate CO₂e for mobile combustion (vehicle distance).
 * @param vehicleKey  key from MOBILE_COMBUSTION_FACTORS
 * @param distanceKm  distance traveled in km
 * @returns kg CO₂e
 */
export function calculateMobileCombustionCo2e(
  vehicleKey: keyof typeof MOBILE_COMBUSTION_FACTORS,
  distanceKm: number
): number {
  const vehicle = MOBILE_COMBUSTION_FACTORS[vehicleKey];
  return calculateCo2e(
    vehicle.co2PerKm * distanceKm,
    vehicle.ch4PerKm * distanceKm,
    vehicle.n2oPerKm * distanceKm
  );
}
