// Malaysian Emission Factors (from MGTC/GHG Protocol)

export const EMISSION_FACTORS = {
  // Scope 1: Direct emissions from fuel combustion (kg CO2e per unit)
  scope1: {
    'Diesel': { factor: 2.68, unit: 'litres', unitLabel: 'kg CO₂e/litre' },
    'Petrol': { factor: 2.31, unit: 'litres', unitLabel: 'kg CO₂e/litre' },
    'Natural Gas': { factor: 2.02, unit: 'kg', unitLabel: 'kg CO₂e/kg' },
    'LPG': { factor: 2.98, unit: 'kg', unitLabel: 'kg CO₂e/kg' },
  },
  // Scope 2: Indirect emissions from electricity (kg CO2e per kWh)
  scope2: {
    'Peninsular': { factor: 0.6332, label: 'Peninsular Malaysia Grid' },
    'Sabah': { factor: 0.4138, label: 'Sabah Grid' },
    'Sarawak': { factor: 0.2450, label: 'Sarawak Grid' },
  },
} as const;

export const FUEL_TYPES = Object.keys(EMISSION_FACTORS.scope1);
export const GRID_LOCATIONS = Object.keys(EMISSION_FACTORS.scope2);

// Malaysian Industry Sectors (for dropdown)
export const INDUSTRY_SECTORS = [
  'Agriculture & Plantation',
  'Construction',
  'Education',
  'Energy & Utilities',
  'Financial Services',
  'Healthcare',
  'Hospitality & Tourism',
  'ICT & Technology',
  'Manufacturing',
  'Mining & Quarrying',
  'Oil & Gas',
  'Professional Services',
  'Property & Real Estate',
  'Retail & Wholesale',
  'Transportation & Logistics',
  'Waste Management',
  'Other',
] as const;

export const REVENUE_RANGES = [
  'Below RM300,000',
  'RM300,000 – RM15 million',
  'RM15 million – RM50 million',
  'RM50 million – RM300 million',
  'Above RM300 million',
] as const;

export const MALAYSIAN_STATES = [
  'Johor',
  'Kedah',
  'Kelantan',
  'Kuala Lumpur',
  'Labuan',
  'Malacca',
  'Negeri Sembilan',
  'Pahang',
  'Penang',
  'Perak',
  'Perlis',
  'Putrajaya',
  'Sabah',
  'Sarawak',
  'Selangor',
  'Terengganu',
] as const;

// Company classification based on SME Corp Malaysia definitions
export function classifyCompany(revenueRange: string, employees: number): string {
  const revenueMap: Record<string, number> = {
    'Below RM300,000': 300000,
    'RM300,000 – RM15 million': 15000000,
    'RM15 million – RM50 million': 50000000,
    'RM50 million – RM300 million': 300000000,
    'Above RM300 million': 300000001,
  };

  const revenue = revenueMap[revenueRange] || 0;

  if (revenue <= 300000 && employees <= 5) return 'Micro';
  if (revenue <= 15000000 && employees <= 75) return 'Small';
  if (revenue <= 50000000 && employees <= 200) return 'Medium';
  return 'Large';
}

// Subscription plans
export const SUBSCRIPTION_PLANS = [
  {
    id: 'free',
    name: 'Starter',
    price: 0,
    interval: 'monthly' as const,
    description: 'Get started with basic ESG reporting',
    features: [
      '1 Company Profile',
      'GHG Calculator (Scope 1 & 2)',
      'Basic SEDG Questionnaire',
      'ESG Readiness Score',
      'Community Support',
      '1 Report per period',
    ],
    cta: 'Current Plan',
    highlighted: false,
  },
  {
    id: 'starter',
    name: 'Professional',
    price: 299,
    interval: 'monthly' as const,
    description: 'For growing businesses serious about ESG',
    features: [
      'Everything in Starter',
      'Up to 3 Company Profiles',
      'Unlimited GHG Calculations',
      'Full SEDG Questionnaire',
      'PDF Report Generation',
      'Historical Data & Trends',
      'Priority Email Support',
    ],
    cta: 'Upgrade to Professional',
    highlighted: true,
  },
  {
    id: 'professional',
    name: 'Enterprise',
    price: 799,
    interval: 'monthly' as const,
    description: 'For organisations with advanced ESG needs',
    features: [
      'Everything in Professional',
      'Unlimited Company Profiles',
      'Multi-user Access',
      'Scope 3 Emissions Tracking',
      'Bursa Narrative Statement Template',
      'Bank/Loan Summary Template',
      'Custom Branding on Reports',
      'Dedicated Account Manager',
      'API Access',
    ],
    cta: 'Contact Sales',
    highlighted: false,
  },
];