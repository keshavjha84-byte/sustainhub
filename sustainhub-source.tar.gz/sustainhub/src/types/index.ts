// ESG Platform Types

export interface UserSession {
  id: string;
  email: string;
  name: string;
  role: string;
}

export interface CompanyData {
  id: string;
  userId: string;
  companyName: string;
  registrationNumber: string | null;
  industrySector: string;
  annualRevenue: string | null;
  numberOfEmployees: number | null;
  state: string | null;
  companySize: string;
  onboardingCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface OnboardingFormData {
  companyName: string;
  registrationNumber?: string;
  industrySector: string;
  annualRevenue: string;
  numberOfEmployees: number;
  state: string;
}

export type CompanySize = 'Micro' | 'Small' | 'Medium' | 'Large';

export interface Scope1Item {
  fuelType: string;
  quantity: number;
  unit: string;
  emissions: number;
}

export interface Scope2Item {
  electricityKwh: number;
  gridLocation: string;
  emissionFactor: number;
  emissions: number;
}

export interface EmissionItem {
  id?: string;
  scope: number; // 1, 2, or 3
  category: string;
  subCategory?: string;
  sourceName?: string;
  activityData: number;
  activityUnit: string;
  emissionFactor: number;
  efUnit: string;
  emissions: number;
  metadata?: string;
}

export interface GhgEntry {
  id: string;
  reportingPeriod: string;
  scope1Total: number;
  scope2Total: number;
  scope3Total: number;
  totalEmissions: number;
  status: string;
  scope2Method: string;
  emissionItems: EmissionItem[];
  scope1Items: Scope1Item[];
  scope2Items: Scope2Item[];
  createdAt: string;
}

export interface EsgIndicator {
  code: string;
  section: 'Governance' | 'Environmental' | 'Social';
  label: string;
  type: 'text' | 'number' | 'select' | 'yesno' | 'percentage';
  options?: string[];
  tooltip?: string;
  placeholder?: string;
  required?: boolean;
}

export interface EsgResponse {
  id: string;
  indicatorCode: string;
  indicatorLabel: string;
  section: string;
  responseValue: string | null;
  notes: string | null;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  interval: 'monthly' | 'yearly';
  features: string[];
  highlighted?: boolean;
  cta?: string;
}

export type PortalView =
  | 'dashboard'
  | 'onboarding'
  | 'ghg-calculator'
  | 'esg-questionnaire'
  | 'reports'
  | 'resources'
  | 'subscription'
  | 'settings'
  | 'landing';